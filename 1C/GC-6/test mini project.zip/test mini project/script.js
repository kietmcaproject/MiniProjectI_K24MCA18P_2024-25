// Toggle between Manage Users and Manage Products
document.getElementById('manage-users-btn').addEventListener('click', function() {
    document.getElementById('manage-users').style.display = 'block';
    document.getElementById('manage-products').style.display = 'none';
  });
  
  document.getElementById('manage-products-btn').addEventListener('click', function() {
    document.getElementById('manage-users').style.display = 'none';
    document.getElementById('manage-products').style.display = 'block';
  });
  
  // Sample data for users and products
  let users = [
    { id: 1, name: 'John Doe', email: 'john@example.com' },
    { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
  ];
  
  let products = [
    { id: 1, name: 'Laptop', price: '$1000' },
    { id: 2, name: 'Smartphone', price: '$800' }
  ];
  
  // Add User
  function addUser() {
    const userName = prompt("Enter user's name:");
    const userEmail = prompt("Enter user's email:");
  
    if (userName && userEmail) {
      const newUser = { id: users.length + 1, name: userName, email: userEmail };
      users.push(newUser);
      renderUsers();
    }
  }
  
  // Delete User
  function deleteUser(id) {
    users = users.filter(user => user.id !== id);
    renderUsers();
  }
  
  // Render Users
  function renderUsers() {
    const userTable = document.getElementById('user-table').getElementsByTagName('tbody')[0];
    userTable.innerHTML = ''; // Clear the table
    users.forEach(user => {
      const row = userTable.insertRow();
      row.innerHTML = `
        <td>${user.id}</td>
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td><button onclick="deleteUser(${user.id})">Delete</button></td>
      `;
    });
  }
  
  // Add Product
  function addProduct() {
    const productName = prompt("Enter product's name:");
    const productPrice = prompt("Enter product's price:");
  
    if (productName && productPrice) {
      const newProduct = { id: products.length + 1, name: productName, price: productPrice };
      products.push(newProduct);
      renderProducts();
    }
  }
  
  // Delete Product
  function deleteProduct(id) {
    products = products.filter(product => product.id !== id);
    renderProducts();
  }
  
  // Render Products
  function renderProducts() {
    const productTable = document.getElementById('product-table').getElementsByTagName('tbody')[0];
    productTable.innerHTML = ''; // Clear the table
    products.forEach(product => {
      const row = productTable.insertRow();
      row.innerHTML = `
        <td>${product.id}</td>
        <td>${product.name}</td>
        <td>${product.price}</td>
        <td><button onclick="deleteProduct(${product.id})">Delete</button></td>
      `;
    });
  }
  // Smooth Toggle Function with Fade Effect
function toggleSection(showId, hideId) {
  const showSection = document.getElementById(showId);
  const hideSection = document.getElementById(hideId);

  hideSection.style.opacity = '0'; // Fade out
  setTimeout(() => {
    hideSection.style.display = 'none';
    showSection.style.display = 'block';
    setTimeout(() => {
      showSection.style.opacity = '1'; // Fade in
    }, 50); // Delay for smooth effect
  }, 300); // Matches fade-out animation
}

// Assign Buttons
document.getElementById('manage-users-btn').addEventListener('click', function() {
  toggleSection('manage-users', 'manage-products');
});

document.getElementById('manage-products-btn').addEventListener('click', function() {
  toggleSection('manage-products', 'manage-users');
});

  // Initial rendering of users and products
  renderUsers();
  renderProducts();