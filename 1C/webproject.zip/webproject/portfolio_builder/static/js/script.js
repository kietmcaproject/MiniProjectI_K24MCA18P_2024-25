document.addEventListener('DOMContentLoaded', function () {
    const greetingElement = document.getElementById('greeting');
    if (greetingElement) {
        greetingElement.innerHTML = "Welcome to Portfolio Builder!";
    }
});