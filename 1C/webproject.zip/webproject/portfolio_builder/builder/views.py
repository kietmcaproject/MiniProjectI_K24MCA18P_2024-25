from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.forms import AuthenticationForm

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from .forms import UserRegistrationForm, PortfolioForm
from .models import Portfolio


def home(request):
    return render(request, 'builder/home.html')

def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            return redirect('login')
    else:
        form = UserRegistrationForm()
    return render(request, 'builder/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')  # Redirect to dashboard after successful login
    else:
        form = AuthenticationForm()
    
    return render(request, 'builder/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

def dashboard(request):
    return render(request, 'builder/dashboard.html')

def create_portfolio(request):
    if request.method == 'POST':
        form = PortfolioForm(request.POST, request.FILES)
        if form.is_valid():
            portfolio = form.save(commit=False)
            portfolio.user = request.user
            portfolio.save()
            return redirect('preview_portfolio')
    else:
        form = PortfolioForm()
    return render(request, 'builder/create_portfolio.html', {'form': form})

def preview_portfolio(request):
    portfolio = Portfolio.objects.get(user=request.user)
    return render(request, 'builder/preview_portfolio.html', {'portfolio': portfolio})