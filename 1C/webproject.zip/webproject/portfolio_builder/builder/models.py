from django.db import models
from django.contrib.auth.models import User

class Portfolio(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    portfolio_name = models.CharField(max_length=255, default="Untitled Portfolio")
    description = models.TextField()
    image = models.ImageField(upload_to='portfolio_images/', blank=True, null=True)
    tags = models.CharField(max_length=255, blank=True)  # We will store tags as a comma-separated string.

    def __str__(self):
        return self.portfolio_name