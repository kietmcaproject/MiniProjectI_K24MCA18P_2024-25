from django import forms
from .models import Portfolio
from django.contrib.auth.models import User

class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = User
        fields = ['username', 'email', 'password']

class PortfolioForm(forms.ModelForm):
    class Meta:
        model = Portfolio
        fields = ['portfolio_name', 'description', 'image', 'tags']

    tags = forms.CharField(widget=forms.TextInput(attrs={'data-role': 'tagsinput'}), required=False)