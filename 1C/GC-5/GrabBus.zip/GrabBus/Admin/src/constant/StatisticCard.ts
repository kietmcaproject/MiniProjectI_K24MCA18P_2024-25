import {FiUsers} from 'react-icons/fi'
import {FaRegMoneyBillAlt} from 'react-icons/fa'
import {FcSalesPerformance} from "react-icons/fc"
export const StatisticCard=[
    {
        id:"1",
        icon:FaRegMoneyBillAlt,
        sum:"1234",
        content:"Today's Money",
        percentage:"1.2"
    },
    {
        id:"2",
        icon:FiUsers,
        sum:"134",
        content:"New Clients",
        percentage:"1.2"
    },
    {
        id:"3",
        icon:FcSalesPerformance,
        sum:"1234",
        content:"Sales",
        percentage:"1.2"
    },
    {
        id:"1",
        icon:FaRegMoneyBillAlt,
        sum:"1234",
        content:"Reservations",
        percentage:"1.2"
    }
]