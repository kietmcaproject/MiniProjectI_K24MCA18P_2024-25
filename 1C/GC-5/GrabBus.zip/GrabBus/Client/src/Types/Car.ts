export interface Car{
    car_name:string,
    nbr_places:number,
    car_image:string
}