export interface Company{
    company_name:string
}