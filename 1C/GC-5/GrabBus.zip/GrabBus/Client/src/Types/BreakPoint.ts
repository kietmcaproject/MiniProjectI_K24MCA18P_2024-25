export interface BreakPoint{
    arrival_time:string,
    city_name:string
}