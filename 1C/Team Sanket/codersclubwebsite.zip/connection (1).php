<?php
$server = 'localhost:3306';
$username = 'fhrskqtz_login';
$password = 'Sanket@6571';
$database = 'fhrskqtz_login_system';

// Create connection
$conn = new mysqli($server, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
