<?php
session_start();
include_once('connection.php');

// Function to generate encrypted link
function generateEncryptedLink($destination) {
    // Generate a random string for encryption
    $randomString = substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil(10/strlen($x)) )),1,10);
    // Encrypt the destination with the random string
    $encryptedLink = base64_encode($destination . "|" . $randomString);
    return $encryptedLink;
}

// Function to decrypt the link and extract the destination URL
function decryptLink($encryptedLink) {
    // Decode the encrypted link
    $decodedLink = base64_decode($encryptedLink);
    // Split the decoded link into destination URL and random string
    $parts = explode("|", $decodedLink);
    // Return the destination URL
    return $parts[0];
}

// Check if the session variables are set
if (!isset($_SESSION['name']) || !isset($_SESSION['username'])) {
    // Redirect to index.php if session variables are not set
    if(!strpos($_SERVER['REQUEST_URI'], 'index.php')) {
        header("Location: index.php");
        exit();
    }
}

// Logout functionality
if (isset($_POST['logout'])) {
    // Unset all session variables
    session_unset();
    // Destroy the session
    session_destroy();
    // Redirect to index.php after logout
    if(!strpos($_SERVER['REQUEST_URI'], 'index.php')) {
        header("Location: index.php");
        exit();
    }
}

// Set session timeout period (in seconds)
$timeout = 600; // 10 minutes

// Check if the user's last activity time is set
if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > $timeout) {
    // Unset all session variables
    session_unset();
    // Destroy the session
    session_destroy();
    // Redirect to index.php after session timeout
    if(!strpos($_SERVER['REQUEST_URI'], 'index.php')) {
        header("Location: index.php");
        exit();
    }
} else {
    // Update last activity time
    $_SESSION['last_activity'] = time();
}

// Check if the card link is clicked and the user is logged in
if (isset($_GET['link']) && isset($_SESSION['name']) && isset($_SESSION['username'])) {
    // Decrypt the link and extract the destination URL
    $destinationURL = decryptLink($_GET['link']);
    // Redirect the user to the destination URL
    header("Location: $destinationURL");
    exit();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="shortcut icon" href="favicon.png">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.css">
  <title>Coders Club</title>
  
  
  <style>
  @import url('https://fonts.googleapis.com/css?family=Roboto:700');
    /* Your CSS styles here */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Lato', 'Arial', sans-serif;
    }
h1, p {
  color: #fff;
  text-align: center;
  line-height: 1.4;
}

h1 {
  font-size: 2.2rem;
}

h2 {
  color: #000;
  font-size: 1.3rem;
  text-align: center;
  line-height: 1.4;
  margin-bottom: 10px;
}

/* BASIC SETUP */

.page-wrapper {
  width: 100%;
  height: auto;
}

.nav-wrapper {
  width: 100%;
  position: -webkit-sticky; /* Safari */
  position: sticky;
  top: 0;
  background-color: #ffffff;
}


/* NAVIGATION */
/* Add these styles to your existing CSS */

/* Add these styles to your existing CSS */

.navbar {
  display: flex;
  align-items: center;
  height: 70px;
  overflow: hidden;
}

.navbar .nav {
  display: flex;
  align-items: center;
  margin-left: auto;
}

.navbar .nav-item {
  margin-right: 20px; /* Adjusted margin between nav items */
}

.navbar .login-btn {
  margin-left: -7px;
}

.login-btn button {
            color: white;
  background-color: rgba(104, 85, 224, 1);
  border: 1px solid rgba(104, 85, 224, 1);
  cursor: pointer;
  border: 0;
  border-radius: 4px;
  font-weight: 600;
  margin: 0 10px;
  width: 85px;
  padding: 10px 0;
  box-shadow: 0 0 20px rgba(104, 85, 224, 0.2);
  transition: 0.4s;
        }

        .login-btn button:hover {
            color: yellow;
  width:;
  box-shadow: 0 0 20px rgba(104, 85, 224, 0.6);
  background-color: rgba(104, 85, 224, 1);
        }



.navbar img {
  height: 42px;
  width: auto;
  justify-self: start;
  margin-left: 20px;
}

.navbar ul {
  list-style: none;
  display: grid;
  grid-template-columns: repeat(6,1fr);
  justify-self: end;
  
}

.nav-item a {
  color: #000;
  font-size: 1.12rem;
  font-weight: 600;
  text-decoration: none;
  transition: color 0.3s ease-out;
}

.nav-item a:hover {
  color: red;
}

/* SECTIONS main */

/* General Styles */

.headline {
  width: 100%;
  height: 50vh;
  min-height: 350px;
  background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.7)),
    url('image/back.jpg');
  background-size: cover;
  background-position: center; /* Center the background image */
  display: flex;
  flex-direction: column;
  justify-content: center;

}

.wrapper {
	text-align: center;
	p {
		color: white;
		font-size: 40px;
	
		font-weight: 600;
		font-family: "Josefin Sans", sans-serif;
		background: linear-gradient(to left,#095fab 10%,#FFD700 20%, red 50%, white 40%);
		background-size: auto auto;
		background-clip: border-box;
		background-size: 200% auto;
		color: #fff;
		background-clip: text;
		text-fill-color: transparent;
		-webkit-background-clip: text;
		-webkit-text-fill-color: transparent;
		animation: textclip 2.5s linear infinite;
		display: inline-block;
	}
}

@keyframes textclip {
	to {
		background-position: 200% center;
	}
}



/*--------------*/


@keyframes leftSwift {
  0% {
    opacity: 0;
    transform: translateX(-50px);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
  }
}

.headline h1 {
  font-size: 3rem;
  animation: leftSwift 1s ease-out;
  opacity: 0; /* Initial opacity set to 0 for animation */
}

/* Adjusted code to handle visibility after animation */
.headline h1.animation-complete {
  opacity: 1;
}


.features {
  display: flex;
  justify-content: space-around;
  padding: 80px 28px;
  background-color: #f1f1f1;
}

.feature-container {
  flex-basis: 30%;
  text-align: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.feature-container img {
  max-width: 75%; /* Ensure the image doesn't exceed the container width */
  height: auto; /* Allow the height to adjust proportionally */
}

.feature-container p {
    color: BLACK; /* Change text color to red */
    font-size: 20px; /* Adjust font size */
    margin-top: 10px; /* Add space between image and text */
    margin-bottom: 0; /* Remove bottom margin */
    font-weight: bold; /* Make text bold */
    font-family: Arial, sans-serif; /* Change font family */
}

.feature-container p  {
    text-decoration: none; /* Remove underline from links within the paragraph */
}
.feature-container a {
    text-decoration: none; /* Remove underline from all links within the feature container */
}
        
        .feature-container:hover p,
        .feature-container:hover h3 {
            color: #000; /* Change text color on hover */
        }
/* Responsive adjustments */
@media only screen and (max-width: 768px) {
  .features {
    flex-direction: column;
    align-items: center;
  }
  
  .feature-container {
    flex-basis: 80%;
    margin-bottom: 20px;
  }
}

@media only screen and (max-width: 600px) {
  .feature-container {
    flex-basis: 70%;
  }
}

@media only screen and (max-width: 500px) {
  .feature-container {
    flex-basis: 80%;
  }
}


/* SEARCH FUNCTION */



/* MOBILE MENU & ANIMATION */

.menu-toggle .bar{
  width: 25px;
  height: 3px;
  background-color: #3f3f3f;
  margin: 5px auto;
  -webkit-transition: all 0.3s ease-in-out;
  -o-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}

.menu-toggle {
  justify-self: end;
  margin-right: 25px;
  display: none;
}

.menu-toggle:hover{
  cursor: pointer;
}

#mobile-menu.is-active .bar:nth-child(2){
  opacity: 0;
}

#mobile-menu.is-active .bar:nth-child(1){
  -webkit-transform: translateY(8px) rotate(45deg);
  -ms-transform: translateY(8px) rotate(45deg);
  -o-transform: translateY(8px) rotate(45deg);
  transform: translateY(8px) rotate(45deg);
}

#mobile-menu.is-active .bar:nth-child(3){
  -webkit-transform: translateY(-8px) rotate(-45deg);
  -ms-transform: translateY(-8px) rotate(-45deg);
  -o-transform: translateY(-8px) rotate(-45deg);
  transform: translateY(-8px) rotate(-45deg);
}

/* KEYFRAME ANIMATIONS */

@-webkit-keyframes gradbar {
  0% {
    background-position: 0% 50%
  }
  50% {
    background-position: 100% 50%
  }
  100% {
    background-position: 0% 50%
  }
}

@-moz-keyframes gradbar {
  0% {
    background-position: 0% 50%
  }
  50% {
    background-position: 100% 50%
  }
  100% {
    background-position: 0% 50%
  }
}

@keyframes gradbar {
  0% {
    background-position: 0% 50%
  }
  50% {
    background-position: 100% 50%
  }
  100% {
    background-position: 0% 50%
  }
}

/* Media Queries */

  /* Mobile Devices - Phones/Tablets */

@media only screen and (max-width: 720px) { 
  .feature{
    flex-direction: column;
    padding: 55px;
  }
  
  /* MOBILE HEADINGS */
  
  h1 {
    font-size: 1.9rem;
  }
  
  h2 {
    font-size: 1rem;
  }
  
  p {
    font-size: 0.8rem;
  }
  

  /* MOBILE NAVIGATION */
     
  .navbar ul {
    display: flex;
    flex-direction: column;
    position: fixed;
    justify-content: start;
    top: 55px;
    background-color: #fff;
    width: 100%;
    height: calc(100vh - 55px);
    transform: translate(-101%);
    text-align: center;
    overflow: hidden;
  }
  
  .navbar li {
    padding: 15px;
  }
  
  .navbar li:first-child {
    margin-top: 50px;
  }
  
  .navbar li a {
    font-size: 1rem;
  }
   
  .menu-toggle, .bar {
    display: block;
    cursor: pointer;
  }
  
  .mobile-nav {
  transform: translate(0%)!important;
}
  
  /* SECTIONS */
  
  .headline {
    height: 20vh;
  }
    
  .feature-container p {
    margin-bottom: 25px;
  }
  
  .feature-container {
    margin-top: 20px;
  }
  
  .feature-container:nth-child(2) {
    order: -1;
  }
  
  
  
}ssssssssssssssssss
    /* Add the rest of your styles here */


    #services {
    padding: 10px 0;
}

.services-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(110px, 150fr));
    grid-gap: 60px;
    justify-content: center;
    margin-top: 65px;
}

.services-list div {
  text-align: center;
    background:#03061A ;
    padding: 20px;
    font-size: 25px;
    line-height: 30 px;
    font-weight: 300;
    border-radius: 40px;
    transition: background 0.5s, transform 0.5s;
}

.services-list div i {
    font-size: 40px;
    margin-bottom: 5px;
}

.services-list div h2 {
    font-size: 30px;
    font-weight: 500;
    margin-bottom: 15px;
}

.services-list div a {
    text-decoration: none;
    color: #fff;
    align-items: center;
    font-size: 14px;
    margin-top: 20px;
    
    display: inline-block;
}

.services-list div:hover {
    background: #ff004f;
    transform: translateY(-10px);
}
    
    .typing-animation {
      font-family: 'Poppins', sans-serif;
      font-weight: bold;
      font-size: 50px;
      color:white;
      animation: typing 3s steps(30) 4s infinite;
    }

    @keyframes typing {
      0% {
        opacity: 0;
      }
      50% {
        opacity: 1;
      }
      100% {
        opacity: 0;
      }

    }
    h2{
        font-weight: 700
    }
     h3{
        font-weight: 700
    }
    p2{
     font-weight: 500
    }

    footer {
      background-color: #03061A; /* Use rgba to set a transparent background color */
      color: #fff;
      padding: 20px;
      text-align: center;
    }

    .footer-links {
      margin-top: 20px;
      color: red;
      text-decoration: none;
    }

    .footer-links a2 {
      color: white;
      text-decoration: none;
      margin-right: 10px;
    }
    
/* Add a class to set the body position to fixed */
.circle-loader-container {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: rgba(0, 0, 0, 0.7);
    z-index: 9998;
}

.circle-loader {
    width: 60px;
    height: 60px;
    border: 6px solid transparent;
    border-radius: 50%;
    animation: spin 1s linear infinite, color-change 4s infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

@keyframes color-change {
    0%, 100% { border-top-color: red; }
    25% { border-top-color: yellow; }
    50% { border-top-color: blue; }
    75% { border-top-color: orange; }
}

/* Add the rest of your existing styles */



 .page-container {
      width: 96vw;
      overflow: hidden;
      position: relative;
    }

    .fruit-container {
      display: flex;
      white-space: nowrap;
      animation: scroll 40s linear infinite;
      width: fit-content;
      position: relative;
    }

    .fruit-container:hover {
      animation-play-state: paused;
    }

    .card {
      width: 200px;
      height: 100px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin: 8px;
      background-color: rgba(255, 255, 255, 0.2);
      border-radius: 10px;
      flex-shrink: 0;
      overflow: hidden;
      transition: transform 0.3s, box-shadow 0.3s, background-color 0.3s;
      backdrop-filter: blur(5px);
      box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
    }

    .card:hover {
      transform: scale(1.05);
      box-shadow: 0px 4px 8px rgba(255, 0, 0, 0.5);
      background-color: rgba(255, 255, 255, 0.3);
    }

    .card img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 10px;
    }

    @keyframes scroll {
      0% { transform: translateX(0); }
      100% { transform: translateX(calc(-100% + 200px)); }
    }

.sub-title {
    font-size: 40px;
    font-weight: 700;
    color: red;
}

.feature-container {
  transition: transform 0.3s ease-in-out;
  text-decoration: none; /* Remove underline from text */
}

.feature-container:hover {
  transform: scale(1.05);
}
.headline h1 {
  z-index: 1; /* Set a higher z-index */
}

/* Adjust the z-index of the header to ensure it's above the animated elements */
.nav-wrapper {
  z-index: 2; 

  </style>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script>
    $(document).ready(function() {
      $("#search-icon").click(function() {
        $(".nav").toggleClass("search");
        $(".nav").toggleClass("no-search");
        $(".search-input").toggleClass("search-active");
      });

      $('.menu-toggle').click(function(){
         $(".nav").toggleClass("mobile-nav");
         $(this).toggleClass("is-active");
      });
    });
  </script>
</head>
<body>
  <div class="page-wrapper">
    <div class="nav-wrapper">
      <div class="grad-bar"></div>
      <nav class="navbar">
        <img src="image/main.jpg" alt="Logo">
        <div class="menu-toggle" id="mobile-menu">
          <span class="bar"></span>
          <span class="bar"></span>
          <span class="bar"></span>
        </div>
        <ul class="nav no-search">
          <li class="nav-item"><a href="index.php">Home</a></li>
          <li class="nav-item"><a href="courselogin.php">Courses</a></li>
          <li class="nav-item"><a href="#">Community</a></li>
          <li class="nav-item"><a href="About.html">About</a></li>
          <li class="nav-item"><a href="ContactUs.php">Contact Us</a></li>
          <li class="nav-item login-btn">
            <?php if(isset($_SESSION['name']) && isset($_SESSION['username'])): ?>
                <form action="" method="post">
                    <button type="submit" name="logout" id="logout-button">Logout</button>
                </form>
            <?php else: ?>
                <a href="mainlogin.php"><button id="login-button">Login</button></a>
            <?php endif; ?>
          </li>
        </ul>
      </nav>
    </div>
    
   <section class="headline">
     <div class="wrapper">
	<p>#Codersclub.in</p>
</div>
    </section>
    


  </div>
  <script>
  // Adding a class to indicate the completion of the animation
  document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('.headline h1').classList.add('animation-complete');
  });
</script>
<br><div id="services">
        <div class="container">
            <h2 class="sub-title">POPULAR</h2>
            <div class="services-list">
                <div>
                    <a href="programming-language/javascript.html"><i class="fab fa-js fa-2x"style="font-size:80px;color:white;"></i>
                </a></div>
                <div>
                   <a href="programming-language/c-programming.html"><i class="fab fa-cuttlefish fa-2x"style="font-size:70px;color:white;"></i>
                </a></div>
                <div>
                    <a href="programming-language/react.html"><i class="fa-brands fa-react" style="font-size:80px;color:white;"></i>
                </a></div>
                 <div>
                    <a href="programming-language/php.html"><i class="fa-brands fa-php fa-2x"style="font-size:70px;color:white;"></i>
                </a></div>
                 <div>
                    <a href="programming-language/python.html"><i class="fab fa-python fa-2x"style="font-size:70px;color:white;"></i>
                </a></div>
                 <div>
                    <a href="programming-language/java.html"><i class="fab fa-java fa-2x"style="font-size:70px;color:white;"></i>
                    
                </a></div>
            </div>
        </div>
    </div>

    
     <!------------------------------------->
  <br>  <br>
<section class="features">
  <div class="feature-container">
    <a href="courselogin.php">
      <img src="https://photogallerycode.netlify.app/courses.png" alt="Feature 1">
      <p>Free Courses</p>
    </a>
  </div>
  <div class="feature-container">
    <a href="project,login.php">
      <img src="https://photogallerycode.netlify.app/project.png" alt="Feature 2">
      <p>Free Projects</p>
    </a>
  </div>
  <div class="feature-container">
    <a href="noteslogin.php">
      <img src="https://photogallerycode.netlify.app/notes.jpg" alt="Feature 3">
      <p>Free Notes</p>
    </a>
  </div>
</section>

    
    
    
    
    
    
     <br><br><br><h2 class="sub-title">Important</h2><br/>
    
    <div class="page-container">
    <div class="fruit-container">
      <a href="important/TCSNQTPreviousYearsQuestion&Answers.pdf" class="card"><img src="image/TCQnqt.jpeg" alt="TCS"></a>
      <a href="important/MachineLearningCheatSheet.pdf" class="card"><img src="image/ml-INTERVIEW.jpeg" alt="Machine Learning"></a>
      <a href="important/JavaInterviewQuestions.pdf" class="card"><img src="image/JAVAinterview.jpeg" alt="Java"></a>
      <a href="important/400+JS-InterviewQuestions.pdf" class="card"><img src="image/JSinterview.jpeg" alt="JS"></a>
      <a href="important/PythonInterviewquestions.pdf" class="card"><img src="image/PYinterview.jpeg" alt="codershub"></a>
      <a href="important/TCSNQTPreviousYearsQuestion&Answers.pdf" class="card"><img src="image/TCQnqt.jpeg" alt="codershub"></a>
      <a href="important/MachineLearningCheatSheet.pdf" class="card"><img src="image/ml-INTERVIEW.jpeg" alt="codershub"></a>
      <a href="important/JavaInterviewQuestions.pdf" class="card"><img src="image/JAVAinterview.jpeg" alt="codershub"></a>
      <a href="important/400+JS-InterviewQuestions.pdf" class="card"><img src="image/JSinterview.jpeg" alt="codershub"></a>
      <a href="important/PythonInterviewquestions.pdf" class="card"><img src="image/PYinterview.jpeg" alt="codershub"></a>
      
    </div>
  </div>
  <script>
    const fruitContainer = document.getElementById("fruitContainer");
    const cards = fruitContainer.getElementsByClassName("card");

    // Clone and append cards dynamically for endless scrolling
    for (let i = 0; i < cards.length; i++) {
      fruitContainer.appendChild(cards[i].cloneNode(true));
    }
  </script>
  
  
  <br><br>
  
   
      </div>
    </div>
  </main>

  <footer>
    <div class="footer-links">
      <a href="#"><i class="fab fa-facebook-f"></i></a>
      <a href="#"><i class="fab fa-twitter"></i></a>
      <a href="#"><i class="fab fa-instagram"></i></a>
      <a href="#"><i class="fab fa-linkedin-in"></i></a>
    </div>
    <p><a2 href="About.html">About</a2> | <a2 href="Contact.html">Contact</a2></p>
    <p>&copy; 2024 CodersClub.in. All rights reserved.</p>
  </footer>
  
<script src="amagiloader.js"></script>
<script>
 AmagiLoader.show();
 setTimeout(() => {
    AmagiLoader.hide();
 }, 2000);
</script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
  <!-- Google Analytics -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-XXXXX-Y', 'auto');
ga('send', 'pageview');
</script>
<!-- End Google Analytics -->
<script>
  const element = document.querySelector('.swipe-animation');
  let touchStartX = 0;
  let touchEndX = 0;

  element.addEventListener('touchstart', (event) => {
    touchStartX = event.touches[0].clientX;
  });

  element.addEventListener('touchmove', (event) => {
    touchEndX = event.touches[0].clientX;
  });

  element.addEventListener('touchend', () => {
    const swipeThreshold = 50; // Adjust this value as needed

    if (touchEndX - touchStartX > swipeThreshold) {
      element.classList.add('swipe-animation');
    } else {
      element.classList.remove('swipe-animation');
    }
  });




</script>
</body>
</html>