<?php
session_start();
include_once('connection.php');

if (isset($_POST['login'])) {
    if (empty($_POST['username']) || empty($_POST['password'])) {
        echo "<script>alert('Please Fill Username and Password');</script>";
        exit;
    } else {
        $username = $_POST['username'];
        $password = md5($_POST['password']);

        // Use prepared statement to prevent SQL injection
        $stmt = $conn->prepare("SELECT * FROM `tbl_user` WHERE `username`=? AND `password`=?");
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION['name'] = $row['name'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['password'] = $row['password'];
            header('location: welcome.php');
            exit; // Make sure to exit after redirecting
        } else {
            echo "<script>alert('Invalid Username or Password');</script>";
            echo "<script>window.location='mainlogin.php';</script>"; // Redirect manually if header redirection fails
            exit;
        }
    }
}
?>
