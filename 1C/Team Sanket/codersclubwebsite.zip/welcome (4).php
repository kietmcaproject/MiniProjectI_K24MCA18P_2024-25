<?php
session_start();
include_once('connection.php');

// Function to generate encrypted link
function generateEncryptedLink($destination) {
    // Generate a random string for encryption
    $randomString = substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil(10/strlen($x)) )),1,10);
    // Encrypt the destination with the random string
    $encryptedLink = base64_encode($destination . "|" . $randomString);
    return $encryptedLink;
}

// Function to decrypt the link and extract the destination URL
function decryptLink($encryptedLink) {
    // Decode the encrypted link
    $decodedLink = base64_decode($encryptedLink);
    // Split the decoded link into destination URL and random string
    $parts = explode("|", $decodedLink);
    // Return the destination URL
    return $parts[0];
}

// Check if the session variables are set
if (!isset($_SESSION['name']) || !isset($_SESSION['username'])) {
    header("Location: index.php"); // Redirect to index.html if session variables are not set
    exit();
}

// Logout functionality
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php"); // Redirect to index.html after logout
    exit();
}

// Set session timeout period (in seconds)
$timeout = 600; // 10 minutes

// Check if the user's last activity time is set
if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > $timeout) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: index.php"); // Redirect to index.html after session timeout
    exit();
} else {
    // Update last activity time
    $_SESSION['last_activity'] = time();
}

// Check if the card link is clicked and the user is logged in
if (isset($_GET['link']) && isset($_SESSION['name']) && isset($_SESSION['username'])) {
    // Decrypt the link and extract the destination URL
    $destinationURL = decryptLink($_GET['link']);
    // Redirect the user to the destination URL
    header("Location: $destinationURL");
    exit();
}
?>


<!doctype html>
<html lang="en">

<head>
    <link rel="shortcut icon" href="favicon.png">
    <title>Welcome Form</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <style>
        
.navbar-text.me-3 {
    color: #333; /* Adjust text color */
    font-weight: bold; /* Make the text bold */
    background-color: #ffc107; /* Add a background color */
    padding: 5px 10px; /* Add padding to increase visibility */
    border-radius: 5px; /* Add rounded corners */
}
        .logout-btn {
    background-color: darkred;
    color: white;
    border: none;
    padding: 5px 10px; /* Adjust padding */
    border-radius: 5px; /* Add rounded corners */
    font-weight: bold;
    cursor: pointer;
}

.logout-btn:hover {
    background-color: red;
}


/* Add your feature card styling here */
        .features {
            margin-top: 100px; /* Adjust as needed */
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .feature-container {
    flex-basis: calc(33.33% - 20px); /* Three columns with margin in between */
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 20px;
    margin-bottom: 40px; /* Increase margin bottom to create more space between cards */
    transition: transform 0.3s;
}


        .feature-container:hover {
            transform: translateY(-5px);
        }

        .feature-container img {
            max-width: 75%;
            height: auto;
        }

        .feature-container p {
    color: red; /* Change text color to red */
    font-size: 25px; /* Adjust font size */
    margin-top: 10px; /* Add space between image and text */
    margin-bottom: 0; /* Remove bottom margin */
    font-weight: bold; /* Make text bold */
    font-family: Arial, sans-serif; /* Change font family */
}

.feature-container p  {
    text-decoration: none; /* Remove underline from links within the paragraph */
}
.feature-container a {
    text-decoration: none; /* Remove underline from all links within the feature container */
}
        
        .feature-container:hover p,
        .feature-container:hover h3 {
            color: #000; /* Change text color on hover */
        }

        /* Responsive adjustments */
        @media only screen and (max-width: 992px) {
            .feature-container {
                flex-basis: calc(50% - 20px); /* Two columns with margin in between for tablets */
            }
        }

        @media only screen and (max-width: 768px) {
            .feature-container {
                flex-basis: calc(50% - 20px); /* Two columns with margin in between for smaller tablets */
            }
        }

        @media only screen and (max-width: 600px) {
            .feature-container {
                flex-basis: calc(50% - 20px); /* Two columns with margin in between for small screens */
            }
        }

        @media only screen and (max-width: 500px) {
            .feature-container {
                flex-basis: calc(100% - 20px); /* Full width for extra small screens */
            }
        }

/* Media query to adjust layout for small screens */
@media (max-width: 768px) {
    .navbar-text.me-3 {
        display: block; /* Display user name on a new line */
        margin-top: 5px; /* Add some space between user name and logout button */
        padding-bottom: 5px; /* Adjust padding to align properly */
        padding-right: 10px; /* Increase padding on the right side */
    }

@media (max-width: 768px) {
    .navbar-text.me-3 {
        margin-right: 10px; /* Increase margin between username and right side */
    }

    .logout-btn {
        margin-left: 20px; /* Increase margin between username and logout button */
    }

    /* Add space between username and logout button when collapsed */
    .navbar-collapse {
        margin-top: 20px; /* Adjust as needed */
    }
}
        
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="https://thecodersclub.in/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="ContactUs.php">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="About.html">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Community</a>
                        </li>
                    </ul>
                    <span class="navbar-text me-3">
                        Welcome, <?=$_SESSION['name'];?>
                    </span>
                    <form class="d-flex" action="welcome.php" method="post">
                        <button class="logout-btn" type="submit" name="logout">Logout</button>
                    </form>
                </div>
            </div>
        </nav>
    </header>
<br>
   <section class="features">
        <div class="feature-container">
            <a href="?link=<?php echo generateEncryptedLink('courses.php'); ?>" class="feature-link">
                <img src="https://photogallerycode.netlify.app/courses.png" alt="Feature 1">
                <p>Courses</p>
            </a>
        </div>
        <div class="feature-container">
            <a href="?link=<?php echo generateEncryptedLink('project.php'); ?>" class="feature-link">
                <img src="https://photogallerycode.netlify.app/project.png" alt="Feature 2">
                <p>Projects</p>
            </a>
        </div>
        <div class="feature-container">
            <a href="?link=<?php echo generateEncryptedLink('notes.php'); ?>" class="feature-link">
                <img src="https://photogallerycode.netlify.app/notes.jpg" alt="Feature 3">
                <p>Notes</p>
            </a>
        </div>
        
    </section>

  <br>  

    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
        crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
        integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz"
        crossorigin="anonymous"></script>
</body>

</html>