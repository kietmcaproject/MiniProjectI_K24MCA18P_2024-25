<?php
session_start();
include_once('connection.php');

// Function to generate encrypted link
function generateEncryptedLink($destination) {
    // Generate a random string for encryption
    $randomString = substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil(10/strlen($x)) )),1,10);
    // Encrypt the destination with the random string
    $encryptedLink = base64_encode($destination . "|" . $randomString);
    return $encryptedLink;
}

// Function to decrypt the link and extract the destination URL
function decryptLink($encryptedLink) {
    // Decode the encrypted link
    $decodedLink = base64_decode($encryptedLink);
    // Split the decoded link into destination URL and random string
    $parts = explode("|", $decodedLink);
    // Return the destination URL
    return $parts[0];
}

// Check if the session variables are set
if (!isset($_SESSION['name']) || !isset($_SESSION['username'])) {
    header("Location: index.php"); // Redirect to index.html if session variables are not set
    exit();
}

// Logout functionality
if (isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php"); // Redirect to index.html after logout
    exit();
}

// Set session timeout period (in seconds)
$timeout = 600; // 10 minutes

// Check if the user's last activity time is set
if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > $timeout) {
    session_unset(); // Unset all session variables
    session_destroy(); // Destroy the session
    header("Location: index.php"); // Redirect to index.html after session timeout
    exit();
} else {
    // Update last activity time
    $_SESSION['last_activity'] = time();
}

// Check if the card link is clicked and the user is logged in
if (isset($_GET['link']) && isset($_SESSION['name']) && isset($_SESSION['username'])) {
    // Decrypt the link and extract the destination URL
    $destinationURL = decryptLink($_GET['link']);
    // Redirect the user to the destination URL
    header("Location: $destinationURL");
    exit();
}
?>

<!doctype html>
<html lang="en">
    <head>
<link rel="shortcut icon" href="favicon.png">

    <title>COURSES</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.1 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <style>
        /* Resetting default margin and padding */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body, html {
            margin: 0;
            padding: 0;
        }

        body > *:last-child {
            margin-bottom: 0;
        }

        /* Header styles */
        .navbar-nav .nav-link {
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .navbar-nav .nav-link:hover {
            color: #ff0000;
        }

        .logout-btn {
            background-color: darkred;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: bold;
            cursor: pointer;
            margin-left: 10px;
        }

        @media screen and (max-width: 991px) {
            .navbar-nav {
                margin-top: 10px;
            }

            .logout-btn {
                margin-left: 0;
                margin-top: 10px;
            }
        }

        .navbar-text {
            font-weight: bold;
            color: red;
            background-color: yellow;
            padding: 8px 12px;
            border-radius: 5px;
            margin-left: 10px;
        }

        @media screen and (max-width: 991px) {
            .navbar-text {
                margin-left: 0;
                margin-top: 10px;
            }
        }

        /* Feature card styles */
        .features {
            margin-top: 100px;
            margin-bottom: 150px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .feature-container {
            flex-basis: calc(33.33% - 20px);
            text-align: center;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 7px;
            margin-bottom: 30px;
            transition: transform 0.3s;
        }

        .feature-container:hover {
            transform: translateY(-5px);
        }

        .feature-container img {
            max-width: 75%;
            height: auto;
        }

        .feature-container p {
            color: #333;
            font-size: 18px;
            margin-top: 10px;
            margin-bottom: 0;
        }

        .feature-container h3 {
            color: #555;
            font-size: 24px;
            margin-bottom: 10px;
            font-weight: bold;
        }

        .feature-container:hover p,
        .feature-container:hover h3 {
            color: #000;
        }

        @media only screen and (max-width: 992px) {
            .feature-container {
                flex-basis: calc(50% - 20px);
            }
        }

        @media only screen and (max-width: 768px) {
            .feature-container {
                flex-basis: calc(50% - 20px);
            }
        }

        @media only screen and (max-width: 600px) {
            .feature-container {
                flex-basis: calc(50% - 20px);
            }
        }

        @media only screen and (max-width: 500px) {
            .feature-container {
                flex-basis: calc(100% - 20px);
            }
        }

        /* Footer styles */
        
        .footer {
            background-color: #0f52ba;
            padding: 50px 0;
            color: white; /* Adjusted text color */
            margin-bottom: 0; /* Remove bottom margin */
        }

        .footer h5 {
            font-size: 18px;
            margin-bottom: 20px;
        }

        .footer ul {
            list-style: none;
            padding: 0;
        }

        .footer ul li {
            margin-bottom: 10px;
        }

        .footer ul li a {
            color: #666;
            text-decoration: none;
        }

        .footer ul li a:hover {
            color: red;
            text-decoration: underline;
        }

        .footer .list-unstyled li a i {
            margin-right: 5px;
            font-size: 18px;
        }

        .footer .list-unstyled li a {
            color: white;
            text-decoration: none;
        }

        .footer .list-unstyled li a:hover {
            color: red;
            text-decoration: underline;
        }

        .navbar-nav .nav-link {
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .navbar-nav .nav-link:hover {
            color: #ff0000;
        }
    </style>
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="https://thecodersclub.in/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="notes.php">Notes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="project.php">Projects</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="ContactUs.php">Contact</a>
                        </li>
                    </ul>
                    <span class="navbar-text me-3">
                        Welcome, <?=$_SESSION['name'];?>
                    </span>
                    <form class="d-flex" action="welcome.php" method="post">
                        <button class="logout-btn" type="submit" name="logout">Logout</button>
                    </form>
                </div>
            </div>
        </nav>
    </header>

    <div class="main-content">
        <section class="features">
            
            <div class="feature-container">
                <a href="course/intro-python.php" > 
                    <img src="https://thecodersclub.in/image/py.jpg" e/alt="Feature 2">
                </a>
            </div>
            <div class="feature-container">
                <a href="course/java.php" > 
                    <img src="https://thecodersclub.in/image/java.jpg" alt="Feature 2">
                </a>
            </div>
            <div class="feature-container">
                <a href="course/react.php" > 
                    <img src="https://thecodersclub.in/image/reactcourse.jpeg" alt="Feature 2">
                </a>
            </div>
            <div class="feature-container">
                <a href="course/C-program.php" > 
                    <img src="https://thecodersclub.in/image/c-course.jpeg" alt="Feature 2">
                </a>
            </div>
            <div class="feature-container">
                <a href="course/php.php" > 
                    <img src="https://thecodersclub.in/image/php-course.jpeg" alt="Feature 2">
                </a>
            </div>
            <div class="feature-container">
                <a href="course/javascript.php" > 
                    <img src="https://thecodersclub.in/image/js-course2.jpeg" alt="Feature 2">
                </a>
            </div>
        </section>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>About</h5>
                    <p>codersclub.in.</p>
                </div>
                <div class="col-md-3">
                    <h5>Navigation</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Community</a></li>
                        <li><a href="#">About</a></li>
                        <li><a href="#">Location</a></li>
                        <li><a href="#"><i class="bi bi-envelope"></i> Email</a></li>
                    </ul>
                </div>
                <div class="col-md-3">
                    <h5>Follow Us</h5>
                    <ul class="list-unstyled">
                        <li><a href="#"><i class="bi bi-facebook"></i> Facebook</a></li>
                        <li><a href="#"><i class="bi bi-twitter"></i> Twitter</a></li>
                        <li><a href="#"><i class="bi bi-instagram"></i> Instagram</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JavaScript Libraries -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
        crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
        integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz"
        crossorigin="anonymous"></script>

   
</body>

</html>
