const mongoose=require("mongoose");
const objectID=mongoose.Types.ObjectId;
const Schema=mongoose.Schema;
// mongoose.connect("mongodb+srv://rishifishyy:ps4ps4ps5@cluster0.016wr.mongodb.net/Course_selling");


const userSchema=new Schema({
  email:{type:String,unique:true },
  password:String,
  firstname:String,
  lastname:String
});

const adminSchema=new Schema({
  email:{type:String,unique:true },
  password:String,
  firstname:String,
  lastname:String

});
const courseSchema=new Schema({
  title:String,
  description:String,
  price: Number,
  imageURL: String,
  creatorID:objectID

});
const purchasecSchema=new Schema({
  userID:objectID,
  courseID:objectID

});
const userModel= mongoose.model("user",userSchema); 
const adminModel=mongoose.model("admin",adminSchema);
const courseModel=mongoose.model("course",courseSchema);
const purchaseModel=mongoose.model("purchase",purchasecSchema);

module.exports={
  userModel,adminModel,courseModel,purchaseModel
}