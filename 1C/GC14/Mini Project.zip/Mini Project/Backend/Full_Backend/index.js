require('dotenv').config()
console.log(process.env.Mongo_URL);

const express=require("express");
const mongoose=require("mongoose");
// mongoose.connect("mongodb+srv://rishifishyy:ps4ps4ps5@cluster0.016wr.mongodb.net/Course_selling");
const jwt=require("jsonwebtoken");
const User_JWT="FISHYY";
const app=express();
const {adminRouter}=require("./routes/admin");
const {userRouter}=require("./routes/user");
const {courseRouter}=require("./routes/course");



app.use(express.json());
app.use("/user",userRouter);
app.use("/admin",adminRouter);
async function main(){
   await mongoose.connect(process.env.Mongo_URL);
 app.listen(3000);
console.log("Connected to the database");
}
main();
