const {User_JWT}= require("../config");
const jwt=require("jsonwebtoken");
function userMiddleware(res,req,next){
  const token=req.headers.token;
  const decoded=jwt.verify(token,User_JWT);
  if(!decoded){
    res.status(403).json({
      message:"Incorrect Credentials"
    })
    return
  }
  req.userId=decoded.id;
  next();

  // here we will be calling the next func


}

module.exports=({
  userMiddleware:userMiddleware 
})