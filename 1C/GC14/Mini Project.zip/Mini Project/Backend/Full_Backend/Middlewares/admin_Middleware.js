const {User_JWT}= require("../config");
const jwt=require("jsonwebtoken");
function adminMiddleware(res,req,next){
  const token=req.headers.token;
  const decoded=jwt.verify(token,Admin_JWT);
  if(!decoded){
    res.json({
      message:"Incorrect Credentials"
    })
    return
  }
  req.userId=decoded.id;
  next();


}

module.exports=({
  adminMiddleware:adminMiddleware 
})