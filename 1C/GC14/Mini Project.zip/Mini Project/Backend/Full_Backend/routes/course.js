const {courseModel}= require("../db");
const {Router} =require("express");
const courseRouter=Router();






module.exports={
  courseRouter:courseRouter
}
