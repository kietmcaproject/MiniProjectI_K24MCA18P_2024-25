const {Router}=require("express");   
const {adminModel, courseModel}=require("../db");
const adminRouter=Router();
const bcrypt =require("bcrypt");
const jwt=require("jsonwebtoken");
const Admin_JWT="RISHI";
const{adminMiddleware}=require("../Middlewares/admin_Middleware");
// function auth(req,res){
//   const email=req.body.email;
//   const password=req.body.password;
//   const hashshedPass=
 

// }
adminRouter.post("/signup",async(req,res)=>{
  const {email,password,firstname,lastname}=req.body;
  const hashedPassword=await bcrypt.hash(password,5);
  await adminModel.create({
   email:email,
   password:hashedPassword,
   firstname:firstname,
   lastname:lastname
 })
 res.json({
   message:"Signed up successfully"
 })

})
adminRouter.post("/signin",async(req,res)=>{
  const{email,password}=req.body;

  const foundUser=await adminModel.findOne({
    email:email,
  
     
  })
  if(!foundUser){
    res.json({
      message:"Sorry lil bro you will not be able to hack us this time"
    })
    return;
  }
  
    const passwordMatch=await bcrypt.compare(password,foundUser.password);
    if(!passwordMatch){
      res.json({
        message:"Log in failed"
      })
    return
    }
const token=jwt.sign({
  id:foundUser._id.toString
},Admin_JWT);
res.json({
  id:token
})
})
adminRouter.post("/createCourse",(req,res)=>{
  res.json({
    message:"This page is used for creating new courses"
  })
})

adminRouter.get("/courses",adminMiddleware,async()=>{
  const {title,description,price,imageURL,creatorID }=req.body;
  const course=await courseModel.create({
    title,description,price,imageURL,creatorID:adminID
  })
  res.json({
    message:"Course created successfully",
    courseID:course._id
  })
})

adminRouter.put("/course",adminMiddleware,(req,res)=>{
       const{adminID}=req.body;
       



})
module.exports={
  adminRouter:adminRouter
}