const {userModel}= require("../db");
const {Router} =require("express");
const userRouter=Router();
const bcrypt =require("bcrypt");
const jwt=require("jsonwebtoken");
const User_JWT="FISHYY";


userRouter.post("/signup",async(req,res)=>{ 
  // const email=req.body.email;
  // or we can destructure
  const {email,password,firstname,lastname}=req.body;
  const hashedPassword=await bcrypt.hash(password,5);
   await userModel.create({
    email:email,
    password:hashedPassword,
    firstname:firstname,
    lastname:lastname
  })
  res.json({
    message:"Signed up successfully"
  })

});
userRouter.post("/signin",async(req,res)=>{
  const{email,password}=req.body;

  const foundUser=await userModel.findOne({
    email:email,
  
     
  })
  if(!foundUser){
    res.json({
      message:"Sorry lil bro you will not be able to hack us this time"
    })
    return;
  }
  
    const passwordMatch=await bcrypt.compare(password,foundUser.password);
    if(!passwordMatch){
      res.json({
        message:"Log in failed"
      })
    return
    }
const token=jwt.sign({
  id:foundUser._id.toString
},User_JWT);
res.json({
  id:token
})
});
userRouter.get("/courses",(req,res)=>{
  res.json({message:"Courses purchased by the user"});
})

module.exports={
  userRouter:userRouter
}
