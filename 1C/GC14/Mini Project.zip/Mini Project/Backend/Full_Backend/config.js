const User_JWT="FISHYY";
const Admin_JWT="RISHI";
module.exports=({
  User_JWT,Admin_JWT
})

