from django.core.paginator import Paginator
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
import requests
import re
from django.core.cache import cache
import json
import random
from .models import Book, ReadingHistory, UserBookmark
from .forms import RegisterForm

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'books/login.html', {'error': 'Invalid username or password'})
    
    return render(request, 'books/login.html')

def user_logout(request):
    logout(request)
    return redirect('home')

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'books/register.html', {'form': form})

def fetch_books_from_gutenberg(page_number=1, search_query="", category=None):
    cache_key = f"gutenberg_books_{page_number}_{search_query}_{category}"
    cached_data = cache.get(cache_key)

    if cached_data:
        return cached_data

    url = f"https://gutendex.com/books/?page={page_number}"
    if search_query:
        url += f"&search={search_query}"
    if category:
        url += f"&topic={category}"

    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        books = [
            {
                'id': f"gutenberg-{item['id']}",
                'title': item['title'],
                'authors': [author['name'] for author in item['authors']],
                'cover_url': item['formats'].get('image/jpeg', ''),
                'download_url': item['formats'].get('text/plain', '')
            }
            for item in data.get('results', [])
        ]
        cache.set(cache_key, (books, data.get('count', 0)), timeout=3600)
        return books, data.get('count', 0)
    except Exception as e:
        print(f"API error: {e}")
        return [], 0

def fetch_book_details(book_id):
    """Fetch detailed information about a book from Gutendex API"""
    cache_key = f"gutenberg_book_details_{book_id}"
    cached_data = cache.get(cache_key)

    if cached_data:
        return cached_data

    try:
        url = f"https://gutendex.com/books/{book_id}"
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

        book_details = {
            'title': data.get('title', 'Unknown Title'),
            'authors': ', '.join([author.get('name', 'Unknown Author') 
                                for author in data.get('authors', [])]),
            'cover_url': data.get('formats', {}).get('image/jpeg', ''),
            'download_url': data.get('formats', {}).get('text/plain', '')
        }

        cache.set(cache_key, book_details, timeout=86400)
        return book_details

    except Exception as e:
        print(f"Error fetching book details: {e}")
        return {
            'title': 'Unknown Title',
            'authors': 'Unknown Author',
            'cover_url': '',
            'download_url': ''
        }

def fetch_book_content(book_id):
    cache_key = f"gutenberg_content_{book_id}"
    cached_content = cache.get(cache_key)

    if cached_content:
        return cached_content

    try:
        urls = [
            f"https://www.gutenberg.org/files/{book_id}/{book_id}-0.txt",
            f"https://www.gutenberg.org/cache/epub/{book_id}/pg{book_id}.txt",
            f"https://www.gutenberg.org/ebooks/{book_id}.txt.utf-8"
        ]

        content = None
        for url in urls:
            try:
                response = requests.get(url)
                if response.status_code == 200:
                    content = response.text
                    break
            except:
                continue

        if content:
            # Process content
            start_marker = "*** START OF THIS PROJECT GUTENBERG"
            end_marker = "*** END OF THIS PROJECT GUTENBERG"
            
            if start_marker in content:
                content = content.split(start_marker)[1]
            if end_marker in content:
                content = content.split(end_marker)[0]
            
            content = content.strip()
            cache.set(cache_key, content, timeout=86400)
            return content
            
        return ""
    except Exception as e:
        print(f"Error fetching book content: {e}")
        return ""

@login_required
def book_detail(request, book_id):
    if not book_id.startswith("gutenberg-"):
        return render(request, 'books/book_detail.html', {"error": "Invalid book ID"})

    try:
        gutenberg_id = book_id.split("-")[1]
        
        # Fetch book details
        book_details = fetch_book_details(gutenberg_id)
        
        # Get or create book in database
        book, created = Book.objects.get_or_create(
            gutenberg_id=gutenberg_id,
            defaults={
                'title': book_details['title'],
                'authors': book_details['authors'],
                'cover_url': book_details['cover_url'],
                'category': 'Fiction'
            }
        )

        # Fetch book content
        content = fetch_book_content(gutenberg_id)
        if not content:
            return render(request, 'books/book_detail.html', {'error': 'Book content not available'})

        # Pagination
        page_size = 1500
        pages = [content[i:i + page_size] for i in range(0, len(content), page_size)]
        current_page = int(request.GET.get('page', 1))
        paginator = Paginator(pages, 1)
        page_obj = paginator.get_page(current_page)

        # Calculate analytics
        words = len(content.split())
        sentences = len(content.split('.'))
        analytics = {
            'words': words,
            'reading_time': words // 200,  # Assuming 200 words per minute
            'complexity_score': round(words / max(sentences, 1), 2)
        }

        # Update reading history
        if request.user.is_authenticated:
            reading_history, _ = ReadingHistory.objects.get_or_create(
                user=request.user,
                book=book,
                defaults={'current_page': current_page}
            )
            if reading_history.current_page != current_page:
                reading_history.current_page = current_page
                reading_history.save()

        # Get bookmarks
        bookmarks = UserBookmark.objects.filter(
            user=request.user,
            book=book
        ).order_by('page_number')

        # Get similar books
        similar_books, _ = fetch_books_from_gutenberg(category='Fiction', page_number=1)
        similar_books = [b for b in similar_books if b['id'] != book_id][:4]

        context = {
            'book': {
                'id': book_id,
                'title': book.title,
                'authors': book.authors,
                'cover_url': book.cover_url,
                'analytics': analytics,
                'pages': {
                    'object_list': [page_obj.object_list[0]] if page_obj else []
                }
            },
            'content': page_obj.object_list[0] if page_obj else None,
            'reading_progress': {
                'current': current_page,
                'total': len(pages),
                'percentage': (current_page / len(pages) * 100) if pages else 0
            },
            'has_next': page_obj.has_next(),
            'has_previous': page_obj.has_previous(),
            'next_page': current_page + 1 if page_obj.has_next() else None,
            'prev_page': current_page - 1 if page_obj.has_previous() else None,
            'bookmarks': bookmarks,
            'similar_books': similar_books
        }

        return render(request, 'books/book_detail.html', context)

    except Exception as e:
        print(f"Error in book_detail: {str(e)}")
        return render(request, 'books/book_detail.html', {"error": f"Failed to load book: {str(e)}"})


    except Exception as e:
        print(f"Error in book_detail: {e}")
        return render(request, 'books/book_detail.html', {"error": f"Failed to load book: {str(e)}"})

def home(request):
    selected_category = request.GET.get('category', '')
    search_query = request.GET.get('q', '')
    
    if search_query:
        books, _ = fetch_books_from_gutenberg(search_query=search_query)
        categories = {"Search Results": books}
    elif selected_category:
        books, _ = fetch_books_from_gutenberg(category=selected_category)
        categories = {selected_category: books}
    else:
        categories = {
            "Fiction": fetch_books_from_gutenberg(category="Fiction")[0],
            "Romance": fetch_books_from_gutenberg(category="Romance")[0],
            "Drama": fetch_books_from_gutenberg(category="Drama")[0],
            "Adventure": fetch_books_from_gutenberg(category="Adventure")[0]
        }

    context = {
        'categories': categories,
        'search_query': search_query,
        'selected_category': selected_category,
    }

    if request.user.is_authenticated:
        reading_history = ReadingHistory.objects.filter(
            user=request.user
        ).select_related('book').order_by('-last_read')[:4]
        
        context.update({
            'reading_history': reading_history,
            'reading_history_count': ReadingHistory.objects.filter(user=request.user).count()
        })

    return render(request, 'books/home.html', context)




@login_required
@csrf_exempt
def add_bookmark(request, book_id):
    try:
        book = get_object_or_404(Book, gutenberg_id=book_id.split('-')[1])
        data = json.loads(request.body)
        
        bookmark = UserBookmark.objects.create(
            user=request.user,
            book=book,
            page_number=data.get('page_number'),
            note=data.get('note', '')
        )
        
        return JsonResponse({'status': 'success'})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def get_reading_history(request):
    history = ReadingHistory.objects.filter(
        user=request.user
    ).select_related('book').order_by('-last_read')[:5]
    
    return JsonResponse({
        'history': [{
            'book_id': h.book.gutenberg_id,
            'title': h.book.title,
            'cover_url': h.book.cover_url,
            'current_page': h.current_page,
            'last_read': h.last_read.strftime('%Y-%m-%d %H:%M:%S')
        } for h in history]
    })
