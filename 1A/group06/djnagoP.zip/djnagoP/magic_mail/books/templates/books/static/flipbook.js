// References to DOM elements
const prevBtn = document.querySelector("#prev-btn");
const nextBtn = document.querySelector("#next-btn");
const book = document.querySelector("#book");

// Get all paper elements
const papers = document.querySelectorAll(".paper");

// State Variables
let currentLocation = 1; // The current page
const numOfPapers = papers.length; // Total number of pages
const maxLocation = numOfPapers + 1; // Total locations (pages + covers)

// Event Listeners
prevBtn.addEventListener("click", goPrevPage);
nextBtn.addEventListener("click", goNextPage);

// Functions
function goNextPage() {
    if (currentLocation < maxLocation) {
        papers[currentLocation - 1].classList.add("flipped");
        currentLocation++;
    }
}

function goPrevPage() {
    if (currentLocation > 1) {
        papers[currentLocation - 2].classList.remove("flipped");
        currentLocation--;
    }
}
