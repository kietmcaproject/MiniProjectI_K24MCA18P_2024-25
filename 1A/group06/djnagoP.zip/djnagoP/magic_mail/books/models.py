from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class Book(models.Model):
    gutenberg_id = models.CharField(max_length=100, unique=True)
    title = models.CharField(max_length=255)
    authors = models.CharField(max_length=255)
    cover_url = models.URLField(max_length=500)
    category = models.CharField(max_length=100)
    total_views = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class ReadingHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    current_page = models.IntegerField(default=1)
    last_read = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-last_read']

    def __str__(self):
        return f"{self.user.username} - {self.book.title}"

class UserBookmark(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    page_number = models.IntegerField()
    note = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['page_number']
