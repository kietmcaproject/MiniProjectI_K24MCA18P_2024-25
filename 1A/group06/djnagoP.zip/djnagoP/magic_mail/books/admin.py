from django.contrib import admin
from .models import Book, ReadingHistory, UserBookmark

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'authors', 'category', 'total_views')
    search_fields = ('title', 'authors')

@admin.register(ReadingHistory)
class ReadingHistoryAdmin(admin.ModelAdmin):
    list_display = ('user', 'book', 'current_page', 'last_read')
    list_filter = ('user', 'last_read')

@admin.register(UserBookmark)
class UserBookmarkAdmin(admin.ModelAdmin):
    list_display = ('user', 'book', 'page_number', 'created_at')
    list_filter = ('user', 'created_at')
