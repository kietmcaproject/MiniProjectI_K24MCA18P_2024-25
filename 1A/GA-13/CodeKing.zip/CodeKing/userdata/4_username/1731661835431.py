import pyautogui as pg
import time

arr = [
    '''I brush my teeth before I go to bed.\tI came home in the morning after working the whole night.\tYou should brush your teeth after you wake up.\tThe bus left before I could get in.'''
]

time.sleep(3)
for i in range(1):
    a = arr[i]  # Removed the semicolon
    pg.write(a)
    # pg.press('tab')
