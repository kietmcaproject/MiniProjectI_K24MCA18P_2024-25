const apiKey = "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"; // Replace with your actual API key
const apiUrl = "https://api.openai.com/v1/chat/completions";

let count = 0; // Tracks the current question index
const Questions = [
  "Do you work well with other people?",
  "Tell me about yourself.",
  "How would you describe yourself?",
  "How would your co-workers describe your personality?",
  "What major challenges and problems have you faced? How did you handle them?",
  "Describe a difficult work situation/project and how you overcame it.",
  "What have you learned from your mistakes?",
  "What was it like working for your supervisor?",
  "What do you expect from a supervisor?",
  "Have you ever had difficulty working with a manager?",
  "How do you handle stress and pressure?",
  "What has been the greatest disappointment in your life?",
  "What are you passionate about?",
  "What do people most often criticize about you?",
  "When was the last time you were angry? What happened?",
  "Do you prefer to work independently or on a team?",
  "Give some examples of your teamwork in completing a critical project.",
  "Why are you the best person for the job?",
  "Why do you want to work here?",
  "What can you contribute to this company?"
];

// Fetch OpenAI API Response
function onReturn(input) {
  const conversation = [
    { role: "system", content: "You are a helpful assistant." },
    {
      role: "user",
      content: `Provide feedback for the response "${input}" to the question "${Questions[count]}". Analyze the sentiment and suggest improvements in 80 words.`,
    },
  ];

  fetch(apiUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: conversation,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      const botReply = data.choices[0].message.content;

      // Display bot's response
      getHardResponse(botReply);

      // Ask the next question
      count++;
      if (count < Questions.length) {
        AskQuery(Questions[count]);
      } else {
        AskQuery("Thank you for completing the session!");
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      getHardResponse("I'm having trouble connecting to the server. Please try again later.");
    });
}
