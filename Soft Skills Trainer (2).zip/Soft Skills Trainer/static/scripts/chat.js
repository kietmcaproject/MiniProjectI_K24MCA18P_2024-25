// Collapsible Functionality
var coll = document.getElementsByClassName("collapsible");
var tryNowButton = document.getElementById("try-now");

for (let i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function () {
    this.classList.toggle("active");
    var content = this.nextElementSibling;

    if (content.style.maxHeight) {
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = content.scrollHeight + "px";
    }
  });
}

if (tryNowButton) {
  tryNowButton.addEventListener("click", function () {
    if (coll.length > 0) {
      coll[0].click();
    }
  });
}

// Utility Function to Get Current Time
function getTime() {
  let today = new Date();
  let hours = today.getHours();
  let minutes = today.getMinutes();

  hours = hours < 10 ? "0" + hours : hours;
  minutes = minutes < 10 ? "0" + minutes : minutes;

  return `${hours}:${minutes}`;
}

// Display the First Bot Message
function firstBotMessage() {
  let firstMessage = "Do you work well with other people?";
  document.getElementById("botStarterMessage").innerHTML =
    `<p class="botText"><span>${firstMessage}</span></p>`;

  let time = getTime();
  $("#chat-timestamp").append(time);
  document.getElementById("userInput").scrollIntoView(false);
  updateProgress();
}

// Update Progress Display
function updateProgress() {
  const progressElement = document.getElementById("progress");
  if (progressElement) {
    progressElement.innerText = `Question ${count + 1} of ${Questions.length}`;
  }
}

// Add New Query to the Chatbox
function AskQuery(query) {
  let botHtml = `<p class="botText"><span>${query}</span></p>`;
  $("#chatbox").append(botHtml);
  document.getElementById("chat-bar-bottom").scrollIntoView(true);
}

// Simulate Typing Animation
function showTyping() {
  let typingHtml = `<p class="botText"><span>...</span></p>`;
  $("#chatbox").append(typingHtml);
  document.getElementById("chat-bar-bottom").scrollIntoView(true);
}

// Append Bot Responses
function getHardResponse(response) {
  let botHtml = `<p class="botText"><span>${response}</span></p>`;
  $("#chatbox").append(botHtml);
  document.getElementById("chat-bar-bottom").scrollIntoView(true);
}

// Append User Response and Send to API
function getResponse() {
  let userText = $("#textInput").val();

  if (userText === "") {
    userText = "Please provide a valid response!";
  }

  let userHtml = `<p class="userText"><span>${userText}</span></p>`;
  $("#textInput").val("");
  $("#chatbox").append(userHtml);
  document.getElementById("chat-bar-bottom").scrollIntoView(true);

  showTyping();
  onReturn(userText); // Send the response to the API via responses.js
  updateProgress();
}

// Attach Events for Sending Messages
function sendButton() {
  getResponse();
}

$("#textInput").keypress(function (e) {
  if (e.which === 13) {
    getResponse();
  }
});

// Clear Chat
document.getElementById("clear-chat").addEventListener("click", () => {
  $("#chatbox").html("");
  count = 0;
  firstBotMessage();
});

// Start the Bot Interaction
firstBotMessage();
