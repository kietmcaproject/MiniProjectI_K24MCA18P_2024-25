
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   
    <!DOCTYPE html>
    <html lang="en">
    
    <head>
        <meta charset="utf-8">
        <title>Signup</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">
    
        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">
    
        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
        
        <!-- Icon Font Stylesheet -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    
        <!-- Libraries Stylesheet -->
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
        <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />
    
        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
    
        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
        <link href="assets/css/main.css" rel="stylesheet">
        <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Inter:wght@100;200;300;400;500;600;700;800;900&family=Nunito:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    </head>
    <?php
    include 'api/config.php';
    if(isset($_POST['mob']))
    {
        $sql="INSERT into users(name,dob,mob,pwd) VALUES ('".$_POST['name']."','".$_POST['dob']."','".$_POST['mob']."','".$_POST['pwd']."') ";
        if ($conn->query($sql) === TRUE) {
            echo "<script>location.href='live_test/live.php';</script>";
            // echo "New records created successfully";
          } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
          }
          
          $conn->close();
    }
    ?>
    <section id="hero" class="hero section">
    <div class="hero-bg">
        <img src="assets/img/108265.jpg" alt="">
      </div>
   <!-- Sign Up start -->
   <div class="container text-center">
    <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
        <div class="col-12 col-sm-8 col-md-6 col-lg-5 col-xl-5">
            <div class="bg-light rounded p-4 p-sm-5 my-4 mx-3">
                <div class="d-flex align-items-center justify-content-between mb-3">
                    <img src="assets/img/maze (2).png" alt="logo" height="" width="150px" style="border-radius: 50%;">
                    <h3 style=" text-align: center;" >Sign Up</h3>
                </div>
                <form method="POST" onsubmit="return validateForm()">

                    <div class="form-floating mb-3">
                        <input type="text" class="form-control" id="floatingInput" placeholder="Enter Name" name="name" required>
                        <label for="floatingInput">Enter Name </label>
                    </div>
                    <div class="form-floating mb-3">
                        <input type="date" class="form-control" id="floatingInput" placeholder="Enter DOB" name="dob" required>
                        <label for="floatingInput">Enter DOB</label>
                    </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingInput" placeholder="Enter Mobile" name="mob" required>
                    <label for="floatingInput">Enter Mobile </label>
                </div>
              <div class="form-floating mb-4">
    <input type="password" class="form-control" id="password" placeholder="Password" name="pwd" required oninput="checkPasswordStrength()">
    <label for="password">Password</label>
    <div id="password-strength" class="mt-2 text-muted">Password strength: <span id="strength-level">Weak</span></div>
</div>

               <div class="form-floating mb-4">
    <input type="password" class="form-control" id="confirmPassword" placeholder="Confirm Password" name="cpwd" required oninput="checkPasswordMatch()">
    <label for="confirmPassword">Confirm Password</label>
    <div id="password-match" class="mt-2 text-muted"></div>
</div>

                <button type="submit" class="btn btn-primary py-3 w-100 mb-4" name="submit">Sign Up</button>
                <p class="text-center mb-0">Already have an Account? <a href="login.php">Log In</a></p>
                <a class=" btn btn-primary btn-getstarted " href="home.html">Home</a>
            </form>
            </div>
        </div>
    </div>
</section>
<!-- Sign up end -->
   <!-- JavaScript Libraries -->
   <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
   <script src="lib/chart/chart.min.js"></script>
   <script src="lib/easing/easing.min.js"></script>
   <script src="lib/waypoints/waypoints.min.js"></script>
   <script src="lib/owlcarousel/owl.carousel.min.js"></script>
   <script src="lib/tempusdominus/js/moment.min.js"></script>
   <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
   <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

 <script>
   
function validateForm() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return false;
    }
    return true;
}


function checkPasswordStrength() {
    const strengthElement = document.getElementById('strength-level');
    const password = document.getElementById('password').value;
    let strength = 'Weak';

    const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/;
    const mediumPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/;

    if (strongPasswordRegex.test(password)) {
        strength = 'Strong';
        strengthElement.style.color = 'green';
    } else if (mediumPasswordRegex.test(password)) {
        strength = 'Medium';
        strengthElement.style.color = 'orange';
    } else {
        strength = 'Weak';
        strengthElement.style.color = 'red';
    }

    strengthElement.textContent = strength;
}

function checkPasswordMatch() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const matchElement = document.getElementById('password-match');

    if (confirmPassword === '') {
        matchElement.textContent = '';
    } else if (password === confirmPassword) {
        matchElement.textContent = 'Passwords match!';
        matchElement.style.color = 'green';
    } else {
        matchElement.textContent = 'Passwords do not match.';
        matchElement.style.color = 'red';
    }
}
</script>


   <script src="js/main.js"></script>
</body>

</html>
</body>
</html>