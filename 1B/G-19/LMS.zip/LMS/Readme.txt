How to run this Library Management System Project

1. Download and Unzip file on your local system copy library.
2. Put library folder inside�root directory

Database Configuration

Open phpmyadmin
Create Database�library
Import database library.sql (available inside zip package)

For User

Open Your browser put inside browser �http://localhost/lms/library�
Login Details for user:�
Username: test@gmail.com
Password: Test@123

For Admin Panel

Open Your browser put inside browser �http://localhost/lms/library/admin�
Login Details for admin :�
Username: admin
Password:Test@123


For More Details --- Kartik Agarwal---kartik.2426mca1671@kiet.edu
                     Manish Pandey---manish.2426mca1674@kiet.edu