module.exports={
    mongourl:'mongodb+srv://harsh844988:lJwIwkKmX732RG55@cluster0.zgv4j.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',
    jwtsensitive:'meqffvgrvgfvfvfvf'

}