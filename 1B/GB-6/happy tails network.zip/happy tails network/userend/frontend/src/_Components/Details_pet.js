// import React from 'react'
import {useParams} from 'react-router-dom';
import {useEffect,useState}  from 'react';
import ('./Css/Details_pet.css')

function Details_pet() {
  const {pet_id} = useParams();
  const [petData, setPetData] = useState(null);
  const [loading, setloading] = useState(true);
  const [error, setError] = useState(null);
 

  useEffect(()=>{
    fetch(`http://localhost:5000/getdetails/${pet_id}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    })
    .then((res)=>{
      if(!res.ok)
      {
        throw new Error(`Error: ${res.status}`);
      }
      return res.json();
    })
    .then((data)=>{
      setPetData(data);
      setloading(false);
    })
    .catch((err)=>{
      setError(err.message);
      setloading(false);
    })
  },[pet_id]);

if(loading) return <p>Loading pet details.... </p>;
if(error) return <p>error</p>;
if(!petData) return <p>pet not found.</p>;


return (
  <div className="pet-details-frame">
      <div className="pet-image-section">
          <img src={petData.image} alt={petData.name} className="pet-details-image" />
      </div>
      <div className="pet-info-section">
          <h2 className="pet-name">{petData.name}</h2>
          <p><strong>Gender:</strong> {petData.gender}</p>
          <p><strong>Age:</strong> {petData.age}</p>
          <p><strong>Location:</strong> {petData.location}</p>
          <p><strong>Breed:</strong> {petData.breed}</p>
          <p><strong>Vaccinated:</strong> {petData.vaccinated ? 'Yes' : 'No'}</p>
          <p><strong>Category:</strong> {petData.category}</p>
          <button className="adopt-button">Proceed to Adopt</button>
      </div>
  </div>
);
}
export default Details_pet