'use client'

import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import Image from 'next/image'
import { useCart } from '../contexts/CartContext'
import { ShoppingCart } from 'lucide-react'

const products = [
  { id: 1, name: "Rainbow Pencil Set", price: 5.99, image: "/11.png?height=200&width=200" },
  { id: 2, name: "Unicorn Notebook", price: 4.99, image: "/12.png.jpg?height=200&width=200" },
  { id: 3, name: "Dinosaur Eraser Pack", price: 3.99, image: "/13.png.jpg?height=200&width=200" },
  { id: 4, name: "Space Rocket Pencil Case", price: 7.99, image: "/14.png.jpg?height=200&width=200" },
]

export default function FeaturedProducts() {
  const { addToCart } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (product: typeof products[0]) => {
    addToCart(product)
    toast({
      title: "Added to cart!",
      description: `${product.name} has been added to your basket.`,
    })
  }

  return (
    <section className="py-12 px-4 bg-gradient-to-b from-secondary/30 to-primary/30">
      <div className="container mx-auto">
        <h2 className="text-3xl font-bold text-center text-primary mb-8 animate-float">Our Super Cool Products!</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="bg-white rounded-lg shadow-lg overflow-hidden transform transition-all hover:scale-105 hover:shadow-xl">
              <CardHeader className="p-0">
                <Image 
                  src={product.image} 
                  alt={product.name} 
                  width={200} 
                  height={200}
                  className="w-full h-48 object-cover"
                />
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-xl font-bold text-primary">{product.name}</CardTitle>
                <p className="text-accent font-bold mt-2">${product.price.toFixed(2)}</p>
              </CardContent>
              <CardFooter className="p-4">
                <Button 
                  className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground font-bold py-2 px-4 rounded-full flex items-center justify-center gap-2"
                  onClick={() => handleAddToCart(product)}
                >
                  <ShoppingCart className="h-5 w-5" />
                  Add to Basket
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

