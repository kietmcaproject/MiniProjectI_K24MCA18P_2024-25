import { Button } from "@/components/ui/button"
import Image from 'next/image'

export default function Hero() {
  return (
    <section className="py-12 px-4">
      <div className="container mx-auto flex flex-col md:flex-row items-center">
        <div className="md:w-1/2 mb-8 md:mb-0">
          <h1 className="text-4xl md:text-6xl font-bold text-purple-700 mb-4">Welcome to KiddieDoodle!</h1>
          <p className="text-xl text-purple-600 mb-6">Discover amazing stationery that will make learning super fun!</p>
          <Button className="bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-6 rounded-full text-lg">
            Start Shopping Now!
          </Button>
        </div>
        <div className="md:w-1/2">
          <Image 
            src="/heads.png" 
            alt="Happy kids with stationery" 
            width={400} 
            height={400}
            className="rounded-lg shadow-lg"
          />
        </div>
      </div>
    </section>
  )
}

