'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const colors = ['red', 'blue', 'green', 'yellow', 'purple', 'orange']

export default function ColoringGame() {
  const [currentColor, setCurrentColor] = useState(colors[0])
  const [coloredAreas, setColoredAreas] = useState<{ [key: number]: string }>({})

  const handleColorChange = (color: string) => {
    setCurrentColor(color)
  }

  const handleAreaClick = (areaId: number) => {
    setColoredAreas(prev => ({
      ...prev,
      [areaId]: currentColor
    }))
  }

  return (
    <Card className="w-full max-w-lg mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-primary">Magic Coloring Game</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-3 gap-2 mb-4">
          {[...Array(9)].map((_, index) => (
            <div
              key={index}
              className="w-full pt-[100%] relative cursor-pointer"
              style={{ backgroundColor: coloredAreas[index] || 'white' }}
              onClick={() => handleAreaClick(index)}
            />
          ))}
        </div>
      </CardContent>
      <CardFooter className="flex justify-center space-x-2">
        {colors.map(color => (
          <Button
            key={color}
            className="w-8 h-8 rounded-full"
            style={{ backgroundColor: color }}
            onClick={() => handleColorChange(color)}
          />
        ))}
      </CardFooter>
    </Card>
  )
}

