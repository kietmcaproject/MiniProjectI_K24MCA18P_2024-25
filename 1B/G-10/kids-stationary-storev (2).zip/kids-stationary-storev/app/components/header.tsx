'use client'

import Link from 'next/link'
import { Pencil, ShoppingCart, Search } from 'lucide-react'
import { useCart } from '../contexts/CartContext'
import { Button } from "@/components/ui/button"
import { useState } from 'react'
import { Input } from "@/components/ui/input"

export default function Header() {
  const { cart } = useCart()

  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0)

  return (
    <header className="bg-primary text-primary-foreground p-4 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold flex items-center gap-2 hover:scale-105 transition-transform">
          <Pencil className="h-8 w-8 animate-float" />
          <span className="font-bubblegum">KiddieDoodle</span>
        </Link>
        <nav className="flex items-center space-x-4">
          <form onSubmit={(e) => { e.preventDefault(); /* Implement search logic here */ }} className="relative">
            <Input
              type="search"
              placeholder="Search..."
              className="pl-10 pr-4 py-2 rounded-full"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          </form>
          <Link href="/products" className="hover:text-secondary transition-colors">Cool Stuff</Link>
          <Link href="/about" className="hover:text-secondary transition-colors">About Us</Link>
          <Button variant="secondary" asChild>
            <Link href="/cart" className="flex items-center gap-1">
              <ShoppingCart className="h-5 w-5" />
              <span>My Basket</span>
              {cartItemsCount > 0 && (
                <span className="ml-1 bg-accent text-accent-foreground rounded-full px-2 py-1 text-xs font-bold">
                  {cartItemsCount}
                </span>
              )}
            </Link>
          </Button>
        </nav>
      </div>
    </header>
  )
}

