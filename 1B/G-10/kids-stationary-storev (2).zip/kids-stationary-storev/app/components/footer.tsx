import { Heart } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground py-8">
      <div className="container mx-auto text-center">
        <p className="text-lg mb-4 animate-float">KiddieDoodle - Where Learning Meets Fun!</p>
        <p className="flex items-center justify-center gap-2">
          Made with <Heart className="text-red-500 animate-pulse" /> for creative kids everywhere
        </p>
        <p className="mt-4 text-sm">© 2023 KiddieDoodle. All rights reserved.</p>
      </div>
    </footer>
  )
}

