'use client'

import { useState } from 'react'
import { useParams } from 'next/navigation'
import { useCart } from '../../contexts/CartContext'
import { useWishlist } from '../../contexts/WishlistContext'
import { useAuth } from '../../contexts/AuthContext'
import { useReviews } from '../../contexts/ReviewsContext'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import Header from '../../components/header'
import Footer from '../../components/footer'
import Image from 'next/image'
import { ShoppingCart, Heart, Star } from 'lucide-react'

const products = [
  { id: 1, name: "Rainbow Pencil Set", price: 5.99, image: "/placeholder.svg?height=400&width=400", description: "A set of vibrant rainbow pencils to make your drawings come alive!" },
  { id: 2, name: "Unicorn Notebook", price: 4.99, image: "/placeholder.svg?height=400&width=400", description: "A magical notebook featuring a beautiful unicorn design." },
  { id: 3, name: "Dinosaur Eraser Pack", price: 3.99, image: "/placeholder.svg?height=400&width=400", description: "Erase your mistakes with these fun dinosaur-shaped erasers!" },
  { id: 4, name: "Space Rocket Pencil Case", price: 7.99, image: "/placeholder.svg?height=400&width=400", description: "Store your stationery in this cool space rocket pencil case." },
]

export default function ProductDetail() {
  const { id } = useParams()
  const product = products.find(p => p.id === Number(id))
  const { addToCart } = useCart()
  const { addToWishlist } = useWishlist()
  const { user } = useAuth()
  const { reviews, addReview, getProductReviews } = useReviews()
  const { toast } = useToast()

  const [rating, setRating] = useState(5)
  const [comment, setComment] = useState('')

  const productReviews = getProductReviews(Number(id))

  const handleAddToCart = () => {
    if (product) {
      addToCart(product)
      toast({
        title: "Added to cart!",
        description: `${product.name} has been added to your basket.`,
      })
    }
  }

  const handleAddToWishlist = () => {
    if (product) {
      addToWishlist(product)
      toast({
        title: "Added to wishlist!",
        description: `${product.name} has been added to your wishlist.`,
      })
    }
  }

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault()
    if (product && user) {
      addReview({
        productId: product.id,
        userId: user.id,
        userName: user.name,
        rating,
        comment,
      })
      setRating(5)
      setComment('')
      toast({
        title: "Review submitted!",
        description: "Thank you for your feedback!",
      })
    }
  }

  if (!product) {
    return <div>Product not found</div>
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary/30 to-primary/30 flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <Image 
              src={product.image} 
              alt={product.name} 
              width={400} 
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
          <div>
            <h1 className="text-4xl font-bold text-primary mb-4">{product.name}</h1>
            <p className="text-2xl font-bold text-accent mb-4">${product.price.toFixed(2)}</p>
            <p className="mb-6">{product.description}</p>
            <div className="flex space-x-4">
              <Button onClick={handleAddToCart} className="flex items-center gap-2">
                <ShoppingCart className="h-5 w-5" />
                Add to Basket
              </Button>
              <Button onClick={handleAddToWishlist} variant="outline" className="flex items-center gap-2">
                <Heart className="h-5 w-5" />
                Add to Wishlist
              </Button>
            </div>
          </div>
        </div>

        <section className="mt-12">
          <h2 className="text-3xl font-bold text-primary mb-6">Reviews</h2>
          {productReviews.length > 0 ? (
            <div className="space-y-4">
              {productReviews.map(review => (
                <Card key={review.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`h-5 w-5 ${i < review.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
                      ))}
                      <span className="ml-2">{review.userName}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p>{review.comment}</p>
                  </CardContent>
                  <CardFooter>
                    <p className="text-sm text-muted-foreground">{new Date(review.date).toLocaleDateString()}</p>
                  </CardFooter>
                </Card>
              ))}
            </div>
          ) : (
            <p>No reviews yet. Be the first to review this product!</p>
          )}
        </section>

        {user && (
          <section className="mt-12">
            <h2 className="text-3xl font-bold text-primary mb-6">Write a Review</h2>
            <form onSubmit={handleSubmitReview} className="space-y-4">
              <div>
                <Label htmlFor="rating">Rating</Label>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Button
                      key={star}
                      type="button"
                      variant="ghost"
                      className="p-0"
                      onClick={() => setRating(star)}
                    >
                      <Star className={`h-6 w-6 ${star <= rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
                    </Button>
                  ))}
                </div>
              </div>
              <div>
                <Label htmlFor="comment">Your Review</Label>
                <Textarea
                  id="comment"
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  rows={4}
                  required
                />
              </div>
              <Button type="submit">Submit Review</Button>
            </form>
          </section>
        )}
      </main>
      <Footer />
    </div>
  )
}

