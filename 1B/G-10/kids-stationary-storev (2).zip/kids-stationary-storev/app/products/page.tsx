'use client'

import { useState } from 'react'
import { useCart } from '../contexts/CartContext'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from '@/hooks/use-toast'
import Image from 'next/image'
import Header from '../components/header'
import Footer from '../components/footer'
import { ShoppingCart } from 'lucide-react'

const products = [
  { id: 1, name: "Rainbow Pencil Set", price: 5.99, image: "/11.png?height=200&width=200", category: "Writing" },
  { id: 2, name: "Unicorn Notebook", price: 4.99, image: "/12.png.jpg?height=200&width=200", category: "Notebooks" },
  { id: 3, name: "Dinosaur Eraser Pack", price: 3.99, image: "/13.png.jpg?height=200&width=200", category: "Erasers" },
  { id: 4, name: "Space Rocket Pencil Case", price: 7.99, image: "/14.png.jpg?height=200&width=200", category: "Accessories" },
  { id: 5, name: "Magical Markers Set", price: 6.99, image: "/18.png.jpg?height=200&width=200", category: "Writing" },
  { id: 6, name: "Enchanted Forest Sketchbook", price: 8.99, image: "/15.png.jpg?height=200&width=200", category: "Notebooks" },
  { id: 7, name: "Superhero Pencil Sharpener", price: 2.99, image: "/16.png.jpg?.jpgheight=200&width=200", category: "Accessories" },
  { id: 8, name: "Glitter Gel Pens", price: 4.99, image: "/17.png.jpg?height=200&width=200", category: "Writing" },
]

const categories = ["All", "Writing", "Notebooks", "Erasers", "Accessories"]

export default function Products() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const { addToCart } = useCart()
  const { toast } = useToast()

  const filteredProducts = selectedCategory === "All" 
    ? products 
    : products.filter(product => product.category === selectedCategory)

  const handleAddToCart = (product: typeof products[0]) => {
    addToCart(product)
    toast({
      title: "Added to cart!",
      description: `${product.name} has been added to your basket.`,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary/30 to-primary/30 flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto py-8">
        <h1 className="text-4xl font-bold text-primary mb-8 animate-float">Magical Stationery</h1>
        <div className="mb-8 flex flex-wrap gap-2">
          {categories.map(category => (
            <Button 
              key={category}
              onClick={() => setSelectedCategory(category)}
              variant={selectedCategory === category ? "default" : "outline"}
            >
              {category}
            </Button>
          ))}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="bg-white rounded-lg shadow-lg overflow-hidden transform transition-all hover:scale-105 hover:shadow-xl">
              <CardHeader className="p-0">
                <Image 
                  src={product.image} 
                  alt={product.name} 
                  width={200} 
                  height={200}
                  className="w-full h-48 object-cover"
                />
              </CardHeader>
              <CardContent className="p-4">
                <CardTitle className="text-xl font-bold text-primary">{product.name}</CardTitle>
                <p className="text-accent font-bold mt-2">${product.price.toFixed(2)}</p>
              </CardContent>
              <CardFooter className="p-4">
                <Button 
                  className="w-full bg-secondary hover:bg-secondary/90 text-secondary-foreground font-bold py-2 px-4 rounded-full flex items-center justify-center gap-2"
                  onClick={() => handleAddToCart(product)}
                >
                  <ShoppingCart className="h-5 w-5" />
                  Add to Basket
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </main>
      <Footer />
    </div>
  )
}

