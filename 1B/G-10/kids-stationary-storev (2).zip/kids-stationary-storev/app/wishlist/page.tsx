'use client'

import { useWishlist } from '../contexts/WishlistContext'
import { useCart } from '../contexts/CartContext'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from '@/hooks/use-toast'
import Header from '../components/header'
import Footer from '../components/footer'
import { ShoppingCart, Trash2 } from 'lucide-react'

export default function Wishlist() {
  const { wishlist, removeFromWishlist } = useWishlist()
  const { addToCart } = useCart()
  const { toast } = useToast()

  const handleAddToCart = (item: typeof wishlist[0]) => {
    addToCart(item)
    toast({
      title: "Added to cart!",
      description: `${item.name} has been added to your basket.`,
    })
  }

  const handleRemoveFromWishlist = (id: number) => {
    removeFromWishlist(id)
    toast({
      title: "Removed from wishlist",
      description: "The item has been removed from your wishlist.",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary/30 to-primary/30 flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto py-8">
        <h1 className="text-4xl font-bold text-primary mb-8 animate-float">My Magical Wishlist</h1>
        {wishlist.length === 0 ? (
          <p className="text-center text-lg">Your wishlist is empty. Let's go find some cool stuff!</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {wishlist.map((item) => (
              <Card key={item.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-primary">{item.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-accent font-bold">${item.price.toFixed(2)}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button 
                    onClick={() => handleAddToCart(item)}
                    className="bg-secondary hover:bg-secondary/90 text-secondary-foreground font-bold py-2 px-4 rounded-full flex items-center justify-center gap-2"
                  >
                    <ShoppingCart className="h-5 w-5" />
                    Add to Basket
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => handleRemoveFromWishlist(item.id)}
                    className="text-destructive hover:bg-destructive hover:text-destructive-foreground"
                  >
                    <Trash2 className="h-5 w-5" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}

