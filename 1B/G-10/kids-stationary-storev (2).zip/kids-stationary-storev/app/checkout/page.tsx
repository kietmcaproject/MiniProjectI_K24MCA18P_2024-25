'use client'

import { useState } from 'react'
import { useCart } from '../contexts/CartContext'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import Header from '../components/header'
import Footer from '../components/footer'

export default function Checkout() {
  const { cart, getCartTotal, clearCart } = useCart()
  const { toast } = useToast()
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    zipCode: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the order to a server
    console.log('Order submitted:', { items: cart, total: getCartTotal(), ...formData })
    toast({
      title: "Order placed successfully!",
      description: "Thank you for your purchase. Your magical items are on their way!",
    })
    clearCart()
    // Redirect to a thank you page (you'd need to create this)
    // router.push('/thank-you')
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary/30 to-primary/30 flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto py-8">
        <h1 className="text-4xl font-bold text-primary mb-8 animate-float">Magical Checkout</h1>
        <form onSubmit={handleSubmit} className="space-y-6 max-w-md mx-auto">
          <div>
            <Label htmlFor="name">Full Name</Label>
            <Input id="name" name="name" required onChange={handleInputChange} />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" required onChange={handleInputChange} />
          </div>
          <div>
            <Label htmlFor="address">Address</Label>
            <Input id="address" name="address" required onChange={handleInputChange} />
          </div>
          <div className="flex gap-4">
            <div className="flex-1">
              <Label htmlFor="city">City</Label>
              <Input id="city" name="city" required onChange={handleInputChange} />
            </div>
            <div className="flex-1">
              <Label htmlFor="zipCode">Zip Code</Label>
              <Input id="zipCode" name="zipCode" required onChange={handleInputChange} />
            </div>
          </div>
          <div>
            <Label htmlFor="cardNumber">Card Number</Label>
            <Input id="cardNumber" name="cardNumber" required onChange={handleInputChange} />
          </div>
          <div className="flex gap-4">
            <div className="flex-1">
              <Label htmlFor="expiryDate">Expiry Date</Label>
              <Input id="expiryDate" name="expiryDate" placeholder="MM/YY" required onChange={handleInputChange} />
            </div>
            <div className="flex-1">
              <Label htmlFor="cvv">CVV</Label>
              <Input id="cvv" name="cvv" required onChange={handleInputChange} />
            </div>
          </div>
          <div>
            <p className="text-2xl font-bold mb-4">Total: ${getCartTotal().toFixed(2)}</p>
          </div>
          <Button type="submit" className="w-full">Place Magical Order</Button>
        </form>
      </main>
      <Footer />
    </div>
  )
}

