'use client'

import React, { createContext, useContext, useState, useEffect } from 'react'

type Review = {
  id: string
  productId: number
  userId: string
  userName: string
  rating: number
  comment: string
  date: string
}

type ReviewsContextType = {
  reviews: Review[]
  addReview: (review: Omit<Review, 'id' | 'date'>) => void
  getProductReviews: (productId: number) => Review[]
}

const ReviewsContext = createContext<ReviewsContextType | undefined>(undefined)

export const ReviewsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [reviews, setReviews] = useState<Review[]>([])

  useEffect(() => {
    const storedReviews = localStorage.getItem('reviews')
    if (storedReviews) {
      setReviews(JSON.parse(storedReviews))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem('reviews', JSON.stringify(reviews))
  }, [reviews])

  const addReview = (review: Omit<Review, 'id' | 'date'>) => {
    const newReview = {
      ...review,
      id: Date.now().toString(),
      date: new Date().toISOString(),
    }
    setReviews(prev => [...prev, newReview])
  }

  const getProductReviews = (productId: number) => {
    return reviews.filter(review => review.productId === productId)
  }

  return (
    <ReviewsContext.Provider value={{ reviews, addReview, getProductReviews }}>
      {children}
    </ReviewsContext.Provider>
  )
}

export const useReviews = () => {
  const context = useContext(ReviewsContext)
  if (context === undefined) {
    throw new Error('useReviews must be used within a ReviewsProvider')
  }
  return context
}

