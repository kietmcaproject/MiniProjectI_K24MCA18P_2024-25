'use client'

import { useCart } from '../contexts/CartContext'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Trash2 } from 'lucide-react'
import Header from '../components/header'
import Footer from '../components/footer'

export default function Cart() {
  const { cart, removeFromCart, clearCart, getCartTotal } = useCart()

  return (
    <div className="min-h-screen bg-gradient-to-b from-secondary/30 to-primary/30 flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto py-8">
        <h1 className="text-4xl font-bold text-primary mb-8 animate-float">My Magical Basket</h1>
        {cart.length === 0 ? (
          <p className="text-center text-lg">Your basket is empty. Let's go find some cool stuff!</p>
        ) : (
          <>
            {cart.map((item) => (
              <Card key={item.id} className="mb-4 bg-white shadow-lg">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-primary">{item.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-accent font-bold">${item.price.toFixed(2)} x {item.quantity}</p>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <p className="font-bold">Total: ${(item.price * item.quantity).toFixed(2)}</p>
                  <Button variant="destructive" onClick={() => removeFromCart(item.id)}>
                    <Trash2 className="h-5 w-5" />
                    Remove
                  </Button>
                </CardFooter>
              </Card>
            ))}
            <div className="mt-8 flex flex-col items-end">
              <p className="text-2xl font-bold mb-4">Grand Total: ${getCartTotal().toFixed(2)}</p>
              <div className="space-x-4">
                <Button variant="outline" onClick={clearCart}>Clear Basket</Button>
                <Button>Checkout</Button>
              </div>
            </div>
          </>
        )}
      </main>
      <Footer />
    </div>
  )
}

