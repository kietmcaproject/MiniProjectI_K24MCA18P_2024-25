const base_url = window.location.origin;
$(document).ready(function(){


	document.getElementById("select-course-id").onchange = function(evt){

	   var course_id = evt.target.value;

	   evt.preventDefault();
		let url = base_url+"/api/v1/getStudent";
		$.ajax({
		  type: "POST",
			url: url,
			data: { 'course_id': course_id},
		    dataType: 'JSON',
		    success: function(response) {

		    	let len = response.length;
		    	let i =0;
		    	let html = "<option value='0'>Select Student</option>";
		    	while(i<len){

		    		html = html+"<option value="+response[i]['registration']+">"+response[i]['fname']+" "+response[i]['lname']+"</option>";
		    		i++;
		    	}

		        $("#select-student-id").empty().append(html);
		    }
		 });
	 };

	document.getElementById("select-student-id").onchange = function(evt){

	    var student = evt.target.value;
	    if(student!='0'){
	    	$('#registration-id').val(student);
	    } else{

	    	$('#registration-id').val("");
	    }
	    
		
	};

});

function generate() {


  let reg_no =  $("#registration-id").val();
  let amount = $("#fee-amount").val();
  var payment = document.getElementById("select-payment-mode");
  let mode = payment.options[payment.selectedIndex].text
  let data = {
    'registration':reg_no,
    'amount':amount,
    'mode':mode
  }

  
  // "http://stackoverflow.com"

    
  let url = base_url+"/api/v1/addFees";
  $.ajax({
    type: "POST",
    url: url,
    data: data,
      dataType: 'JSON',
      success: function(response) {

        $("#generate-btn").hide();
        $("#print-btn").show();
      }
   });


 
}

function vewInvoice() {

  

  var course = document.getElementById("select-course-id");
  let selCourse = course.options[course.selectedIndex].text;

  if(selCourse=='Select course'){
    alert("Please select course!");
    return false;
  }

  $("#invoice-course").text(selCourse);

  var sel = document.getElementById("select-student-id");
  let studentId = sel.options[sel.selectedIndex].text;
  $("#invoice-student").text(studentId);

  if(studentId=='Select Student'){
    alert("Please select student!");
    return false;
  }

  let reg = $("#registration-id").val();
  $("#invoice-registration").text(reg);

 

  let amount = $("#fee-amount").val();
  $("#invoice-total").text(amount);

  console.log((amount));
  if(amount==''){
    alert("Please Enter fee amount!");
    return false;
  }

  $("#invoice-total-amount").text($("#fee-amount").val());

 

  var payment = document.getElementById("select-payment-mode");
  $("#invoice-payment-mode").text(payment.options[payment.selectedIndex].text);

  const today = new Date();
  const yyyy = today.getFullYear();
  let mm = today.getMonth() + 1; // Months start at 0!
  let dd = today.getDate();
  console.log(dd)
  if (dd < 10) dd = '0' + dd;
  if (mm < 10) mm = '0' + mm;

  let formattedToday = dd + '/' + mm + '/' + yyyy;
  $("#invoice-date").text(formattedToday);

  $("#invoice-form").hide();
  $("#invoice-layout").show();

}

function printDiv(divId) {

 


  var printContents = document.getElementById(divId).innerHTML;
  var originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;

    window.print();

    document.body.innerHTML = originalContents;
}