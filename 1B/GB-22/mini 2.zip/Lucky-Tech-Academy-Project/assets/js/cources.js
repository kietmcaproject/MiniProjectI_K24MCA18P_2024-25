
// console.log("munendra kumar");

let development = document.getElementById("Development-Courses");
let programing = document.getElementById("Programing-Courses");
let basic_computer = document.getElementById("Basic-computer-Cources");
let tranding_cources = document.getElementById("Tranding-couces");


function onloadbodyevent() {
    development.style.display = "none"
    programing.style.display = "none"
    basic_computer.style.display = "none"
    tranding_cources.style.display = "block"

}

function Developmentclick() {
    development.style.display = "block";
    programing.style.display = "none"
    basic_computer.style.display = "none"
    tranding_cources.style.display = "none"
}

function Programingclick() {
    development.style.display = "none"
    programing.style.display = "block"
    basic_computer.style.display = "none"
    tranding_cources.style.display = "none"

}
function BasicComputerclick() {
    development.style.display = "none"
    programing.style.display = "none"
    basic_computer.style.display = "block"
    tranding_cources.style.display = "none"
}
function trandingclick() {
    development.style.display = "none"
    programing.style.display = "none"
    basic_computer.style.display = "none"
    tranding_cources.style.display = "block"
}

