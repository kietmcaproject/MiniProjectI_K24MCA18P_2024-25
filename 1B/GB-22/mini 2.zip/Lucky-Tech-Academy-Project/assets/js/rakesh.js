// window.addEventListener('scroll',()=>{
//     // document.querySelector('nav').classList.toggle("window-scroll",window.scrollY >0)
// })

// console.log("hii")
// const faqs=document.querySelectorAll(".faq");
// console.log("values  of the faqs = ",faqs);

// faqs.forEach(faq=>{
//     faq.addEventListener('click',()=>{
//         faq.classList.toggle(".open");
//         const icon=faq.querySelector('.faq_icon i');
//         if(icon.className=='bi bi-plus'){
//             icon.className="bi bi-dash"
//         }
//     })
// })
// function show(ele){
//    let p_ele= document.getElementById("que");
//    console.log(p_ele);
//    p_ele.classList.add("open")
//     p_ele.classList.remove("phide");
// }


// ////////////////////////////////////////////////////one question /////////////////////////////////////////////////////////////////////
const one=document.getElementById("one")
const one1=document.getElementById("one1");
one.onclick=function(){
   one1.classList.toggle("phide")
   const icon=document.querySelector('#a');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
//////////////////////////////////////////////////two question /////////////////////////////////////////////////////////////
const two=document.getElementById("two")
const two2=document.getElementById("two2");
two.onclick=function(){
    two2.classList.toggle("phide")
    const icon=document.querySelector('#b');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
//////////////////////////////////////////////third question///////////////////////////////////////////////////

const three=document.getElementById("three")
const three3=document.getElementById("three3");
three.onclick=function(){
    three3.classList.toggle("phide")
    const icon=document.querySelector('#c');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
////////////////////////////////////////////////////four question//////////////////////////////////////////////
const four=document.getElementById("four")
const four4=document.getElementById("four4");
four.onclick=function(){
    four4.classList.toggle("phide")
    const icon=document.querySelector('#d');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
///////////////////////////////////////////////////five question////////////////////////////////////////////////
const five=document.getElementById("five")
const five5=document.getElementById("five5");
five.onclick=function(){
    five5.classList.toggle("phide")
    const icon=document.querySelector('#e');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
//////////////////////////////////////////////////six question/////////////////////////////////////////////////
const six=document.getElementById("six")
const six6=document.getElementById("six6");
six.onclick=function(){
    six6.classList.toggle("phide")
    const icon=document.querySelector('#f');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
///////////////////////////////////////////////////sevin question////////////////////////////////////////////////
const seven=document.getElementById("seven")
const seven7=document.getElementById("seven7");
seven.onclick=function(){
    seven7.classList.toggle("phide")
    const icon=document.querySelector('#g');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
////////////////////////////////////////////////////eigth question/////////////////////////////////////////////
const eigth=document.getElementById("eigth")
const eigth8=document.getElementById("eigth8");
eigth.onclick=function(){
    eigth8.classList.toggle("phide")
    const icon=document.querySelector('#h');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
///////////////////////////////////////////////////////////nine question///////////////////////////////////////
const nine=document.getElementById("nine")
const nine9=document.getElementById("nine9");
nine.onclick=function(){
    nine9.classList.toggle("phide")
    const icon=document.querySelector('#i');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
/////////////////////////////////////////////////////////////////ten question/////////////////////////////////
const ten=document.getElementById("ten")
const ten10=document.getElementById("ten10");
ten.onclick=function(){
    ten10.classList.toggle("phide")
    const icon=document.querySelector('#j');
   console.log(icon);
   if(icon.className==="bi bi-plus"){
    icon.className="bi bi-dash";
   }
   else{
    if(icon.className==="bi bi-dash"){
        icon.className="bi bi-plus";
       }
   }
};
////////////////////////////////////////