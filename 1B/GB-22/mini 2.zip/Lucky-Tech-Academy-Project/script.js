 
document.getElementById('student-form').addEventListener('submit', function(event) {
  event.preventDefault();
  alert('Student login submitted!');
});

document.getElementById('admin-form').addEventListener('submit', function(event) {
  event.preventDefault();
  alert('Admin login submitted!');
});
