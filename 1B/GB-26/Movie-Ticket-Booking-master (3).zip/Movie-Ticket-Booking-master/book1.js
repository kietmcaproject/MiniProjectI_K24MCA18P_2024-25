// Handle seat selection
const seats = document.querySelectorAll('.seat');
let selectedSeats = [];

seats.forEach(seat => {
    seat.addEventListener('click', () => {
        seat.classList.toggle('selected');

        // Update selectedSeats array
        if (seat.classList.contains('selected')) {
            selectedSeats.push(seat.textContent);
        } else {
            selectedSeats = selectedSeats.filter(s => s !== seat.textContent);
        }
    });
});

// Handle booking button click
const bookBtn = document.querySelector('.book-btn');

bookBtn.addEventListener('click', () => {
    if (selectedSeats.length > 0) {
        alert(`Your ticket(s) for seat(s) ${selectedSeats.join(', ')} are booked!`);
        window.location.href = 'movie.html'; // Redirect to movie.html
    } else {
        alert('Please select at least one seat.');
    }
});

