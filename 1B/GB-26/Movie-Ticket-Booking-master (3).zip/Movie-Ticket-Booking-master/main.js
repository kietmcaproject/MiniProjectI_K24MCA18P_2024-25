document.addEventListener('DOMContentLoaded', function() {
    // Get all "Book Now" buttons
    const bookButtons = document.querySelectorAll('.book-btn');

    // Add click event listener to each button
    bookButtons.forEach((button, index) => {
        button.addEventListener('click', function() {
            // Get the movie details from the parent movie div
            const movieDiv = this.closest('.movie');
            const movieTitle = movieDiv.querySelector('h3').textContent;
            const movieGenre = movieDiv.querySelector('p').textContent;
            const movieImage = movieDiv.querySelector('img').src;

            // Store movie details in sessionStorage
            sessionStorage.setItem('movieDetails', JSON.stringify({
                title: movieTitle,
                genre: movieGenre.replace('Genre: ', ''),
                image: movieImage,
                movieId: index + 1
            }));

            // Redirect to booking page
            window.location.href = 'book1.html';
        });
    });
});
