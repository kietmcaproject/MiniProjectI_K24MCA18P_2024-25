// OLD CODE 
// document.addEventListener('DOMContentLoaded', function() {
//     const signupButton = document.querySelector('.clkbtn');
    
//     signupButton.addEventListener('click', function() {
//         // Get all input values
//         const name = document.querySelector('.name').value.trim();
//         const email = document.querySelector('.email').value.trim();
//         const passwords = document.querySelectorAll('.password');
//         const password = passwords[0].value;
//         const confirmPassword = passwords[1].value;

//         // Validation checks
//         if (!name || !email || !password || !confirmPassword) {
//             alert('Please fill in all fields');
//             return;
//         }

//         // Email validation
//         const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//         if (!emailPattern.test(email)) {
//             alert('Please enter a valid email address');
//             return;
//         }

//         // Password validation
//         if (password.length < 8) {
//             alert('Password must be at least 8 characters long');
//             return;
//         }

//         // Confirm password validation
//         if (password !== confirmPassword) {
//             alert('Passwords do not match');
//             return;
//         }

//         // Store user data in localStorage
//         const userData = {
//             name: name,
//             email: email,
//             password: password
//         };

//         // Get existing users or create new array
//         const users = JSON.parse(localStorage.getItem('users')) || [];
        
//         // Check if email already exists
//         if (users.some(user => user.email === email)) {
//             alert('This email is already registered');
//             return;
//         }

//         // Add new user
//         users.push(userData);
        
//         // Save to localStorage
//         localStorage.setItem('users', JSON.stringify(users));

//         // Show success message
//         alert('Signup successful!');

//         // Redirect to login page
//         window.location.href = 'login.html';
//     });
// });


// NEW CODE
document.addEventListener('DOMContentLoaded', function () {
    const signupForm = document.getElementById('signup-form');
    const loader = document.getElementById('loader');

    signupForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent form from refreshing the page

        // Show loader
        loader.style.display = 'block';

        // Get all input values
        const name = document.querySelector('input[name="username"]').value.trim();
        const email = document.querySelector('input[name="email"]').value.trim();
        const password = document.querySelector('input[name="password"]').value.trim();
        const confirmPassword = document.querySelector('input[name="confirmpassword"]').value.trim();

        // Validation checks
        if (!name || !email || !password || !confirmPassword) {
            alert('Please fill in all fields');
            loader.style.display = 'none'; // Hide loader on error
            return;
        }

        // Email validation
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            alert('Please enter a valid email address');
            loader.style.display = 'none'; // Hide loader on error
            return;
        }

        // Password validation
        if (password.length < 8) {
            alert('Password must be at least 8 characters long');
            loader.style.display = 'none'; // Hide loader on error
            return;
        }

        // Confirm password validation
        if (password !== confirmPassword) {
            alert('Passwords do not match');
            loader.style.display = 'none'; // Hide loader on error
            return;
        }

        // Create user data for API
        const userData = {
            name: name,
            email: email,
            password: password
        };

        fetch('https://new-gym-be.vercel.app/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        })
            .then(response => response.json())
            .then(data => {
                loader.style.display = 'none'; // Hide loader after response
                if (data.message) {
                    alert(data.message); // Show success message
                    window.location.href = 'login.html'; // Redirect to login page
                } else if (data.error) {
                    alert(data.error); // Show error message
                }
            })
            .catch(error => {
                loader.style.display = 'none'; // Hide loader on error
                console.error('Error:', error);
                alert('An error occurred. Please try again later.');
            });
    });
});
