// Show and hide sections
function showSection(sectionId) {
    const sections = document.querySelectorAll('.section');
    sections.forEach(section => section.style.display = 'none');
    document.getElementById(sectionId).style.display = 'block';
}
// Toggle login/signup modal
function toggleAuthForm() {
    const modal = document.getElementById('auth-modal');
    modal.style.display = modal.style.display === 'flex' ? 'none' : 'flex';
}

// Switch between login and signup forms
function switchAuthForm() {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    if (loginForm.style.display === 'none') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
    }
}

// Play and pause meditation audio
let currentAudio = null;

function playMeditation(meditationName) {
    const audioFiles = {
        "Relaxation Meditation": "audio/Relaxation.mp3",
        "Stress Relief Meditation": "audio/Stress.mp3",
        "Sleep Meditation": "audio/Sleep.mp3",
        "Gratitude Meditation": "audio/Gratitude.mp3",
        "Focus Meditation": "audio/Focus.mp3"
    };

    const audioFile = audioFiles[meditationName];

    if (audioFile) {
        // Check if a different audio file is selected
        if (!currentAudio || currentAudio.src !== new URL(audioFile, window.location.origin).href) {
            if (currentAudio) {
                currentAudio.pause(); // Pause the currently playing audio
            }
            currentAudio = new Audio(audioFile); // Load the new audio file
        }

        // Play the selected audio
        if (currentAudio.paused) {
            currentAudio.play();
        }
    }
}

function pauseMeditation() {
    if (currentAudio) {
        currentAudio.pause(); // Pause the audio without resetting its position
    }
}

// Add article functionality
document.getElementById('add-article-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const title = document.getElementById('article-title').value;
    const content = document.getElementById('article-content').value;

    const newArticle = document.createElement('article');
    newArticle.innerHTML = `
        <h3>${title}</h3>
        <p>${content}</p>
    `;
    document.getElementById('article-list').appendChild(newArticle);
    e.target.reset();
});

// Show mindfulness activity details
function showActivityDetails(activityName) {
    const details = {
        "Mindful Walking": "Focus on each step, feel the ground beneath your feet, and be present.<br><strong>How to Practice Mindful Walking:</strong></br><ol><li>Start by grounding yourself with deep breaths.</li><li>Walk slowly and deliberately, paying attention to each step.</li><li>Focus on sensations like the heel touching the ground and the roll of the foot.</li></ol>",
        "Mindful Eating": "Savor every bite, focus on the taste, texture, and smell of your food.<br>Mindful eating is the practice of bringing full attention to the experience of eating</br>. It involves being present during meals, engaging all your senses, and paying attention to hunger and fullness cues.<br><strong>How to Practice Mindful Eating:</strong></br> <ul><li>Eat without distractions like TV or phone.</li><li>Notice the colors, textures, and flavors of your food.</li><li>Chew slowly and savor each bite.</li></ul>",
        "Body Scan Meditation": "Relax by focusing on different parts of your body from head to toe.<br>Body scan meditation involves mentally scanning your body from head to toe to increase awareness and relaxation.<br><ol><li>Find a quiet place to sit or lie down.</li><li>Start at the top of your head and move your focus down your body.</li> <li>Notice sensations without judgment.</li></ol>",
        "Breathing Exercises": "Practice deep, rhythmic breathing to calm your mind.<li>Inhale deeply through your nose for 4 counts.</li> <li>Hold your breath for 4 counts.</li><li>Exhale slowly through your mouth for 6 counts.</li>",
        "Journaling": "Write down your thoughts and emotions for better self-reflection.<ul><li>Set aside 10-15 minutes daily to write.</li><li>Use prompts or write freely about your day.</li><li>Focus on expressing your thoughts without judgment.</li></ul>",
    };

    const activityDetails = document.getElementById('activity-details');
    activityDetails.innerHTML = `<h4>${activityName}</h4><p>${details[activityName]}</p>`;
    activityDetails.style.display = 'block';
    
}

