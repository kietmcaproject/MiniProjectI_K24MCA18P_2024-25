
 
from flask import Flask, render_template, request, jsonify
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
import requests

import google.generativeai as genai
import os

# genai.configure(api_key=os.environ["GEMINI_API_KEY"])

# model = genai.GenerativeModel(model_name="gemini-1.5-flash")
# response = model.generate_content("Explain how AI works")
# print(response.text)
# Load the pre-trained model and tokenizer
# New global variables to handle mood rating

tokenizer = AutoTokenizer.from_pretrained("microsoft/DialoGPT-medium")
model = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-medium")

# Initialize Flask app
app = Flask(__name__)

# Initialize chat history at the global scope
chat_history_ids = None
mood_rating = None
asked_for_mood = False

# def fetch_mental_health_api_data():
#     url = "https://api.example.com/mental-health-info"
#     headers = {"Authorization": "Bearer YOUR_API_KEY"}
#     response = requests.get(url, headers=headers)
#     data = response.json()
#     return data

# mental_health_data = fetch_mental_health_api_data()
# print(mental_health_data)

def assess_user_message(msg):
    # Simple keyword-based assessment
    if "anxiety" in msg.lower():
        return "It seems you're talking about anxiety. Here's some information that might help: " + get_anxiety_info()
    elif "depression" in msg.lower():
        return "It seems you're talking about depression. Here's some information that might help: " + get_depression_info()
    else:
        return "Can you tell me more about how you're feeling?"

def get_anxiety_info():
    return "Anxiety can be managed with techniques like mindfulness, breathing exercises, and therapy. Seek professional help if needed."

def get_depression_info():
    return "Depression can be treated with therapy and medication. Talking to a mental health professional is a great step toward recovery."

def generate_mental_health_assistance(msg):
    # Pass user message to Gemini for a more nuanced response
    response = genai.ChatCompletion.create(
        model="google/gemini-model",  # Use the relevant model
        messages=[{"role": "user", "content": msg}]
    )
    return response['choices'][0]['message']['content']

def check_mental_health(msg):
    """Check for mental health-related keywords in the message."""
    # Basic implementation to check for specific words related to mental health
    mental_health_keywords = ["depressed", "sad", "anxious", "stressed", "overwhelmed"]
    for word in mental_health_keywords:
        if word in msg.lower():
            return "It sounds like you might be feeling down. It's okay to not be okay. Would you like to talk more about it?"
    return None

@app.route("/")
def index():
    return render_template('chat.html')

@app.route("/get", methods=["GET", "POST"])
def chat():
    global chat_history_ids  # Use global to retain chat history across calls
    global mood_rating, asked_for_mood
    # Get the message sent by the user
    msg = request.form.get("msg")
    if not asked_for_mood:
        # If we haven't asked for the mood rating yet, do so now
        asked_for_mood = True
        return "Hi! Before we start, could you rate your mood on a scale from 1 to 10, where 1 is the lowest and 10 is the happiest?"

    if mood_rating is None and msg:
        try:
            # Attempt to convert the user input to an integer for mood rating
            mood_rating = int(msg)
            if 1 <= mood_rating <= 10:
                return f"Thank you! You've rated your mood as {mood_rating}. How can I assist you today?"
            else:
                # If the rating is out of range, ask again
                return "Please provide a number between 1 and 10."
        except ValueError:
            # If the user input is not a number, ask again
            return "Please provide a number between 1 and 10 to rate your mood."

    if msg and mood_rating is not None:
        # Check if the message matches any mental health keywords
        assessment = check_mental_health(msg)
        if assessment:
            return assessment

    if "anxiety" in msg.lower() or "depression" in msg.lower() or "stress" in msg.lower():
            api_response = fetch_mental_health_data(msg)  # Fetch data from API based on user's query
            return personalize_response(api_response)
        # Generate the chatbot response
    response = get_Chat_response(msg)
    return personalize_response(response)

    return "No message received"

def get_Chat_response(text):
    global chat_history_ids

    # First check for mental health-related keywords in the user's message
    if 'anxiety' in text.lower():
        return "It seems like you're talking about anxiety. Here's some advice: " + get_anxiety_info()
    elif 'depression' in text.lower():
        return "It seems like you're talking about depression. Here's some advice: " + get_depression_info()

    # Encode the user input, add the eos_token, and return a tensor in PyTorch
    new_user_input_ids = tokenizer.encode(text + tokenizer.eos_token, return_tensors='pt')

    # If chat history exists, append the new user input tokens to it
    if chat_history_ids is not None:
        bot_input_ids = torch.cat([chat_history_ids, new_user_input_ids], dim=-1)
    else:
        bot_input_ids = new_user_input_ids

    # Generate a response while limiting the total chat history to 1000 tokens
    chat_history_ids = model.generate(bot_input_ids, max_length=1000, pad_token_id=tokenizer.eos_token_id)

    # Decode and return the last output tokens from the bot
    response = tokenizer.decode(chat_history_ids[:, bot_input_ids.shape[-1]:][0], skip_special_tokens=True)
    return response
   
# def fetch_mental_health_data(query):
#     # Replace with your actual API URL and key
#     api_url = "https://www.nimh.nih.gov/health/topics/anxiety-disorders"
#     headers = {
#         "Authorization": "Bearer YOUR_API_KEY",  # Use your API key if required
#         "Content-Type": "application/json"
#     }

#     params = {
#         "query": query  # Send the user's query to the API if it supports queries
#     }

#     try:
#         # Make the API request
#         response = requests.get(api_url, headers=headers, params=params)
#         response.raise_for_status()  # Raise an exception for any 4xx or 5xx status codes
#         data = response.json()

#         # Process and extract relevant data from API response
#         # Adjust based on the actual API response structure
#         return data.get('info', 'I found some information, but couldn\'t retrieve details.')  

#     except requests.exceptions.RequestException as e:
#         print(f"Error fetching data: {e}")
#         return "Sorry, I couldn't fetch the latest mental health information at this time."

def personalize_response(response):
    global mood_rating
    if mood_rating is None:
        return response  # If mood rating is not set, return the normal response

    # Adjust responses based on the user's mood
    if mood_rating <= 4:
        return f"I noticed you might not be feeling great. Remember, I'm here to listen. {response}"
    elif mood_rating <= 7:
        return f" Let's see how I can help. {response}"
    else:
        return f"I'm glad you're in a good mood! {response}"

if __name__ == "__main__":
    app.run(debug=True)


                       