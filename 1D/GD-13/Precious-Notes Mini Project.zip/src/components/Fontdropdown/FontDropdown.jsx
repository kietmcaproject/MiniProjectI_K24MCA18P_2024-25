import React, { useState } from 'react';

const FontDropdown = ({ fontFamilies, onFontFamilyChange }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedFont, setSelectedFont] = useState(fontFamilies[0]);

    const handleDropdownClick = () => {
        setIsOpen(!isOpen);
    };

    const handleFontSelect = (font) => {
        setSelectedFont(font);
        setIsOpen(false);
        onFontFamilyChange(font);
    };

    return (
        <div className="relative inline-block text-left items-center">
            <div className='flex justify-between'>
                <button
                    type="button"
                    className="btn btn-primary btn-sm dropdown-toggle"
                    onClick={handleDropdownClick}
                >
                    {selectedFont}
                </button>
            </div>
            {isOpen && (
                <div className="absolute left-0 z-10 mt-2 bg-white border border-gray-200 rounded-md shadow-lg">
                    <div className="grid grid-cols-3 gap-2 p-2" role="menu" aria-orientation="horizontal" aria-labelledby="options-menu" style={{height:"5in",width:"20rem",overflow:'scroll'}}>
                        {fontFamilies.map((font) => (
                            <button
                                key={font}
                                className="w-full px-2 py-1 text-center text-sm text-gray-700 hover:bg-indigo-100 hover:text-indigo-900 focus:bg-indigo-100 focus:text-indigo-900"
                                onClick={() => handleFontSelect(font)}
                                style={{ fontFamily: font }}
                            >
                                {font}
                            </button>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default FontDropdown;
