import React, { useState, useEffect } from 'react'
import logo from './image/Artboard 1@logo.png';
import phonepayqr from './image/PhonePeQR_Federal Bank - 46741.png'
import './Navbar.css'
import { FaFacebook, FaLinkedin, FaGithub, FaInstagram, FaEnvelope } from 'react-icons/fa';

const Navbar = () => {

    const [autorColorcard, setAuthorcolorcard] = useState('');


    const authorcardcolor = () => {
        const r1 = Math.floor(Math.random() * 56 + 200); // Generates a number between 200 and 255
        const g1 = Math.floor(Math.random() * 56 + 200);
        const b1 = Math.floor(Math.random() * 56 + 200);

        const r2 = Math.floor(Math.random() * 56 + 200);
        const g2 = Math.floor(Math.random() * 56 + 200);
        const b2 = Math.floor(Math.random() * 56 + 200);

        const color1 = `rgba(${r1}, ${g1}, ${b1})`;
        const color2 = `rgba(${r2}, ${g2}, ${b2})`;

        return `linear-gradient(to right, ${color1}, ${color2})`;
    };

    useEffect(() => {
        setAuthorcolorcard(authorcardcolor());
    }, [])

    return (
        <>
            <div className="bg-gray-900 p-1 text-wrap flex justify-between align-middle navbarmobile" style={{ alignItems: 'center' }}>
                <span className='d-flex mobile-navbar' style={{ alignItems: 'center' }}>
                    <img src={logo} alt="logo" className=' img-fluid logoanimation' onError={(e) => { e.currentTarget.scr = "logo" }} style={{ objectFit: 'cover', maxWidth: 'fit-content', width: '6rem', height: '4rem', clipPath: 'inset(0px 0px 12px 0px)' }} />
                    <h1 className="text-white text-xl text-capitalize ">PreciousNotes...</h1>
                    <button
                        className='text-sm text-white font-bold mx-2'
                        type="button"
                        data-bs-toggle="modal"
                        data-bs-target="#exampleModal" >
                        <i className="bi bi-exclamation-circle text-sm text-white font-bold"></i>
                    </button>
                </span>
                <span title='Buy me a coffee'>
                    <details>
                        <summary className='flex gap-2 text-yellow-500'>
                            <i className="bi bi-emoji-smile-fill text-yellow-500 " style={{ filter: "drop-shadow(5px 5px 15px white)" }}></i>
                            <p className="text-1xl text-white text-capitalize "> created by vikas singh</p>
                            <i className="bi bi-caret-down-fill mobileshow text-gray-100 text-sm"></i>
                        </summary>
                        <div className='onmobilescreenautor mt-5' style={{ background: autorColorcard }}>
                            <div className="bg-gray-900 p-6 rounded-lg shadow-md max-w-xl mx-auto font-sans">
                                <h2 className="text-2xl font-bold text-gray-100 mb-4">Thank You for Using PreciousNotes! <i className="bi bi-cup-hot"></i></h2>
                                <p className="text-gray-100 mb-4">
                                    Dear User,
                                </p>
                                <p className="text-gray-100 mb-4">
                                    I hope you are doing well. I wanted to personally thank you for using PreciousNotes. It means a lot to me to see people like you enjoying and benefiting from the platform. Creating PreciousNotes has been a passion project, and your support encourages me to keep making it better.
                                </p>
                                <p className="text-gray-100 mb-4">
                                    If you have found PreciousNotes helpful and would like to show your appreciation, please consider buying me a coffee. Your support, with a minimum donation of 10 rupees, will help keep me energized and inspired to continue improving the platform for you and other users.
                                </p>
                                <p className="text-gray-100 mb-4">
                                    You can buy me a coffee here:
                                    <br />
                                    <img src={phonepayqr} className='img-fluid' alt="qr" />
                                </p>
                                <p className="text-gray-100 mb-4">
                                    Thank you again for using PreciousNotes. Your support really means the world to me!
                                </p>
                                <div className="social-media-icons d-flex justify-content-center mb-3 jiophonefooter text-right flex-wrap">
                                    <a href="https://www.facebook.com/profile.php?id=100017086654558" target="_blank" rel="noopener noreferrer" className="mx-2">
                                        <FaFacebook />
                                    </a>
                                    <a href="https://www.instagram.com/me.vikassingh/" target="_blank" rel="noopener noreferrer" className="mx-2">
                                        <FaInstagram />
                                    </a>
                                    <a href="https://www.linkedin.com/in/vikas-singh-877789203/" target="_blank" rel="noopener noreferrer" className="mx-2">
                                        <FaLinkedin />
                                    </a>
                                    <a href="https://github.com/Iamvikassingh/Iamvikassingh" target="_blank" rel="noopener noreferrer" className="mx-2">
                                        <FaGithub />
                                    </a>
                                    <a
                                        href='mailto:9625vikassingh@gmail.com'
                                        className='mx-2'
                                        style={{ display: 'block', textDecoration: 'none' }}
                                    >
                                        <FaEnvelope />
                                    </a>

                                </div>
                            </div>
                        </div>
                    </details>
                </span>
            </div>

            <div className="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog bg-dark">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title font-bold text-capitalize" id="exampleModalLabel">PreciousNotes...</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body p-4">
                            <h4 className='text-gray-900 font-bold card-text text-3xl text-capitalize text-center my-4'>
                                Preciours Notes App: Secure and Private Note-Taking
                            </h4>
                            <p className='card-text text-gray-900 font-sans mt-2'>
                                Preciours Notes, also known as PreciousNotes..., is an innovative note-taking app designed with a focus on privacy and security. This app ensures that all your data remains exclusively within your control, providing a safe space for storing your personal information, ideas, and important reminders.

                            </p>
                            <p className='card-text text-gray-900 font-sans mt-2'>
                                One of the standout features of Preciours Notes is its robust encryption technology. Every note you create is encrypted, ensuring that only you have access to its contents. This means that even in the event of a security breach, your data remains protected and unreadable to unauthorized parties.
                            </p>
                            <p className='card-text text-gray-900 font-sans mt-2'>
                                The app's user-friendly interface allows you to easily organize and manage your notes. You can categorize, tag, and search for notes efficiently, making it simple to keep track of your information. Additionally, the app supports various formats, including text, images, and attachments, catering to diverse note-taking needs.
                            </p>
                            <p className='card-text text-gray-900 font-sans mt-2'>
                                Preciours Notes respects your privacy by not storing any data on external servers. All your information is stored locally on your device, eliminating the risk of cloud-based data breaches. This app is perfect for individuals who prioritize their privacy and want a reliable tool to keep their personal and professional notes secure.
                            </p>
                            <p className='card-text text-gray-900 font-sans mt-2'>
                                In summary, Preciours Notes is a reliable and secure note-taking app that ensures your data remains private and accessible only to you. Its combination of encryption, local storage, and user-friendly features makes it an ideal choice for anyone seeking a trustworthy note-taking solution.
                            </p>
                        </div>
                    </div>
                </div>
            </div >

        </>
    )
}

export default Navbar
