import React, { useState, useEffect } from 'react';
import 'bootstrap-icons/font/bootstrap-icons.css';

const VisitorCounter = () => {
  const [visitorCount, setVisitorCount] = useState(0);
  const [finalCount, setFinalCount] = useState(162);

  useEffect(() => {
    const updateVisitorCount = () => {
      let visitorData = localStorage.getItem('visitorData');
      if (!visitorData) {
        visitorData = JSON.stringify({ count: 0, ips: [] });
        localStorage.setItem('visitorData', visitorData);
      }

      visitorData = JSON.parse(visitorData);
      const clientIp = getClientIp();

      if (!visitorData.ips.includes(clientIp)) {
        visitorData.count += 1;
        visitorData.ips.push(clientIp);
        localStorage.setItem('visitorData', JSON.stringify(visitorData));
        setVisitorCount(visitorData.count);
      } else {
        setVisitorCount(visitorData.count);
      }
    };

    updateVisitorCount();
  }, []);

  useEffect(() => {
    setFinalCount(162 + visitorCount);
  }, [visitorCount]);

  // Function to get client IP (simulated for demonstration)
  const getClientIp = () => {
    // Simulate getting client IP (replace with actual logic if needed)
    return '127.0.0.1';
  };

  return (
    <div className="flex justify-center items-center my-2 w-100">
      <div className="bg-white shadow-lg p-10 rounded-lg text-center container-fluid">
        <h1 className="mb-4 font-bold text-3xl text-capitalize">Our users...</h1>
        <div className="flex justify-center items-center mb-4">
          <i className="text-6xl text-lime-500 bi bi-people-fill"></i>
        </div>
        <div className="font-bold text-4xl text-blue-600">
          Total Visitor's : <RunningCounter initialCount={finalCount} />
          <br />
          Recently Visited : {visitorCount}
        </div>
      </div>
    </div>
  );
};

// Running Counter Component
const RunningCounter = ({ initialCount }) => {
  const [currentCount, setCurrentCount] = useState(initialCount);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentCount((prevCount) => prevCount + 1);
    }, 10000); // Increment every 10 seconds

    return () => clearInterval(intervalId); // Cleanup on unmount
  }, []);

  return <>{currentCount}</>;
};

export default VisitorCounter;
