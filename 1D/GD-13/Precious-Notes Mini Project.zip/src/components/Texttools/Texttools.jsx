import React, { useState, useEffect } from 'react';
import FindReplace from '../Find/Findreplace'; // Import the FindReplace component
import FontDropdown from '../Fontdropdown/FontDropdown'; // Import the FontDropdown component
import './Toolarea.css';

const Texttools = ({
    handleBold,
    handleItalic,
    handleUnderline,
    handleAlign,
    handleColorChange,
    handleCopy,
    handleUppercase,
    handleLowercase,
    handleCapitalize,
    handleTextToSpeech,
    handleGenerateNote,
    handleFindAndReplace,
    handleMark,
    fileInputRef,
    handleClearOldNotes,
    onpenInput,
    toggleVideoVisibility,
    handleFontFamilyChange,
    handleDecreaseFontSize,
    handleIncreaseFontSize,
    onFontFamilyChange,
    handlewikipedia,
    handleYourdictionary,
    hideaboutsection,
    hidecalculator,
    openDrawingAreaToIllustrate,
    convertToHyperlink,
}) => {
    const [toolsVisible, setToolsVisible] = useState(true);

    const toggleToolsVisibility = () => {
        setToolsVisible(!toolsVisible);
    };

    // Hide tools button after 10 seconds on mobile devices
    useEffect(() => {
        if (window.innerWidth <= 900) { // Assuming mobile devices are less than or equal to 768px width
            const timer = setTimeout(() => {
                setToolsVisible(false);
            }, 120000); // 120 seconds
            return () => clearTimeout(timer);
        }
    }, [toolsVisible]);

    const handleGenerateNoteWithLoading = async () => {
        await handleGenerateNote();
    };

    const handleBackgroundColorChange = (event) => {
        document.execCommand('hiliteColor', false, event.target.value);
    };

    const fontFamilies = [
        'Arial', 'Georgia', 'Times New Roman', 'Courier New', 'Verdana',
        'Tahoma', 'Trebuchet MS', 'Impact', 'Comic Sans MS', 'Lucida Console',
        'Serif', 'Sans-serif', 'Monospace', 'Cursive', 'Fantasy', 'Helvetica',
        'Calibri', 'Garamond', 'Open Sans', 'Roboto', 'Lora', 'Merriweather',
        'Montserrat', 'Playfair Display', 'Raleway', 'Source Sans Pro', 'Noto Sans',
        'Ubuntu', 'PT Sans', 'Oswald', 'Poppins', 'Baskerville', 'Fira Sans',
        'Arvo', 'Bebas Neue', 'Quicksand', 'Nunito', 'Alegreya', 'IBM Plex Sans',
        'Exo 2'
    ];

    return (
        <>
            <div className="container-fluid bg-gray-300 flex toolarea justify-between text-capitalize align-middle rounded-md changecolor" style={{ position: 'sticky', top: '0px', zIndex: '100', alignItems: "center" }}>
                <div className="container-fluid gap-1 font-serif text-pretty text-capitalize text-gray-800 text-2xl font-bold" onClick={toggleToolsVisibility} style={{ cursor: 'pointer' }}>
                    <button className='spining font-serif font-extrabold'>
                        <i className="bi bi-gear-wide-connected"></i>
                    </button>
                    Tools
                </div>

                {toolsVisible ? (
                    <div className="container-fluid flex my-1 justify-end toolstools gap-2 toolwrap text-fuchsia-900 font-extrabold text-larger text-sg">
                        <FontDropdown fontFamilies={fontFamilies} onFontFamilyChange={onFontFamilyChange} className="items-center mt-1" />
                        <button className="btn font-bold " onClick={handleBold} title='Text Bold'>
                            <i className="bi bi-type-bold"></i>
                        </button>
                        <button className="btn font-bold " onClick={handleItalic} title='Text Italic'>
                            <i className="bi bi-type-italic"></i>
                        </button>
                        <button className="btn font-bold " onClick={handleUnderline} title='Text Underline'>
                            <i className="bi bi-type-underline"></i>
                        </button>
                        <button className="btn font-bold " onClick={handleMark} title="Mark Text">
                            <i className="bi bi-highlighter"></i>
                        </button>
                        <button className="font-bold btn" onClick={handleIncreaseFontSize} title='Text Increase'>
                            <i className="bi bi-plus-lg"></i>
                        </button>
                        <button className="btn font-extrabold" onClick={handleDecreaseFontSize} title='Text Decrease'>
                            <i className="bi bi-dash-lg"></i>
                        </button>
                        <div className="dropdown " title='Text Formating'>
                            <button className="btn font-bold dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <i className="bi bi-fonts"></i>
                            </button>
                            <ul className="dropdown-menu text-justify">
                                <li>
                                    <button className="dropdown-item btn text-capitalize" onClick={() => handleAlign('Left')}>
                                        <i className="bi bi-text-left"></i> text left
                                    </button>
                                </li>
                                <li>
                                    <button className="dropdown-item btn text-capitalize" onClick={() => handleAlign('Center')}>
                                        <i className="bi bi-text-center"></i> text center
                                    </button>
                                </li>
                                <li>
                                    <button className="dropdown-item btn text-capitalize" onClick={() => handleAlign('Right')}>
                                        <i className="bi bi-text-right"></i> text right
                                    </button>
                                </li>
                                <li>
                                    <button className="dropdown-item btn text-capitalize" onClick={() => handleAlign('Full')}>
                                        <i className="bi bi-justify"></i> text justify
                                    </button>
                                </li>
                                <li>
                                    <button className="dropdown-item btn text-capitalize" onClick={handleUppercase}>
                                        <i className="bi bi-alphabet-uppercase"></i> Uppercase
                                    </button>
                                </li>
                                <li>
                                    <button className="dropdown-item btn text-capitalize" onClick={handleLowercase}>
                                        <i className="bi bi-alphabet"></i> lowercase
                                    </button>
                                </li>
                                <li>
                                    <button className="dropdown-item btn text-capitalize" onClick={handleCapitalize}>
                                        <i className="bi bi-type"></i> capitalize
                                    </button>
                                </li>
                            </ul>
                        </div>


                        {/* /find and replace */}
                        <div className="dropdown" title='Find & Replace'>
                            <button className="btn dropdown-toggle font-bold" data-bs-toggle="dropdown">
                                <i className="bi bi-search"></i>
                            </button>
                            <ul className="dropdown-menu bg-transparent outline-none border-0">
                                <li>
                                    <FindReplace handleFindAndReplace={handleFindAndReplace} className="text-center form-control flex justify-center mt-2" />
                                </li>
                            </ul>
                        </div>


                        {/* text color changer */}
                        <div className="dropdown" title='TextColor'>
                            <button className="btn font-bold dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <i className="bi bi-palette"></i>
                            </button>
                            <ul className="dropdown-menu text-justify">
                                <li>
                                    <button className="dropdown-item btn text-capitalize">
                                        Text colour
                                        <input type="color" className="form-control" onChange={handleColorChange} />
                                    </button>
                                </li>
                                <li>
                                    <button className="dropdown-item btn text-capitalize">
                                        Background colour
                                        <input type="color" className="form-control" onChange={handleBackgroundColorChange} />
                                    </button>
                                </li>
                            </ul>
                        </div>










                        <div className="dropdown" title='Text Utils'>
                            <button className="btn font-bold dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <i className="bi bi-pencil-square"></i>
                            </button>
                            <ul className="dropdown-menu text-justify">
                                <li>
                                    {/*  Insert image from user gallery  */}
                                    <button className="btn font-bold dropdown-item btn text-capitalize" onClick={() => fileInputRef.current.click()} title='Insert Image'>
                                        <i className="bi bi-image"></i> Insert Image
                                    </button>
                                </li>
                                <li>
                                    {/* convert to link */}
                                    <button className="btn font-bold dropdown-item btn text-capitalize" onClick={convertToHyperlink} title="Convet to link">
                                        <i className="bi bi-link"></i> Hyperlink
                                    </button>
                                </li>
                                <li>
                                    {/* Copy all the text */}
                                    <button className="btn font-bold dropdown-item btn text-capitalize" onClick={handleCopy} title='Copy'>
                                        <i className="bi bi-clipboard"></i> Copy Document
                                    </button>
                                </li>
                                <li>
                                    {/* Read text */}
                                    <button className="btn font-bold dropdown-item btn text-capitalize" onClick={handleTextToSpeech} title="Read Text">
                                        <i className="bi bi-volume-up"></i> Read Text
                                    </button>
                                </li>
                            </ul>
                        </div>

                        {/* Ai features of this app */}
                        <div className="dropdown" title='AI Features'>
                            <button className="btn font-bold dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <i className="bi bi-robot"></i>
                            </button>
                            <ul className="dropdown-menu text-justify">
                                <li>
                                    <button className="btn font-bold dropdown-item btn text-capitalize" onClick={onpenInput} title='Generate Image'>
                                        <i className="bi bi-image-alt"></i> Ai Generate Image
                                    </button>
                                </li>
                                <li>
                                    <button className="btn font-bold dropdown-item btn text-capitalize" onClick={handleGenerateNoteWithLoading} title='AI Generated Note'>
                                        <i className="bi bi-magic"></i> Ai generated notes
                                    </button>
                                </li>
                                <li>
                                    {/* open AutoDraw */}
                                    <button className="btn font-bold dropdown-item btn text-capitalize" onClick={openDrawingAreaToIllustrate} title='Open AutoDraw'>
                                        <i className="bi bi-easel-fill"></i> Ai Generated AutoDraw
                                    </button>
                                </li>
                            </ul>
                        </div>







                        {/* Research area */}
                        <div className="dropdown" title='Research Area'>
                            <button className="btn font-bold dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <i className="bi bi-binoculars-fill"></i>
                            </button>
                            <ul className="dropdown-menu text-justify">
                                <li>
                                    <button className='btn font-bold dropdown-item btn text-capitalize' onClick={handleYourdictionary} title='Open Dictionary'>
                                        <i className="bi bi-journals"></i> Dictonary
                                    </button>
                                </li>
                                <li>
                                    <button className='btn font-bold dropdown-item btn text-capitalize' onClick={handlewikipedia} title='Open Wikipedia'>
                                        <i className="bi bi-wikipedia"></i> Wikipedia
                                    </button>
                                </li>
                                <li>
                                    <button className='btn font-bold dropdown-item btn text-capitalize' onClick={hidecalculator} title='About'>
                                        <i className="bi bi-calculator"></i> Calculator
                                    </button>
                                </li>
                            </ul>
                        </div>




                        {/* Why this app */}
                        <div className="dropdown" title='Why This App'>
                            <button className="btn font-bold dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                <i className="bi bi-app-indicator"></i>
                            </button>
                            <ul className="dropdown-menu text-justify">
                                <li>
                                    {/* Add the toggle video button */}
                                    <button className="btn font-bold dropdown-item btn text-capitalize" onClick={toggleVideoVisibility} title="Toggle Video Player">
                                        <i className="bi bi-play-circle-fill"></i> Video Tutorial
                                    </button>
                                </li>
                                <li>
                                    <button className='btn font-bold dropdown-item btn text-capitalize' onClick={hideaboutsection} title='About'>
                                        <i className="bi bi-person-check-fill"></i> About The App
                                    </button>
                                </li>
                            </ul>
                        </div>




                        {/* Delete all notes */}
                        <div className="dropdown" title='Delete all notes'>
                            <button className='btn font-bold dropdown-toggle' data-bs-toggle="dropdown" aria-expanded="false">
                                <i className="bi bi-trash3-fill"></i>
                            </button>
                            <ul className='dropdown-menu text-justify bg-transparent outline-none border-0'>
                                <li>
                                    <button className="font-bold css-button-shadow-border-sliding--red" onClick={handleClearOldNotes}>
                                        <i className="bi bi-trash3-fill"></i> All Notes
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                ) : (
                    <i className="bi bi-caret-down-fill mobileshow text-gray-900 text-2xl" onClick={toggleToolsVisibility}></i>
                )}
            </div>
        </>
    );
};

export default Texttools;
