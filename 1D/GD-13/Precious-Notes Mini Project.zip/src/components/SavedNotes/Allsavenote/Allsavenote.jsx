import React, { useState, useEffect } from 'react';
import './Allsavenote.css';
import { AiFillDelete, AiFillEdit, AiOutlineShareAlt } from 'react-icons/ai';
import Downloadnotes from '../../Downloadbutton/Downloadnotes';

const Allsavenote = (props) => {
    const [cardColor, setCardColor] = useState('');

    // Generate random light color with good visibility for black text
    const generateRandomColor = () => {
        const r1 = Math.floor(Math.random() * 56 + 200); // Generates a number between 200 and 255
        const g1 = Math.floor(Math.random() * 56 + 200);
        const b1 = Math.floor(Math.random() * 56 + 200);
    
        const r2 = Math.floor(Math.random() * 56 + 200);
        const g2 = Math.floor(Math.random() * 56 + 200);
        const b2 = Math.floor(Math.random() * 56 + 200);
    
        const color1 = `rgba(${r1}, ${g1}, ${b1})`;
        const color2 = `rgba(${r2}, ${g2}, ${b2})`;
    
        return `linear-gradient(to right, ${color1}, ${color2})`;
    };
    
    useEffect(() => {
        setCardColor(generateRandomColor());
    }, []);

    const handleShareNote = () => {
        const { title, content } = props;
    
        // Function to convert HTML to plain text, preserving line breaks
        const convertToPlainText = (htmlString) => {
            const tempElement = document.createElement('div');
            tempElement.innerHTML = htmlString;
            let plainText = tempElement.innerText || tempElement.textContent;
            plainText = plainText.replace(/\n/g, '\n');
            return plainText;
        };
    
        // Convert title and content to plain text
        const plainTextTitle = convertToPlainText(title);
        const plainTextContent = convertToPlainText(content);
    
        const shareData = {
            title: plainTextTitle,
            text: `Title: \n ${plainTextTitle}\n\n Content: \n${plainTextContent}`,
            // // Including the URL only if needed
            // url: window.location.href
        };
    
        if (navigator.share) {
            navigator.share(shareData)
                .then(() => {
                    props.notifySuccess('Note shared successfully');
                })
                .catch((error) => {
                    console.error('Error sharing note:', error);
                    props.notifyError('Error sharing note: ' + error.message);
                });
        } else {
            props.notifyError('Share functionality is not supported in your browser.');
        }
    };
    
    

    return (
        <div className="container-fluid mt-3">
            <div className="card mb-3 cardanimation" style={{ background: cardColor}}>
                <div className="card-body">
                    <h5 className="card-title text-capitalize" dangerouslySetInnerHTML={{ __html: props.title }}></h5>
                    <p className="card-text" style={{ overflow: 'hidden', textAlign: 'justify', textOverflow: 'ellipsis', whiteSpace: 'nowrap', height: '1.8in', maxHeight: '1.8in' }} dangerouslySetInnerHTML={{ __html: props.content }}>
                    </p>
                    <div className="flex justify-between jiophonealignment mt-2" style={{ alignItems: "center", flexWrap: 'wrap' }}>
                        <button className="css-button-shadow-border-sliding--red" data-bs-toggle="modal" data-bs-target={`#exampleModal${props.index}`} title='Read your note...'>Read Note...
                        </button>
                        <div className="flex justify-evenly jiophonebtn">
                            <button className='btn rounded-lg' title='edit note...'>
                                <AiFillEdit onClick={() => props.onEdit(props.index)} style={{ cursor: 'pointer', fontSize: '1.5rem', color: 'red' }} />
                            </button>
                            <button className='rounded-lg' title='Download note...'>
                                <Downloadnotes title={props.title} content={props.content} />
                            </button>
                            <button className='btn rounded-lg' title='Share note...'>
                                <AiOutlineShareAlt onClick={handleShareNote} style={{ cursor: 'pointer', fontSize: '1.5rem', color: 'red' }} />
                            </button>
                            <button className='btn rounded-lg position-relative right-1' title='Delete note...'>
                                <AiFillDelete onClick={() => props.onDelete(props.index)} style={{ cursor: 'pointer', fontSize: '1.5rem', color: 'red' }} />
                            </button>
                        </div>
                    </div>
                    <div className="dateandtimecreatedarea mt-2">
                        <div className="text-start text-capitalize font-bold text-blue-900">
                            Created on :  {props.date} at {props.time}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Allsavenote;
