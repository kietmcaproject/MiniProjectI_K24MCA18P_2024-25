import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './Appusermanual.css';

const Appusermanual = () => {
    const [isVisible, setIsVisible] = useState(false);

    const toggleVisibility = () => {
        setIsVisible(!isVisible);
    };

    return (
        <div className="container-fluid  my-2 p-4 bg-light rounded shadow">
            <div className="container-fluid flex justify-between items-center inmobile" style={{ alignItems: 'center' }}>
                <button title='show/hide' className="bg-red-900 rounded-circle text-white p-2 " onClick={toggleVisibility} style={{ width: "50px" }}>
                    <i className={`bi ${isVisible ? 'bi-eye-slash' : 'bi-eye'}`} style={{ fontSize: '1.5rem' }}></i>
                </button>
                {isVisible ? '' : <h5 className="text-gray-900 font-bold text-right card-title text-2xl">
                    PreciousNotes...
                </h5>}
            </div>
            {
                isVisible && (
                    <>
                        <h1 className="text-gray-900 font-bold m-4 text-center text-3xl">
                            PreciousNotes User Manual
                        </h1>
                        <p className="text-secondary lead mb-5 text-left">
                            Welcome to the PreciousNotes App User Manual. This guide is designed to help you understand how to use the PreciousNotes app effectively.
                        </p>
                        <ul className="list-unstyled">
                            <li className="media my-4">
                                <i className="bi bi-plus-circle-fill text-primary mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 1: Create a New Note</h5>
                                    Click the "New Note" button to start a new note. This will open a blank note where you can enter your title and content.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-pencil-fill text-success mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 2: Add a Title and Content</h5>
                                    Enter a descriptive title and your note content in the respective fields. Make sure to save your note after editing.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-save-fill text-info mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 3: Save Your Note</h5>
                                    Click the "Save" button to save your note. Notes are automatically saved to local storage and can be accessed anytime.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-search text-warning mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 4: Search Notes</h5>
                                    Use the search bar to find specific notes by typing in keywords from the title or content.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-trash-fill text-danger mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 5: Delete Notes</h5>
                                    To delete a note, click the delete button next to the note you wish to remove. Confirm your action in the popup dialog.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-pencil-square text-info mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 6: Edit Notes</h5>
                                    To edit a note, click the edit button next to the note. Modify the title and content as needed and save the changes.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-image text-primary mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 7: Insert Images</h5>
                                    Use the "Insert Image" option to add images to your notes. You can fetch images from Unsplash or Pexels.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-volume-up-fill text-warning mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 8: Text-to-Speech</h5>
                                    Highlight the text you want to be read aloud and click the "Text-to-Speech" button to listen to your note.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-clock-history text-secondary mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 9: Clear Old Notes</h5>
                                    Click the "Clear Old Notes" button to delete notes older than 30 days, freeing up space in your storage.
                                </div>
                            </li>
                            <li className="media my-4">
                                <i className="bi bi-play-circle-fill text-info mr-3" style={{ fontSize: '2rem' }}></i>
                                <div className="media-body">
                                    <h5 className="mt-0 mb-1">Step 10: Toggle Video</h5>
                                    Use the toggle button to show or hide the video container that provides instructional videos.
                                </div>
                            </li>
                        </ul>
                    </>
                )
            }
        </div>
    );
}

export default Appusermanual;
