import React, { useState, useRef } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faBookOpen, faVolumeUp } from '@fortawesome/free-solid-svg-icons';
import { Oval } from 'react-loader-spinner';

const Dictionary = () => {
    const [word, setWord] = useState('');
    const [meaning, setMeaning] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);
    const [isReading, setIsReading] = useState(false);
    const speechSynthesisRef = useRef(null);

    const fetchWordMeaning = async () => {
        setLoading(true);
        try {
            const response = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
            if (!response.ok) {
                throw new Error('Word not found');
            }
            const data = await response.json();
            setMeaning(data[0].meanings);
            setError(null);
        } catch (err) {
            setError(err.message);
            setMeaning(null);
        }
        setLoading(false);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        fetchWordMeaning();
    };

    const handleSpeechToggle = (text) => {
        if (isReading) {
            speechSynthesisRef.current.cancel();
            setIsReading(false);
        } else {
            const utterance = new SpeechSynthesisUtterance(text);
            speechSynthesisRef.current = window.speechSynthesis;
            speechSynthesisRef.current.speak(utterance);
            setIsReading(true);
            utterance.onend = () => setIsReading(false);
        }
    };

    return (
        <div className="container-fluid w-100  mt-3 max-h-lg  flex items-center justify-center p-4">
            <div className="container max-w-lg mx-auto p-8 bg-white shadow-xl rounded-lg">
                <header className="text-center mb-6">
                    <h1 className="text-4xl font-bold text-gray-800 mb-4">
                        <FontAwesomeIcon icon={faBookOpen} className="text-teal-400 mr-2" />
                        PreciousNotes...  Dictionary
                    </h1>
                    <form onSubmit={handleSubmit} className="flex flex-col md:flex-row items-center justify-center gap-4">
                        <input
                            type="search"
                            value={word}
                            onChange={(e) => setWord(e.target.value)}
                            placeholder="Enter a word"
                            required
                            className="form-control w-full md:w-2/3 p-3 border border-gray-300 rounded-lg"
                        />
                        <button type="submit" className="btn btn-outline-success px-4 py-3 rounded-lg">
                            <FontAwesomeIcon icon={faSearch} className="mr-2" />
                        </button>
                    </form>
                    {error && <p className="text-red-500 mt-4">{error}</p>}
                </header>
                {loading && (
                    <div className="flex justify-center mt-4">
                        <Oval color="#E91E63" height={50} width={50} />
                    </div>
                )}
                {meaning && (
                    <div className="mt-6">
                        <h2 className="text-2xl font-semibold text-gray-700 mb-4">Meanings of : {word}</h2>
                        <button
                            onClick={() => handleSpeechToggle(`Meanings for ${word}: ${meaning.map(meaningItem => meaningItem.definitions.map(def => def.definition).join('. ')).join('. ')}`)}
                            className="btn btn-secondary mb-4"
                        >
                            <FontAwesomeIcon icon={faVolumeUp} className="mr-2" />
                            {isReading ? 'Stop Reading' : 'Read Aloud'}
                        </button>
                        {meaning.map((meaningItem, index) => (
                            <div key={index} className="mb-4">
                                <h3 className="text-xl font-medium text-gray-800">Part of Speech: {meaningItem.partOfSpeech}</h3>
                                <ul className="list-disc list-inside pl-4">
                                    {meaningItem.definitions.map((definition, i) => (
                                        <li key={i} className="text-gray-600">{definition.definition}</li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Dictionary;
