import React from 'react'
import './Feedbackform.css'

const Feedbackform = () => {
    return (
        <>
            <div className="my-5 container">
                <iframe src="https://preciousnotesfeedbackform.netlify.app" title='preciousnotesfeedbackform' className='rounded-2xl w-full' height={1200}></iframe>
            </div>
        </>
    );
}

export default Feedbackform;
