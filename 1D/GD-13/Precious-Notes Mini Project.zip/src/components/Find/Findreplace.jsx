import React, { useState } from 'react';

const Findreplace = ({ handleFindAndReplace }) => {
    const [findWord, setFindWord] = useState('');
    const [replaceWord, setReplaceWord] = useState('');

    const handleFindChange = (event) => setFindWord(event.target.value);
    const handleReplaceChange = (event) => setReplaceWord(event.target.value);

    const handleFindReplace = () => {
        handleFindAndReplace(findWord, replaceWord);
    };

    return (
        <div className="find-replace-container mt-1">
            <input 
                type="search" 
                placeholder="Find" 
                value={findWord} 
                className='form-control mt-1 mb-1'
                onChange={handleFindChange} 
            />
            <input 
                type="search" 
                placeholder="Replace" 
                value={replaceWord} 
                className='form-control mt-1 mb-1'
                onChange={handleReplaceChange} 
            />
            <button className='btn btn-danger mt-1 mb-1' onClick={handleFindReplace}>Find & Replace</button>
        </div>
    );
};

export default Findreplace;
