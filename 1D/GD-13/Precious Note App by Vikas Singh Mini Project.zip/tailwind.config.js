/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#ff4500', // Example primary color for your app
        secondary: '#1e90ff', // Example secondary color
        text: '#333333', // Example text color
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'], // Example custom font
        serif: ['Merriweather', 'serif'],
      },
      spacing: {
        '128': '32rem', // Example custom spacing
        '144': '36rem',
      },
      borderRadius: {
        'xl': '1.5rem', // Example custom border radius
      },
    },
  },
  plugins: [],
}
