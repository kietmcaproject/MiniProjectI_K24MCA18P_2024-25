

import './App.css';
import Bottomnavbar from './components/Bottomnavbar/Bottomnavbar';
import Navbar from './components/Navbar/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';
import About from './components/About/About';
import { HashRouter, Routes, Route } from 'react-router-dom';
import useScrollToTop from './components/ScrollToTop/useScrollToTop';
import Mainapp from './components/Mainapp/Mainapp';
import Footer from './components/Footer/Footer';
import Feedbackform from './components/feedbackform/Feedbackform';



function App() {
  useScrollToTop();
  console.clear();


  return (
    <>

      <HashRouter>
        <Navbar />
        <Bottomnavbar />
        <Routes>
          <Route path='/' index element={<Mainapp />} />
          <Route path='/home' element={<Mainapp />} />
          <Route path="/about" element={<About />} />
          <Route path="/feedbackform" element={<Feedbackform/>} />
          <Route path="*" element={<h1 className='text-red-700 text-capitalize text-center flex justify-center items-center'>(404) page is not found...</h1>} />
        </Routes>
        <Footer />
      </HashRouter>

    </>
  );
}



export default App;
