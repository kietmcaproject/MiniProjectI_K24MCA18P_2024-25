import React from 'react';
import { FaFacebook, FaLinkedin, FaGithub, FaInstagram } from 'react-icons/fa';
import './About.css';

const About = () => {
  return (
    <div className="about-container">
      <div className="about-content">
        <h1 className="about-title">About Our App Developed By Vikas Singh</h1>
        <p className="about-description text-justify ">
          Our app is a versatile tool designed to boost productivity and streamline task management. Users can effortlessly create, edit, and delete notes, with automatic timestamps for easy organization. The app features robust text formatting tools, allowing users to apply bold, italic, and underline styles, align text, and change text color, enhancing the readability and visual appeal of their notes. Additionally, users can transform text to uppercase, lowercase, or capitalize each word for consistency.

          A standout feature is the search functionality, which enables quick retrieval of notes by keywords in the title or content, saving time and effort. The app also includes a copy-to-clipboard feature, allowing users to easily share note content across different platforms and applications.

          Designed with a user-friendly interface, the app is accessible to users of all technical backgrounds, making it an ideal tool for students, professionals, and anyone looking to enhance personal productivity. By offering these comprehensive features, the app helps users organize, retrieve, and share information efficiently, saving valuable time and reducing stress. Our app empowers users to focus on what truly matters, achieving their goals more effectively.
        </p>
        <div className="social-media-icons">
          <a href="https://www.facebook.com/profile.php?id=100017086654558" target="_blank" rel="noopener noreferrer">
            <FaFacebook />
          </a>
          <a href="https://www.instagram.com/me.vikassingh/" target="_blank" rel="noopener noreferrer">
            <FaInstagram />
          </a>
          <a href="https://www.linkedin.com/in/vikas-singh-877789203/" target="_blank" rel="noopener noreferrer">
            <FaLinkedin />
          </a>
          <a href="https://github.com/Iamvikassingh/Iamvikassingh" target="_blank" rel="noopener noreferrer">
            <FaGithub />
          </a>
        </div>
        <p className="portfolio-link">
          <a href="https://myportfoliobyvikassingh.netlify.app" target="_blank" rel="noopener noreferrer">
            Check out my portfolio
          </a>
        </p>
      </div>
    </div>
  );
}

export default About;
