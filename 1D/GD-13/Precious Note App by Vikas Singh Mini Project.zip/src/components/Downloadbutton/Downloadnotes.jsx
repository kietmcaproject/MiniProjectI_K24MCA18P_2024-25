import React from 'react';
import { saveAs } from 'file-saver';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

const Downloadnotes = ({ title, content }) => {
    // Helper function to convert HTML to formatted plain text
    const convertHtmlToPlainText = (html) => {
        const tempElement = document.createElement('div');
        tempElement.innerHTML = html;

        const walkNodes = (node) => {
            let text = '';

            node.childNodes.forEach((child) => {
                if (child.nodeType === Node.TEXT_NODE) {
                    text += child.textContent;
                } else if (child.nodeType === Node.ELEMENT_NODE) {
                    if (child.tagName === 'BR') {
                        text += '\n';
                    } else if (child.tagName === 'P') {
                        text += walkNodes(child) + '\n\n';
                    } else if (child.tagName === 'DIV') {
                        text += walkNodes(child) + '\n';
                    } else if (child.tagName === 'IMG') {
                        text += '[Image]'; // Placeholder for image in plain text
                    } else {
                        text += walkNodes(child);
                    }
                }
            });

            return text;
        };

        return walkNodes(tempElement).trim();
    };

    const handleDownloadTxt = () => {
        const plainTextTitle = convertHtmlToPlainText(title);
        const plainTextContent = convertHtmlToPlainText(content);
        const txtContent = `Title:\n${plainTextTitle}\n\nContent:\n${plainTextContent}`;
        const blob = new Blob([txtContent], { type: 'text/plain;charset=utf-8' });
        saveAs(blob, `${plainTextTitle.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.txt`);
    };

    const handleDownloadPdf = async () => {
        const plainTextTitle = convertHtmlToPlainText(title);
        const contentElement = document.createElement('div');
        contentElement.innerHTML = content;
    
        // Set the content element's style to match the original HTML for rendering
        contentElement.style.position = 'absolute';
        contentElement.style.left = '-9999px';
        document.body.appendChild(contentElement);
    
        const canvas = await html2canvas(contentElement, { scale: 2 });
        document.body.removeChild(contentElement);
    
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF({
            orientation: 'portrait',
            unit: 'mm',
            format: 'a4'
        });
    
        const margin = 10;
        const pageHeight = pdf.internal.pageSize.height;
        const pageWidth = pdf.internal.pageSize.width;
        const pdfWidth = pageWidth - 2 * margin;
    
        // Set title font size
        pdf.setFontSize(18);
        pdf.text(`Title:\n${plainTextTitle}`, margin, 20);
    
        // Set content font size
        pdf.setFontSize(14);
    
        const contentText = convertHtmlToPlainText(content);
        const lines = pdf.splitTextToSize(contentText, pdfWidth);
    
        let yPosition = 40; // Ensure there's space between title and content
    
        lines.forEach(line => {
            // Check if the next line fits on the current page
            if (yPosition + 10 > pageHeight) {
                pdf.addPage();
                yPosition = 10; // Reset y position for new page
            }
            if (yPosition + 10 <= pageHeight) {
                pdf.text(line, margin, yPosition);
                yPosition += 10; // Line height
            }
        });
    
        // Add content image to the PDF and handle page overflow
        const imgProps = pdf.getImageProperties(imgData);
        const imgHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
        if (yPosition + imgHeight > pageHeight) {
            pdf.addPage();
            yPosition = 10; // Reset y position for new page
        }
  
    
        // Save the PDF with the title as the filename
        try {
            pdf.save(`${plainTextTitle.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.pdf`);
        } catch (error) {
            console.error("Error while saving PDF:", error);
        }
    };
    

    return (
        <div style={{textWrap:"wrap"}}>
            <button onClick={handleDownloadTxt} className='btn' style={{ cursor: 'pointer', fontSize: '1.5rem', color: 'red' }}>
                <i className="bi bi-filetype-txt"></i>
            </button>
            <button onClick={handleDownloadPdf} className='btn' style={{ cursor: 'pointer', fontSize: '1.5rem', color: 'red' }}>
                <i className="bi bi-filetype-pdf"></i>
            </button>
        </div>
    );
};

export default Downloadnotes;
