import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Container } from 'react-bootstrap';
import { FaExpand, FaCompress } from 'react-icons/fa';

const VideoContainer = () => {
    const [isVisible, setIsVisible] = useState(false);
    const [isFullScreen, setIsFullScreen] = useState(false);

    const toggleVisibility = () => setIsVisible(!isVisible);

    const toggleFullScreen = () => {
        const videoElement = document.getElementById('videoElement');
        if (!document.fullscreenElement) { // Check if not in fullscreen
            if (videoElement.requestFullscreen) {
                videoElement.requestFullscreen();
            } else if (videoElement.webkitRequestFullscreen) { /* Safari */
                videoElement.webkitRequestFullscreen();
            } else if (videoElement.msRequestFullscreen) { /* IE11 */
                videoElement.msRequestFullscreen();
            }
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) { /* Safari */
                document.webkitExitFullscreen();
            } else if (document.msExitFullscreen) { /* IE11 */
                document.msExitFullscreen();
            }
        }
        setIsFullScreen(!isFullScreen);
    };

    // video link is here
    // const introvideo = 'https://youtu.be/9hMC7NA0yMw?si=YFoEB3F7-apsetUM';
    return (
        <>
            <div className="bg-white p-10 rounded-lg shadow-lg container-fluid">
                <div className="flex justify-between my-4">
                    <div className="container">
                        <h4 className='text-gray-900 font-bold card-text text-3xl text-capitalize'>
                            video how to use your notes...
                        </h4>
                        <p className='text-sm text-capitalize text-wrap card-text'>tap to see the video</p>
                    </div>
                    <button onClick={toggleVisibility} className=" text-red-600 font-bold text-3xl">
                        {isVisible ? <i class="bi bi-pause-circle-fill"></i> : <i class="bi bi-play-circle-fill"></i>}
                    </button>
                </div>
                {isVisible && (
                    <Container className="relative  max-w-5xl rounded-lg shadow-lg overflow-hidden">
                        
                        <iframe id="videoElement" className="w-full" height={"350px"} src="https://www.youtube.com/embed/ZpLkKAY3uGE?si=WtRlVtxhiTw406Qh" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                        <button
                            onClick={toggleFullScreen}
                            className="absolute top-2 right-2 p-2 bg-black text-white rounded-full hover:bg-gray-700"
                            variant="secondary"
                        >
                            {isFullScreen ? <FaCompress /> : <FaExpand />}
                        </button>
                    </Container>
                )}
            </div>

        </>

    );
};

export default VideoContainer;
