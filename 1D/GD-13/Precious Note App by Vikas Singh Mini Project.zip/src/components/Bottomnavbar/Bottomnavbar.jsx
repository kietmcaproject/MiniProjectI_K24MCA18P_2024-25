import React from 'react'
import './Bottomnav.css'
import { Link } from 'react-router-dom'
import { Container, Row } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import APKDownload from '../../Assets/Notes.apk'
const Bottomnavbar = () => {
    const handleRefreshPage = () => {
        window.location.reload();
    };
    return (
        <>
            <div className="bg-gray-800 text-2xl" style={{ boxShadow: "1px 36px 80px rgba(0, 0, 0, 0.21)" }}>
                <div className="text-white text-capitalize implink">
                    <nav>
                        <ul className='mobileviewbottomnavbar d-flex justify-between mx-2' style={{ alignItems: "center" }}>
                            <div className="container-fluid">
                                <li className='mobileviewbottomnavbar'>
                                    <Link to="/home">Home</Link>
                                    <Link to="/about">About</Link>
                                    <Link to="https://myportfoliobyvikassingh.netlify.app/" target='_blank' rel="noreferrer noopener" >Visit portfolio</Link>
                                    <Link to="/feedbackform">Feedback form</Link>
                                </li>
                            </div>
                            <div className='d-flex justify-end items-center gap-4 container-fluid'>
                                <li>
                                    <Container fluid>
                                        <Row>
                                            <Button
                                                variant=" btn-outline-secondary"
                                                href={APKDownload}
                                                target="_blank"
                                                className="d-flex items-center gap-1 m-1 btn-sm"
                                                title="Download Android APK"
                                            >
                                                <i className="text-green-500 bi bi-android2"></i>
                                                Download Android APK
                                            </Button>
                                        </Row>
                                    </Container>
                                </li>
                                <li className='mobileviewbottomnavbar d-flex my-1 text-white text-capitalize' onClick={handleRefreshPage} style={{ fontSize: '18px' }}>
                                    <button title="Refresh Page" className="font-bold text-white btn spining">
                                        <i className="bi-arrow-clockwise bi"></i>
                                    </button>
                                </li>
                            </div>
                        </ul>
                    </nav>
                </div>
            </div>
        </>
    )
}

export default Bottomnavbar
