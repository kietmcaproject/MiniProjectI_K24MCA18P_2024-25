import React, { useState } from 'react';
import './YourNotesCalculator.css';
import { evaluate } from 'mathjs';

const YourNotesCalculator = () => {
  const [display, setDisplay] = useState('');

  const handleButtonClick = (value) => {
    if (value === 'C') {
      setDisplay('');
    } else if (value === '=') {
      try {
        setDisplay(evaluate(display).toString());
      } catch {
        setDisplay('Error');
      }
    }else if(value === "<"){
      setDisplay(display.slice(0,-1));
    } else {
      setDisplay(display + value);
    }
  };

  const buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+',
    'C', '<'
  ];

  return (
    <div className="calculator">
      <div className="calculator__display "
      style={{overflowX:"scroll",scrollBehavior:"smooth",scrollbarWidth:"none"}}>{display}</div>
      <div className="calculator__buttons">
        {buttons.map((btn, index) => (
          <button
            key={index}
            className="calculator__button"
            onClick={() => handleButtonClick(btn)}
          >
            {btn}
          </button>
        ))}
      </div>
    </div>
  );
};

export default YourNotesCalculator;
