import React, { useState, useEffect } from 'react';
import 'bootstrap-icons/font/bootstrap-icons.css';

const VisitorCounter = () => {
  const [visitorCount, setVisitorCount] = useState(0);
  const [finalCount, setFinalCount] = useState(162);

  useEffect(() => {
    const updateVisitorCount = () => {
      let visitorData = localStorage.getItem('visitorData');
      if (!visitorData) {
        visitorData = JSON.stringify({ count: 0, ips: [] });
        localStorage.setItem('visitorData', visitorData);
      }

      visitorData = JSON.parse(visitorData);
      const clientIp = getClientIp();

      if (!visitorData.ips.includes(clientIp)) {
        visitorData.count += 1;
        visitorData.ips.push(clientIp);
        localStorage.setItem('visitorData', JSON.stringify(visitorData));
        setVisitorCount(visitorData.count);
      } else {
        setVisitorCount(visitorData.count);
      }
    };

    updateVisitorCount();
  }, []);

  useEffect(() => {
    setFinalCount(162 + visitorCount);
  }, [visitorCount]);

  // Function to get client IP (simulated for demonstration)
  const getClientIp = () => {
    // Simulate getting client IP (replace with actual logic if needed)
    return '127.0.0.1';
  };

  return (
    <div className="flex items-center justify-center w-100 my-2">
      <div className="bg-white p-10 rounded-lg shadow-lg text-center container-fluid">
        <h1 className="text-3xl font-bold mb-4 text-capitalize">Our users...</h1>
        <div className="flex items-center justify-center mb-4">
          <i className="bi bi-people-fill text-6xl text-lime-500"></i>
        </div>
        <div className="text-5xl font-bold text-blue-600">
          <RunningCounter initialCount={finalCount} />
          +{visitorCount}
        </div>
      </div>
    </div>
  );
};

// Running Counter Component
const RunningCounter = ({ initialCount }) => {
  const [currentCount, setCurrentCount] = useState(initialCount);

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentCount((prevCount) => prevCount + 1);
    }, 10000); // Increment every 10 seconds

    return () => clearInterval(intervalId); // Cleanup on unmount
  }, []);

  return <>{currentCount}</>;
};

export default VisitorCounter;
