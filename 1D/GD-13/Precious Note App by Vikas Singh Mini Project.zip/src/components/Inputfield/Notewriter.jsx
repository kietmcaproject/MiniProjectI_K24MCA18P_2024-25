import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';
import './Notewriter.css';

const Notewriter = ({ passNote, editNote, titleRef, contentRef, fileInputRef, notifySuccess, notifyError }) => {
    const [notes, setNotes] = useState([{ title: '', content: '' }]);
    const [currentTab, setCurrentTab] = useState(0);

    useEffect(() => {
        if (editNote) {
            setNotes([{ title: editNote.title, content: editNote.content }]);
            setCurrentTab(0);
            if (titleRef.current) {
                titleRef.current.innerHTML = editNote.title;
            }
            if (contentRef.current) {
                contentRef.current.innerHTML = editNote.content;
            }
        }
    }, [editNote, titleRef, contentRef]);

    const addEvent = () => {
        if (notes[currentTab].title.trim() === '' || notes[currentTab].content.trim() === '') {
            notifyError("Both title and content must be filled out to add a note.");
            return;
        } else {
            notifySuccess("Your note successfully added.");
        }
        passNote(notes[currentTab]);
        setNotes([...notes, { title: '', content: '' }]);
        setCurrentTab(notes.length);
        if (titleRef.current) {
            titleRef.current.innerHTML = '';
        }
        if (contentRef.current) {
            contentRef.current.innerHTML = '';
        }
    };

    const clearContent = () => {
        const updatedNotes = [...notes];
        updatedNotes[currentTab] = { title: '', content: '' };
        setNotes(updatedNotes);
        if (contentRef.current || titleRef.current) {
            contentRef.current.innerHTML = '';
            titleRef.current.innerHTML = '';
        }
    };

    const handleImageUpload = (event) => {
        const files = event.target.files;
        if (files.length === 0) return;

        Array.from(files).forEach(file => {
            if (file.size > 3 * 1024 * 1024) {
                alert('File size exceeds 3MB. Please upload a smaller file.');
                return;
            }

            const reader = new FileReader();
            reader.onload = (e) => {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.style.width = '100%';
                img.style.height = 'auto';

                const resizableBox = document.createElement('div');
                resizableBox.classList.add('resizable-box');

                const ResizableComponent = () => (
                    <ResizableBox
                        width={200}
                        height={200}
                        minConstraints={[100, 100]}
                        maxConstraints={[300, 300]}
                        resizeHandles={['se']}
                    >
                        <img src={img.src} alt="Uploaded" style={{ width: '100%', height: '100%' }} />
                    </ResizableBox>
                );

                ReactDOM.render(<ResizableComponent />, resizableBox);

                const alignDiv = document.createElement('div');
                alignDiv.style.textAlign = 'center';
                alignDiv.appendChild(resizableBox);

                const selection = window.getSelection();
                if (selection.rangeCount > 0) {
                    const range = selection.getRangeAt(0);
                    range.insertNode(alignDiv);
                    range.collapse(false);
                } else {
                    contentRef.current.appendChild(alignDiv);
                }

                const updatedNotes = [...notes];
                updatedNotes[currentTab] = {
                    ...updatedNotes[currentTab],
                    content: contentRef.current.innerHTML
                };
                setNotes(updatedNotes);
            };
            reader.readAsDataURL(file);
        });

        event.target.value = '';
    };

    const handleTabSwitch = (index) => {
        setCurrentTab(index);
        if (titleRef.current) {
            titleRef.current.innerHTML = notes[index].title;
        }
        if (contentRef.current) {
            contentRef.current.innerHTML = notes[index].content;
        }
    };

    const addNewTab = () => {
        setNotes([...notes, { title: '', content: '' }]);
        setCurrentTab(notes.length);
        if (titleRef.current) {
            titleRef.current.innerHTML = '';
        }
        if (contentRef.current) {
            contentRef.current.innerHTML = '';
        }
    };

    const deleteTab = (index) => {
        if (notes.length === 1) {
            notifyError("You can't delete the last tab.");
            return;
        }
        const updatedNotes = notes.filter((_, i) => i !== index);
        setNotes(updatedNotes);
        setCurrentTab(currentTab === index ? 0 : (currentTab > index ? currentTab - 1 : currentTab));
        if (titleRef.current) {
            titleRef.current.innerHTML = updatedNotes[currentTab === index ? 0 : (currentTab > index ? currentTab - 1 : currentTab)].title;
        }
        if (contentRef.current) {
            contentRef.current.innerHTML = updatedNotes[currentTab === index ? 0 : (currentTab > index ? currentTab - 1 : currentTab)].content;
        }
    };

    return (
        <>

            <div className='flex justify-end mt-2' title='New Tab'>
                <button className="btn btn-success" onClick={addNewTab}>
                    <i className="bi bi-plus-circle"></i>
                </button>
            </div>
            <div className="tab-container flex-wrap my-2">
                {notes.map((note, index) => (
                    <div key={index} className="tab-wrapper flex gap-2">
                        <button
                            className={`${index === currentTab ? 'active' : ''} btn btn-outline-dark`}
                            onClick={() => handleTabSwitch(index)}
                        >
                            {index + 1}
                        </button>
                        <button className="btn btn-danger" onClick={() => deleteTab(index)}>
                            <i className="bi bi-x"></i>
                        </button>
                    </div>
                ))}
            </div>

            <div className="mb-3">
                <label htmlFor="exampleFormControlInput1" className="form-label font-bold">Topic</label>
                <div
                    contentEditable
                    className="form-control"
                    id="exampleFormControlInput1"
                    placeholder="Topic Name"
                    onInput={(e) => {
                        const updatedNotes = [...notes];
                        updatedNotes[currentTab].title = e.currentTarget.innerHTML;
                        setNotes(updatedNotes);
                    }}
                    ref={titleRef}
                />
            </div>

            <div className="form-floating">
                <div
                    contentEditable
                    className="form-control mobilenotwriter"
                    placeholder="write your note here"
                    id="floatingTextarea"
                    style={{ height: '60vh', overflowY: 'scroll', maxHeight: '60vh', border: 'none' }}
                    onInput={(e) => {
                        const updatedNotes = [...notes];
                        updatedNotes[currentTab].content = e.currentTarget.innerHTML;
                        setNotes(updatedNotes);
                    }}
                    ref={contentRef}
                ></div>
                <label htmlFor="floatingTextarea" className="form-label font-bold">Note...</label>
                <input
                    type="file"
                    accept="image/*"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    style={{ display: 'none' }}
                    multiple
                />
                <button className="btn btn-danger btn mb-2 mt-2 css-button-shadow-border-sliding--red" onClick={addEvent}>
                    {editNote ? "Update Note..." : "Save Note..."}
                </button>
                <button className="btn btn-danger btn mt-2 ml-2 mb-2" onClick={clearContent}>
                    <i className="bi bi-eraser-fill"></i>
                </button>
            </div>
        </>
    );
};

export default Notewriter;
