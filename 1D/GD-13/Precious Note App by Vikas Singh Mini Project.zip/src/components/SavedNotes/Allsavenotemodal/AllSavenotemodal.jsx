import React, { useState, useEffect } from 'react';
import './Allsavenotemodal.css';

const AllSavenotemodal = (props) => {
    const [dateColor, setDatecolor] = useState('');

    const Datetimechangecolore = () => {
        const r1 = Math.floor(Math.random() * 56 + 200); // Generates a number between 200 and 255
        const g1 = Math.floor(Math.random() * 56 + 200);
        const b1 = Math.floor(Math.random() * 56 + 200);

        const r2 = Math.floor(Math.random() * 56 + 200);
        const g2 = Math.floor(Math.random() * 56 + 200);
        const b2 = Math.floor(Math.random() * 56 + 200);

        const color1 = `rgba(${r1}, ${g1}, ${b1})`;
        const color2 = `rgba(${r2}, ${g2}, ${b2})`;

        return `linear-gradient(to top, ${color1}, ${color2})`;
    }

    useEffect(() => {
        setDatecolor(Datetimechangecolore());
    }, [])


    // Function to convert HTML to formatted plain text
    const convertHtmlToPlainText = (html) => {
        // Create a temporary DOM element
        const tempElement = document.createElement('div');
        tempElement.innerHTML = html;

        // Function to walk through all nodes and convert to plain text
        const walkNodes = (node) => {
            let text = '';

            // Traverse each child node
            node.childNodes.forEach((child) => {
                if (child.nodeType === Node.TEXT_NODE) {
                    text += child.textContent;
                } else if (child.nodeType === Node.ELEMENT_NODE) {
                    if (child.tagName === 'BR') {
                        text += '\n';
                    } else if (child.tagName === 'P') {
                        text += walkNodes(child) + '\n\n';
                    } else if (child.tagName === 'DIV') {
                        text += walkNodes(child) + '\n';
                    } else {
                        text += walkNodes(child);
                    }
                }
            });

            return text;
        };

        return walkNodes(tempElement).trim();
    };

    // Function to handle copying the text
    const handleCopyText = () => {
        const title = convertHtmlToPlainText(props.title);
        const content = convertHtmlToPlainText(props.content);

        // Format the copied text with proper spacing and line breaks
        const combinedText = `Title:\n${title}\n\nContent:\n${content}`;
        navigator.clipboard.writeText(combinedText)
            .then(() => {
                alert('Text copied to clipboard');
            })
            .catch((error) => {
                console.error('Error copying text: ', error);
                alert('Failed to copy text');
            });
    };

    return (
        <>
            <div className="modal fade" id={`exampleModal${props.index}`} tabIndex="-1" aria-labelledby={`exampleModalLabel${props.index}`} aria-hidden="true">
                <div className="modal-dialog modal-dialog-scrollable">
                    <div className="modal-content">
                        <div className="dateandtimecreatedarea p-2" style={{ background: dateColor }}>
                            <div className="text-center text-capitalize font-bold text-blue-900">
                                Created on: {props.date} at {props.time}
                            </div>
                        </div>
                        <div className="modal-header" style={{ borderBottom: "none" }}>
                            <h5 className="modal-title text-capitalize" dangerouslySetInnerHTML={{ __html: props.title }}></h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body col-11 container" dangerouslySetInnerHTML={{ __html: props.content }}></div>
                        <button className="btn font-bold" onClick={handleCopyText}>
                            <i className="bi bi-clipboard"></i> Copy
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
}

export default AllSavenotemodal;
