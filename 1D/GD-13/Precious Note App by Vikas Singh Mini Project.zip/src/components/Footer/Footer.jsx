import React from 'react';
import './Footer.css';
import { FaFacebook, FaLinkedin, FaGithub, FaInstagram, FaEnvelope } from 'react-icons/fa';


const Footer = () => {
    const currentYear = new Date().getFullYear();
    return (
        <>
            <footer className="footer mt-11">
                <div className="container-fluid bg-gray-800 text-white mt-2 px-3 py-3 text-center innerfooter" style={{ textWrap: "wrap" }}>
                    <div className="container-fluid col-5 bg-gray-900 text-white rounded-lg">
                        <center className='text-sm'>
                            Design And Developed By Vikas Singh
                        </center>
                    </div>
                    <div className="social-media-icons d-flex justify-content-center mb-3 jiophonefooter text-right">
                        <a href="https://www.facebook.com/profile.php?id=100017086654558" target="_blank" rel="noopener noreferrer" className="mx-2">
                            <FaFacebook />
                        </a>
                        <a href="https://www.instagram.com/me.vikassingh/" target="_blank" rel="noopener noreferrer" className="mx-2">
                            <FaInstagram />
                        </a>
                        <a href="https://www.linkedin.com/in/vikas-singh-877789203/" target="_blank" rel="noopener noreferrer" className="mx-2">
                            <FaLinkedin />
                        </a>
                        <a href="https://github.com/Iamvikassingh/Iamvikassingh" target="_blank" rel="noopener noreferrer" className="mx-2">
                            <FaGithub />
                        </a>
                        <a
                            href='mailto:9625vikassingh@gmail.com'
                            className='mx-2'
                            style={{ display: 'block', textDecoration: 'none' }}
                        >
                            <FaEnvelope />
                        </a>

                    </div>
                    <p className='text-md text-center text-capitalize'>&copy; {currentYear} Vikas Singh. All rights reserved.</p>
                    <div className="container  flex justify-center gap-2 align-middle" onClick={() => window.location.href = 'mailto:9625vikassingh@gmail.com'} style={{ textOverflow: "ellipsis", alignItems: "center" }}>
                        <p><FaEnvelope className='mx-2' style={{ alignItems: "center" }} /></p>
                        <p className='text-center text-white text-sm' style={{ cursor: 'pointer', textWrap: "wrap" }}>
                            Email : 9625vikassingh@gmail.com
                        </p>
                    </div>
                </div>
            </footer>
        </>
    );
}

export default Footer;
