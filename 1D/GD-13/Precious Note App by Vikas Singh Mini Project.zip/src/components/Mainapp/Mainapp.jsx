import React, { useState, useEffect, useRef } from 'react';
import './Mainapp.css';
import Notewriter from '../Inputfield/Notewriter';
import Allsavenote from '../SavedNotes/Allsavenote/Allsavenote';
import AllSavenotemodal from '../SavedNotes/Allsavenotemodal/AllSavenotemodal';
import Texttools from '../Texttools/Texttools';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { GoogleGenerativeAI } from '@google/generative-ai';
import VideoContainer from '../videocontainer/VideoContainer '; // Import the VideoContainer component
import Appusermanual from '../Appusermanual/Appusermanual';
import Marquee from "react-fast-marquee";
import Dictonary from '../Dictonarycomponent/Dictonary';
import VisitorCounter from '../Visitortracker/VisitorCounter';
import About from '../About/About'
import YourNotesCalculator from '../calculator/YourNotesCalculator ';
import generatedimgaepicphot from '../../Assets/Designer.png'


const MAX_STORAGE_SIZE = 220 * 1024 * 1024; // 220 MB
const Mainapp = () => {
    const [addItem, setAddItem] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [editNote, setEditNote] = useState(null);
    const [isSpeaking, setIsSpeaking] = useState(false);
    const [showInputField, setShowInputField] = useState(false);
    const [inputValue, setInputValue] = useState('');
    const [imageQuery, setImageQuery] = useState('');
    const [imageWidth, setImageWidth] = useState('');
    const [imageHeight, setImageHeight] = useState('');
    const [isImgLoading, setImgIsLoading] = useState(false);
    const [imgInputfield, setImgInputfield] = useState(false)
    const [isVideoVisible, setIsVideoVisible] = useState(false); // State for video container visibility
    const [showWikipedia, setshowWikipedia] = useState(false);
    const [showdictionary, setShowdictionary] = useState(false);
    const [marqueeVisiable, setMarqueeVisiable] = useState(true);
    const [hideAbout, sethideAbout] = useState(false);
    const [openCalculator, setOpencalculator] = useState(false);
    const [openDrawingArea, setOpenDrawingArea] = useState(false);


    const titleRef = useRef(null);
    const contentRef = useRef(null);
    const fileInputRef = useRef(null);

    const API_KEY = process.env.REACT_APP_GENERATIVE_AI_API_KEY;
    const PIXEL_KEY = process.env.REACT_APP_PIXEL_AI_API_KEY;

    const [isLoading, setIsLoading] = useState(false);

    const notifySuccess = (message) => {
        toast.success(message);
    };

    const notifyError = (message) => {
        toast.error(message);
    };
    useEffect(() => {
        const storedNotes = localStorage.getItem('notes');
        if (storedNotes) {
            setAddItem(JSON.parse(storedNotes));
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('notes', JSON.stringify(addItem));
    }, [addItem]);

    const addNote = (Note) => {
        if (editNote !== null) {
            const updatedNotes = addItem.map((item, index) =>
                index === editNote ? { ...item, title: Note.title, content: Note.content } : item
            );
            setAddItem(updatedNotes);
            setEditNote(null);
        } else {
            const currentDate = new Date();
            const date = currentDate.toLocaleDateString();
            const time = currentDate.toLocaleTimeString();
            setAddItem((prevData) => {
                return [{ ...Note, date, time }, ...prevData];
            });
        }
    };

    const handleSearch = (event) => {
        setSearchQuery(event.target.value);
    };

    const handleDelete = (index) => {
        toast.promise(
            new Promise((resolve, reject) => {
                if (window.confirm("Are you sure you want to delete this note?")) {
                    resolve();
                } else {
                    reject();
                }
            }),
            {
                pending: 'Deleting note...',
                success: 'Note deleted!',
                error: 'Note not deleted!'
            }
        ).then(() => {
            setAddItem((prevData) => {
                const updatedNotes = prevData.filter((item, i) => i !== index);
                localStorage.setItem('notes', JSON.stringify(updatedNotes));
                return updatedNotes;
            });
        }).catch((error) => {
            toast.error('User canceled the deletion');
        });
    };


    const handleEdit = (index) => {
        setEditNote(index);
    };

    const filteredNotes = addItem.filter(note =>
        note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        note.content.toLowerCase().includes(searchQuery.toLowerCase())
    );

    useEffect(() => {
        const currentStorageSize = JSON.stringify(addItem).length * 2; // in bytes
        if (currentStorageSize > MAX_STORAGE_SIZE) {
            toast.error('Storage limit exceeded! Please delete some notes to free up space.');
            // Clear the storage and remove all notes
            localStorage.removeItem('notes');
            setAddItem([]);
        }
    }, [addItem]);

    const handleBold = () => document.execCommand('bold');
    const handleItalic = () => document.execCommand('italic');
    const handleUnderline = () => document.execCommand('underline');
    const handleUppercase = () => {
        const selection = window.getSelection();
        if (selection) {
            const text = selection.toString().toUpperCase();
            document.execCommand('insertText', false, text);
        }
    };
    const handleCapitalize = () => {
        const selection = window.getSelection();
        if (selection) {
            const text = selection.toString().replace(/\b\w/g, (char) => char.toUpperCase());
            document.execCommand('insertText', false, text);
        }
    };
    const handleLowercase = () => {
        const selection = window.getSelection();
        if (selection) {
            const text = selection.toString().toLowerCase();
            document.execCommand('insertText', false, text);
        }
    };
    const handleAlign = (align) => {
        // Align text
        document.execCommand('justify' + align);

        // Align images
        const images = document.querySelectorAll('img');
        images.forEach(img => {
            img.style.display = 'block';
            img.style.marginLeft = align === 'Left' ? '0' : align === 'Center' ? 'auto' : 'auto';
            img.style.marginRight = align === 'Right' ? '0' : align === 'Center' ? 'auto' : 'auto';
        });
    };

    const handleColorChange = (event) => document.execCommand('foreColor', false, event.target.value);

    const handleCopy = () => {
        const titleText = titleRef.current.innerHTML;  // Get the HTML content of the title
        const contentText = contentRef.current.innerHTML;  // Get the HTML content of the content

        // Create a temporary element to hold the combined HTML content
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = `${titleText} ${contentText}`;

        // Append the temporary element to the document body
        document.body.appendChild(tempDiv);

        // Create a range and selection to select the temporary element's content
        const range = document.createRange();
        range.selectNodeContents(tempDiv);

        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);

        // Copy the selected content to the clipboard
        document.execCommand('copy');

        // Remove the temporary element from the document body
        document.body.removeChild(tempDiv);

        notifySuccess('Text copied to clipboard');
    };

    const handleTextToSpeech = () => {
        if (!window.speechSynthesis) {
            notifyError("Your browser does not support text-to-speech.");
            return;
        }
        if (isSpeaking) {
            window.speechSynthesis.cancel();
            setIsSpeaking(false);
            return;
        }
        const titleText = titleRef.current.innerText;
        const contentText = contentRef.current.innerText;
        if (titleText.trim() === '' || contentText.trim() === '') {
            notifyError("Both title and content must be filled out.");
            return;
        }
        const speech = new SpeechSynthesisUtterance(`${titleText}. ${contentText}`);
        speech.onend = () => setIsSpeaking(false);
        window.speechSynthesis.speak(speech);
        setIsSpeaking(true);
    };

    const handleGenerateNote = async () => {
        try {
            const genAI = new GoogleGenerativeAI(API_KEY);
            const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
            const result = await model.generateContent(inputValue);
            const response = await result.response;
            const text = await response.text();

            // Remove unnecessary asterisk (*) symbols from the generated text
            const cleanedText = text.replace(/\*+/g, '');

            contentRef.current.innerText = cleanedText;
            titleRef.current.innerText = inputValue;

            toast.success("Note Generated. Please Edit Both Topic And Content Of Note Before Adding Notes.");
            setShowInputField(false); // Hide the input field after generating the note
        } catch (error) {
            console.error("Error generating content:", error);
            notifyError("Failed to generate content.");
        }
    };

    const handleGenerateNoteWithLoading = async () => {
        setIsLoading(true);
        await handleGenerateNote();
        setIsLoading(false);
    };

    const handleImgGenerateWithLoading = async () => {
        setImgIsLoading(false)
        await handleFetchImage();
        setImgIsLoading(false)
    };

    const onpenInput = () => {
        setImgInputfield(!imgInputfield)
    }

    const handleFindAndReplace = (findWord, replaceWord) => {
        const findText = findWord;
        if (!findText) return;

        const replaceText = replaceWord;
        if (replaceText === null) return;

        const range = document.createRange();
        const selection = window.getSelection();
        const findInNode = (node) => {
            if (node.nodeType === Node.TEXT_NODE) {
                const startIndex = node.textContent.indexOf(findText);
                if (startIndex !== -1) {
                    range.setStart(node, startIndex);
                    range.setEnd(node, startIndex + findText.length);
                    const replacementNode = document.createTextNode(replaceText);
                    range.deleteContents();
                    range.insertNode(replacementNode);
                    selection.removeAllRanges();
                }
            } else if (node.nodeType === Node.ELEMENT_NODE) {
                node.childNodes.forEach(findInNode);
            }
        };

        findInNode(contentRef.current);
        findInNode(titleRef.current);
    };

    const handleMark = () => {
        const selection = window.getSelection();
        if (!selection.rangeCount) return;

        const range = selection.getRangeAt(0);
        const markElement = range.startContainer.parentElement;

        if (markElement && markElement.tagName === 'MARK' && markElement) {
            // If already marked, remove the mark
            const parent = markElement.parentNode;
            while (markElement.firstChild) {
                parent.insertBefore(markElement.firstChild, markElement);
            }
            parent.removeChild(markElement);
        } else {
            // If not marked, add a mark
            const newMarkElement = document.createElement('mark');
            newMarkElement.appendChild(range.extractContents());
            range.insertNode(newMarkElement);
        }

        // Clear the selection
        selection.removeAllRanges();
    };

    const handleImageUpload = () => {
        // Trigger the file input click in Notewriter
        if (fileInputRef.current) {
            fileInputRef.current.click();
        }
    };

    const handleClearOldNotes = () => {
        const confirmation = window.confirm("Do you really want to delete all notes before older than 30 days? This will automatically delete notes older than 30 days for saving memory. Press OK to delete the notes.");

        if (confirmation) {
            const currentDate = new Date();
            const oneMonthAgo = new Date(currentDate.getTime() - 30 * 24 * 60 * 60 * 1000); // 30 days ago
            const updatedNotes = addItem.filter(note => new Date(note.date) >= oneMonthAgo);
            setAddItem(updatedNotes);
            localStorage.setItem('notes', JSON.stringify(updatedNotes));
        }
    };

    // Count the number of notes
    const noteCount = addItem.length;


    const handleFetchImage = async () => {
        if (!imageQuery) {
            notifyError("Please enter a search term for the image.");
            return;
        }

        const fetchFromUnsplash = async () => {
            try {
                const response = await fetch(`https://source.unsplash.com/featured/?${imageQuery}`);
                if (response.ok) {
                    return response.url;
                } else {
                    throw new Error("Unsplash fetch failed");
                }
            } catch (error) {
                throw new Error("Unsplash fetch failed");
            }
        };

        const fetchFromPexels = async () => {
            const apiKey = PIXEL_KEY; // Replace with your Pexels API key
            const randomPage = Math.floor(Math.random() * 100) + 1; // Randomly select a page number between 1 and 100
            try {
                const response = await fetch(`https://api.pexels.com/v1/search?query=${imageQuery}&per_page=1&page=${randomPage}`, {
                    headers: {
                        Authorization: apiKey
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    return data.photos[0].src.original;
                } else {
                    throw new Error("Pexels fetch failed");
                }
            } catch (error) {
                throw new Error("Pexels fetch failed");
            }
        };

        try {
            let imageUrl = await fetchFromUnsplash();
            const imgHTML = `<img src="${imageUrl}" style="width: ${imageWidth || 'auto'}; height: ${imageHeight || 'auto'};"/>`;
            document.execCommand('insertHTML', false, imgHTML);
            notifySuccess("Image fetched and inserted successfully.");
        } catch (error) {
            try {
                let imageUrl = await fetchFromPexels();
                const imgHTML = `<img src="${imageUrl}" style="width: ${imageWidth || 'auto'}; height: ${imageHeight || 'auto'};"/>`;
                document.execCommand('insertHTML', false, imgHTML);
                notifySuccess("Image fetched and inserted successfully.");
            } catch (error) {
                notifyError("Failed to fetch image from both Unsplash and Pexels. Please try again.");
            }
        }
    };


    const toggleVideoVisibility = () => {
        setIsVideoVisible(!isVideoVisible);
    };

    const modifySelectedTextFontSize = (increment) => {
        const selection = window.getSelection();
        if (!selection.isCollapsed) {
            const range = selection.getRangeAt(0);
            const selectedText = range.extractContents();

            const span = document.createElement('span');
            span.appendChild(selectedText);

            const currentSize = window.getComputedStyle(range.startContainer.parentNode).fontSize;
            const newSize = parseFloat(currentSize) + increment;
            span.style.fontSize = `${newSize}px`;

            range.insertNode(span);
            range.selectNodeContents(span);
        }
    };

    const handleIncreaseFontSize = () => {
        modifySelectedTextFontSize(1);
    };

    const handleDecreaseFontSize = () => {
        modifySelectedTextFontSize(-1);
    };

    const handleFontFamilyChange = (fontFamily) => {
        const selection = window.getSelection();

        if (selection.isCollapsed) {
            // No text is selected, so change the font style of the title and content
            const title = document.getElementById('title');
            const content = document.getElementById('content');

            if (title) {
                title.style.fontFamily = fontFamily;
            }
            if (content) {
                content.style.fontFamily = fontFamily;
            }
            return;
        }

        const range = selection.getRangeAt(0);
        const startNode = range.startContainer;
        const endNode = range.endContainer;

        // Function to wrap text nodes within the selection with a span
        const wrapTextNodes = (node, fontFamily) => {
            if (node.nodeType === Node.TEXT_NODE) {
                const span = document.createElement('span');
                span.style.fontFamily = fontFamily;
                span.className = 'styled-text';
                const textNode = document.createTextNode(node.nodeValue);
                span.appendChild(textNode);
                node.parentNode.replaceChild(span, node);
            } else if (node.nodeType === Node.ELEMENT_NODE) {
                node.childNodes.forEach(childNode => wrapTextNodes(childNode, fontFamily));
            }
        };

        // Function to process the selection range and apply the font style
        const processSelection = (startNode, endNode, fontFamily) => {
            let node = startNode;
            while (node && node !== endNode.nextSibling) {
                if (node.nodeType === Node.TEXT_NODE || node.nodeType === Node.ELEMENT_NODE) {
                    wrapTextNodes(node, fontFamily);
                }
                node = node.nextSibling;
            }
        };

        // Apply the font family to the selected text nodes
        processSelection(startNode, endNode, fontFamily);

        // Re-apply the selection to prevent it from being lost
        selection.removeAllRanges();
        selection.addRange(range);
    };

    const handlewikipedia = () => {
        setshowWikipedia(!showWikipedia);
    }

    const handleYourdictionary = () => {
        setShowdictionary(!showdictionary);
    }

    const marqueeText = "To use the text formatting tools in our application, ensure you first select the text. For bold, italic, or underline, click the respective button after selection. For text alignment, choose the desired alignment button. This ensures your text is formatted correctly. Always select text before using any tool."
    const visiablemarquee = setInterval(() => {
        setMarqueeVisiable(false);
        return () => clearTimeout(visiablemarquee);
    }, 30000);

    const hideaboutsection = () => {
        sethideAbout(!hideAbout);
    }

    const hidecalculator = () => {
        setOpencalculator(!openCalculator)
    }

    const linkTodraw = 'https://www.autodraw.com/';

    const openDrawingAreaToIllustrate = () => {
        setOpenDrawingArea(!openDrawingArea);
    }

    const openFullScreen = () => {
        const iframeContainer = document.getElementById('drawingIframeContainer');
        if (iframeContainer.requestFullscreen) {
            iframeContainer.requestFullscreen();
        } else if (iframeContainer.webkitRequestFullscreen) { // Safari
            iframeContainer.webkitRequestFullscreen();
        } else if (iframeContainer.msRequestFullscreen) { // IE11
            iframeContainer.msRequestFullscreen();
        } else {
            alert('Fullscreen mode is not supported in this browser.');
        }
    };


    const convertToHyperlink = () => {
        // Get the current selection
        const selection = window.getSelection();

        // Ensure there is a valid selection and it's not collapsed
        if (selection.rangeCount > 0 && !selection.isCollapsed) {
            const range = selection.getRangeAt(0); // Get the selected range
            const selectedText = range.toString().trim(); // Get the selected text and trim it

            // Regular expression to validate URLs starting with http or https
            const urlPattern = /^(https?:\/\/[^\s]+)$/;

            // Check if the selected text is already a hyperlink
            if (range.commonAncestorContainer.closest && range.commonAncestorContainer.closest('a')) {
                alert('The selected text is already a hyperlink.');
                return;
            }

            if (urlPattern.test(selectedText)) {
                // Create an anchor element
                const anchor = document.createElement('a');
                anchor.href = selectedText;
                anchor.target = '_blank'; // Open in a new tab
                anchor.rel = 'noopener noreferrer'; // For security
                anchor.textContent = selectedText;

                // Add an accessible label
                anchor.setAttribute('aria-label', `Link to ${selectedText}`);

                // Replace the selected text with the anchor element
                range.deleteContents(); // Remove the selected text
                range.insertNode(anchor); // Insert the anchor in its place

                // Adjust the cursor position after the anchor
                const newRange = document.createRange();
                newRange.setStartAfter(anchor);
                newRange.collapse(true);
                selection.removeAllRanges();
                selection.addRange(newRange);
            } else {
                alert('The selected text is not a valid URL. Please select a valid URL starting with http or https.');
            }
        } else {
            alert('Please select some text to convert into a hyperlink.');
        }
    };






    return (
        <>
            <ToastContainer
                position="top-right"
                autoClose={6000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="colored"
            />
            <Texttools
                handleBold={handleBold}
                handleItalic={handleItalic}
                handleUnderline={handleUnderline}
                handleAlign={handleAlign}
                handleColorChange={handleColorChange}
                handleCopy={handleCopy}
                handleUppercase={handleUppercase}
                handleCapitalize={handleCapitalize}
                handleLowercase={handleLowercase}
                handleTextToSpeech={handleTextToSpeech}
                handleGenerateNote={() => setShowInputField(!showInputField)}
                handleFindAndReplace={handleFindAndReplace}
                handleMark={handleMark}
                handleImageUpload={handleImageUpload}
                fileInputRef={fileInputRef}
                handleClearOldNotes={handleClearOldNotes}
                onpenInput={onpenInput} // Pass handleFetchImage to Texttools
                toggleVideoVisibility={toggleVideoVisibility}
                handleIncreaseFontSize={handleIncreaseFontSize}
                handleDecreaseFontSize={handleDecreaseFontSize}
                onFontFamilyChange={handleFontFamilyChange}
                handlewikipedia={handlewikipedia}
                handleYourdictionary={handleYourdictionary}
                hideaboutsection={hideaboutsection}
                hidecalculator={hidecalculator}
                openDrawingAreaToIllustrate={openDrawingAreaToIllustrate}
                convertToHyperlink={convertToHyperlink}
            />

            {marqueeVisiable && (
                <>
                    <div className="flex bg-white mt-2 p-2 container-fluid" style={{ alignItems: 'center', borderRadius: "50px" }}>
                        <div className="p-1 container" style={{ alignItems: 'center', borderRadius: "50px" }}>
                            <Marquee
                                direction='left'
                                delay={10}
                                speed={50}
                                pauseOnHover={true}
                                gradient={false}
                                className="marquee-container">
                                <h5 className='font-serif text-bolder text-pink-950'>
                                    {marqueeText}
                                </h5>
                            </Marquee>
                        </div>
                    </div>
                </>
            )}

            {
                openCalculator && (
                    <div className="flex justify-between bg-white my-2 calcol container-fluid"
                        style={{
                            border: '1px solid #ccc',
                            borderRadius: "10px",
                            padding: "1%",
                            alignItems: "center"
                        }}>
                        <div className="card container-fluid">
                            <h1 className='font-bolder text-4xl text-dark text-capitalize card-header'>
                                PreciousNotes... Calculator
                            </h1>
                            <p className='p-2 font-serif card-text'>
                                At PreciousNotes, we understand the importance of quick and accurate calculations in your daily tasks. Our integrated calculator feature is designed to enhance your productivity by providing instant solutions to basic and complex mathematical problems. Whether you need to perform simple arithmetic or tackle advanced equations, our calculator is a reliable tool that seamlessly integrates with your notes. This allows you to stay organized and focused without switching between different apps. Perfect for students, professionals, and anyone who values efficiency, our calculator ensures that you have the power of precise calculations at your fingertips.
                            </p>
                        </div>
                        <div className="container-fluid">
                            <YourNotesCalculator />
                        </div>

                    </div>
                )
            }


            <div className="flex justify-around gap-2 container-fluid mobilescreengeneratordiv" style={{ alignItems: "center" }}>

                {showInputField && (
                    <div className="bg-gradient-to-r from-teal-100 to-blue-200 mt-2 container-fluid" style={{
                        width: '100%',
                        height: '400px',
                        border: '1px solid #ccc',
                        borderRadius: "10px",
                        padding: "1%"
                    }}>
                        <label className="form-label font-bold text-capitalize">Generate Note</label>
                        <div className="mb-3">
                            <textarea
                                type="search"
                                value={inputValue}
                                onChange={(e) => setInputValue(e.target.value)}
                                placeholder="Enter note topic..."
                                className="form-control input-full-width"
                                style={{ height: '17.25rem' }}
                            ></textarea>
                            {isLoading ? (
                                <button className="font-bold text-2xl rotator" disabled>
                                    <i className="bi-arrow-clockwise text-2xl bi"></i>
                                </button>
                            ) : (
                                <button className="css-button-shadow-border-sliding--green font-bold btn btn-outline-success" onClick={handleGenerateNoteWithLoading} title='AI Generated Note'>
                                    <i className="bi-send-arrow-up-fill bi"></i> Send
                                </button>
                            )}
                        </div>
                    </div>
                )}

                {imgInputfield ? (
                    <div className="bg-gradient-to-r from-teal-100 to-blue-200 mt-2 container-fluid" style={{
                        width: '100%',
                        height: '400px',
                        border: '1px solid #ccc',
                        borderRadius: "10px",
                        padding: "1%"
                    }}>
                        <label className="form-label font-bold text-capitalize">Generate Image</label>
                        <div className="mb-3" style={{ maxWidth: '100%' }}>
                            <input
                                type="search"
                                value={imageQuery}
                                onChange={(e) => setImageQuery(e.target.value)}
                                placeholder="Enter a search term for the image..."
                                className="form-control input-full-width"
                            />
                            <div className="mt-3 input-group">
                                <input
                                    type="search"
                                    value={imageWidth}
                                    onChange={(e) => setImageWidth(e.target.value)}
                                    className="form-control"
                                    placeholder="Width (e.g., 500px or 50%),900px Full Width On Desktop"
                                />
                                <input
                                    type="search"
                                    value={imageHeight}
                                    onChange={(e) => setImageHeight(e.target.value)}
                                    className="form-control"
                                    placeholder="Height (e.g., 300px or auto)"
                                />
                            </div>
                            {isImgLoading ? (
                                <button className="mt-6 font-bold text-2xl rotator" disabled>
                                    <i className="bi-arrow-clockwise text-2xl bi"></i>
                                </button>
                            ) : (
                                <>
                                    <button className="css-button-shadow-border-sliding--green mt-2 font-bold btn btn-outline-success" onClick={handleImgGenerateWithLoading} title='AI Generated Note'>
                                        <i className="bi bi-search"></i> Generate Image
                                    </button>
                                    <div className="d-flex justify-start items-center mt-4 object-fit-cover">
                                        <img src={generatedimgaepicphot} className="rounded-3xl w-40 img-fluid"
                                            alt="" />
                                        <h1 className='px-2 font-bold font-serif text-center text-lg text-capitalize'>
                                            generate your image!
                                        </h1>
                                    </div>

                                </>
                            )}
                        </div>
                    </div>
                ) : (null)}

                {showWikipedia ? (
                    <>
                        <iframe
                            id="wikiFrame"
                            src="https://www.wikipedia.org/"
                            style={{
                                width: '100%',
                                height: '400px',
                                border: '1px solid #ccc',
                                borderRadius: "10px",
                            }}
                            title="Wikipedia"
                            className='mt-2'
                        ></iframe>
                    </>
                ) : (null)}

                {
                    showdictionary ? (
                        <>
                            <div
                                style={{
                                    width: '100%',
                                    height: '400px',
                                    border: '1px solid #ccc',
                                    borderRadius: "10px",
                                    overflow: "scroll"
                                }}
                                title='Your Dictionary'
                                className='bg-gradient-to-r from-teal-100 to-blue-300 mt-2'>
                                <Dictonary />
                            </div>
                        </>
                    ) : (null)
                }
            </div>


            {/* Auto Draw */}
            {openDrawingArea && (
                <>
                    <div className="d-flex justify-center container-fluid">
                        <button onClick={openFullScreen} className="my-2 btn btn-primary btn-sm">
                            <i class="bi bi-arrows-fullscreen"></i> Open Full Screen
                        </button>
                    </div>
                    <div id="drawingIframeContainer" className="container-fluid">
                        <iframe src={linkTodraw} className="w-100 min-h-screen" frameBorder="0" title="AutoDraw"></iframe>
                    </div>
                </>
            )}



            <div className="flex justify-between bg-white my-2 px-2 container-fluid outercontainerfield">
                <div className="container-fluid inputfield">
                    <Notewriter
                        passNote={addNote}
                        editNote={editNote !== null ? addItem[editNote] : null}
                        titleRef={titleRef}
                        contentRef={contentRef}
                        fileInputRef={fileInputRef}
                        notifyError={notifyError}
                        notifySuccess={notifySuccess}
                    />
                </div>
                <div className="bg-gray-100 mt-2 mb-2 container-fluid jiophonemaxheight notedisplayfield" style={{
                    backgroundImage: "radial-gradient(circle, rgba(1, 0, 1, 0.20) 1px, rgba(255, 255, 255, 0.05) 1px)",
                    backgroundSize: "20px 20px"
                }}>
                    <div className="flex justify-between gap-11 bg-gray-800 my-2 p-2 rounded-2xl font-bold font-serif text-2xl text-white text-wrap text-capitalize forjiophone" style={{ alignItems: 'center' }}>
                        notes...
                        <input
                            className="form-control my-2"
                            type="search"
                            placeholder="Search"
                            aria-label="Search"
                            value={searchQuery}
                            onChange={handleSearch}
                        />
                    </div>
                    <div className="container">
                        <p className='mb-2 font-bold text-blue-900 text-center text-capitalize card-title'>
                            {(addItem.length === 0) ? ("(notes) not available") : ("number of notes... " + noteCount)}  {/* Display the note count here */}
                        </p>
                    </div>
                    <div className="container" style={{ overflowY: 'scroll', maxHeight: '68vh' }}>
                        {filteredNotes.map((val, index) => (
                            <React.Fragment key={index}>
                                <Allsavenote
                                    index={index}
                                    title={val.title}
                                    content={val.content}
                                    onDelete={handleDelete}
                                    onEdit={handleEdit}
                                    date={val.date}
                                    time={val.time}
                                    notifyError={notifyError}
                                    notifySuccess={notifySuccess}
                                />
                                <AllSavenotemodal
                                    index={index}
                                    title={val.title}
                                    content={val.content}
                                    date={val.date}
                                    time={val.time}
                                    handleCopy={handleCopy}
                                />
                            </React.Fragment>
                        ))}
                    </div>
                </div>
            </div>
            <div className="controllerflex flex justify-evenly my-4 w-100 container-fluid">
                <div className="container-fluid">

                    <VisitorCounter />

                    <div className="container-fluid" style={{
                        maxHeight: "450px",
                        overflowY: "scroll"
                    }}>
                        {
                            hideAbout && (
                                <About />
                            )
                        }
                    </div>
                </div>
                <div className="container-fluid">
                    {isVideoVisible ? (

                        <>

                            <div className="container-fluid" style={{
                                maxHeight: "730px",
                                overflowY: "scroll"
                            }}>
                                <Appusermanual />
                            </div>
                        </>) : (
                        <>
                            <div className="container-fluid" style={{
                                maxHeight: "675px",
                                overflowY: "scroll"
                            }}>
                                <VideoContainer />
                            </div>
                        </>
                    )} {/* Conditionally render the VideoContainer */}
                </div>
            </div>
        </>
    );
};

export default Mainapp;
